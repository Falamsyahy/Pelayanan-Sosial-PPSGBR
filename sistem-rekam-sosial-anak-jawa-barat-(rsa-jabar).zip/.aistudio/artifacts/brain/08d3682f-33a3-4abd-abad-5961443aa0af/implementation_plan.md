# Rencana Implementasi: Kop Surat Gambar, Ekspor Multi-Angkatan, & Instrumen Asesmen Terpadu

Rencana ini merinci integrasi gambar resmi `Kopsurat.png` (UPTD Pusat Pelayanan Sosial Griya Bina Remaja Lembang), penyesuaian ekspor Excel dengan sistem checklist multi-angkatan, serta penautan instrumen **Social Roadmap**, **Genogram**, dan **Ecomap** secara terpadu pada **Tab Asesmen** dan **Tab Evaluasi**.

---

## 1. Integrasi Gambar Kop Surat (`Kopsurat.png`)
- **Penempatan Berkas Aset**:
  - Menyalin `/Kopsurat.png` ke `/public/Kopsurat.png` agar dapat diakses langsung oleh Vite di web.
  - Menyiapkan konversi base64 untuk integrasi pada ekspor PDF (`html2canvas`/`jsPDF`) dan ekspor Word (`.doc`) agar gambar selalu tampil sempurna tanpa kendala jalur lokal.
- **Penerapan Gambar Kop Utuh**:
  - Mengganti teks kop surat lama di `src/components/tabs/TabCetak.tsx` dengan banner gambar `Kopsurat.png` utuh beresolusi tinggi.
  - Memperbarui `src/services/exportDocumentService.ts` sehingga seluruh lembar cetak tab (Asesmen, Intervensi, Evaluasi, dan Laporan Lengkap) menggunakan gambar kop resmi UPTD PPS Griya Bina Remaja.

---

## 2. Fitur Ekspor Excel Multi-Angkatan Berbasis Checklist
- **Pembaruan Antarmuka pada `DataManagementModal.tsx`**:
  - Mengubah pemilih angkatan dari dropdown tunggal menjadi **daftar pilihan checklist multi-angkatan** (checkbox interaktif).
  - Menyediakan tombol cepat: **"Pilih Semua Angkatan"** dan **"Reset Pilihan"**.
  - Menampilkan jumlah anak binaan di samping setiap checkbox angkatan serta ringkasan total anak yang akan diekspor (misal: *32 dari 40 anak terpilih*).
- **Logika Ekspor pada `exportExcelService.ts`**:
  - Memperbarui `exportClientsToExcel` agar menerima array angkatan yang dipilih (`selectedAngkatan: string[]`).
  - Menjaga kolom **"Angkatan Masuk" (Kolom C)** tetap berada di bagian depan spreadsheet.
  - Sheet rekapitulasi per angkatan akan merangkum seluruh angkatan yang dicentang.

---

## 3. Penautan Instrumen Social Roadmap, Genogram, & Ecomap (Terpadu di Asesmen & Evaluasi)
Berdasarkan arahan peksos, ketiga instrumen ini ditautkan secara fungsional pada alur:
1. **Genogram (Pohon Keluarga 3 Generasi & Pola Asuh)**:
   - Ditautkan pada **Tab Asesmen &rarr; Dimensi Sosial & Relasi Keluarga**.
   - Digunakan untuk memetakan dinamika 3 generasi, riwayat putus sekolah/eksploitasi antargenerasi, dan penelusuran keluarga (*family tracing* / *kinship care*).
2. **Ecomap (Peta Ekologi Sosial Anak)**:
   - Ditautkan pada **Tab Asesmen &rarr; Lingkungan Sosial & Komunitas**.
   - Digunakan untuk memetakan sistem di luar keluarga: sekolah/PKBM, lingkungan asal, teman sebaya asrama, dan satgas sosial wilayah.
3. **Social Roadmap (Peta Perjalanan Sosial & Peta Jalan Kemandirian)**:
   - Ditautkan pada **Tab Asesmen (Garis Waktu / Life History)** dan **Tab Evaluasi (Peta Jalan Kemandirian & Aftercare)**.
   - Memetakan 3 fase hidup anak:
     - **Fase 1: Akar Kerentanan Masa Lalu** (penelantaran, pekerja anak di jalanan, putus sekolah).
     - **Fase 2: Pembinaan di UPTD PPS Griya Bina Remaja** (stabilisasi emosi, asrama, pelatihan vokasi, penguatan karakter).
     - **Fase 3: Transisi & Reintegrasi Mandiri** (keberlanjutan sekolah PKBM/formal, sertifikasi kerja, kemandirian ekonomi).
- **Implementasi Komponen**:
  - Menambahkan kartu instrumen interaktif untuk mencatat hasil pembacaan Genogram, Ecomap, dan Social Roadmap pada `TabAsesmen.tsx`.
  - Menampilkan ketercapaian fase Social Roadmap pada `TabEvaluasi.tsx` yang bersinergi dengan *Growth Chart* dan *Aftercare*.
  - Memperbarui `TabCetak.tsx` dan `exportDocumentService.ts` agar ringkasan temuan ketiga instrumen ini tercantum di laporan resmi.

---

## 4. Verifikasi & Pengujian
- Menjalankan `compile_applet` dan `lint_applet` untuk menjamin tidak ada error TypeScript.
- Memverifikasi tampilan gambar kop surat pada pratinjau cetak dan unduhan PDF/Word.
- Menguji fungsi ekspor Excel dengan mencentang kombinasi beberapa angkatan sekaligus.
