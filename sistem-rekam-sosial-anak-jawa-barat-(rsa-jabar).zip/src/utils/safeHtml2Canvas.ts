import html2canvas from 'html2canvas';

type Html2CanvasOptions = Parameters<typeof html2canvas>[1];

/**
 * Robust wrapper around html2canvas that sanitizes modern CSS color formats (like oklch)
 * which cause html2canvas's internal color parser to throw:
 * "Error: Attempting to parse an unsupported color function 'oklch'"
 */
export async function safeHtml2Canvas(
  element: HTMLElement,
  options: Html2CanvasOptions = {}
): Promise<HTMLCanvasElement> {
  const userOnClone = options?.onclone;

  // Cache to avoid recalculating colors
  const colorCache = new Map<string, string>();

  // Use a temporary canvas to let the browser convert oklch to standard sRGB rgb(...)
  const dummyCanvas = document.createElement('canvas');
  dummyCanvas.width = 1;
  dummyCanvas.height = 1;
  const ctx = dummyCanvas.getContext('2d');

  const convertOklch = (colorStr: string): string => {
    if (!colorStr || !colorStr.includes('oklch')) return colorStr;
    return colorStr.replace(/oklch\([^)]+\)/g, (match) => {
      if (colorCache.has(match)) {
        return colorCache.get(match)!;
      }
      if (!ctx) return '#475569';
      try {
        ctx.fillStyle = '#475569';
        ctx.fillStyle = match;
        const converted = ctx.fillStyle;
        colorCache.set(match, converted);
        return converted;
      } catch (e) {
        return '#475569';
      }
    });
  };

  return html2canvas(element, {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
    ...options,
    onclone: (clonedDoc, clonedElement) => {
      try {
        // 1. Sanitize all <style> elements in clonedDoc
        const styleTags = clonedDoc.querySelectorAll('style');
        styleTags.forEach((styleTag) => {
          if (styleTag.textContent && styleTag.textContent.includes('oklch')) {
            styleTag.textContent = convertOklch(styleTag.textContent);
          }
        });

        // 2. Sanitize all inline styles in clonedDoc
        const allElements = clonedDoc.querySelectorAll('*');
        allElements.forEach((node) => {
          const el = node as HTMLElement;
          const inline = el.getAttribute('style');
          if (inline && inline.includes('oklch')) {
            el.setAttribute('style', convertOklch(inline));
          }
        });

        // 3. Intercept getComputedStyle on clonedDoc.defaultView
        const defaultView = clonedDoc.defaultView;
        if (defaultView && typeof defaultView.getComputedStyle === 'function') {
          const origGetComputedStyle = defaultView.getComputedStyle;
          defaultView.getComputedStyle = function (elt: Element, pseudoElt?: string | null) {
            const style = origGetComputedStyle.call(defaultView, elt, pseudoElt);
            return new Proxy(style, {
              get(target, prop, receiver) {
                const val = Reflect.get(target, prop, receiver);
                if (typeof val === 'function') {
                  if (prop === 'getPropertyValue') {
                    return (propertyName: string) => {
                      const res = target.getPropertyValue(propertyName);
                      if (typeof res === 'string' && res.includes('oklch')) {
                        return convertOklch(res);
                      }
                      return res;
                    };
                  }
                  return val.bind(target);
                }
                if (typeof val === 'string' && val.includes('oklch')) {
                  return convertOklch(val);
                }
                return val;
              },
            });
          };
        }
      } catch (err) {
        console.warn('safeHtml2Canvas onclone sanitizer notice:', err);
      }

      // Call user's onclone if provided
      if (userOnClone) {
        userOnClone(clonedDoc, clonedElement);
      }
    },
  });
}
