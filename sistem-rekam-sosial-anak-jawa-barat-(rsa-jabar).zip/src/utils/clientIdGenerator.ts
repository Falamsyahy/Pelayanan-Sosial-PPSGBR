import { Client } from '../types';
import { JAWA_BARAT_REGIONS } from '../data/defaultData';

const ROMAN_MAP: Array<[number, string]> = [
  [1000, 'M'],
  [900, 'CM'],
  [500, 'D'],
  [400, 'CD'],
  [100, 'C'],
  [90, 'XC'],
  [50, 'L'],
  [40, 'XL'],
  [10, 'X'],
  [9, 'IX'],
  [5, 'V'],
  [4, 'IV'],
  [1, 'I'],
];

export function toRoman(num: number): string {
  if (!Number.isFinite(num) || num < 1) return 'I';
  let n = Math.floor(num);
  let res = '';
  for (const [val, sym] of ROMAN_MAP) {
    while (n >= val) {
      res += sym;
      n -= val;
    }
  }
  return res || 'I';
}

function normalizeRegionName(name: string): string {
  return (name || '')
    .toLowerCase()
    .trim()
    .replace(/^kab\.\s*/i, 'kabupaten ')
    .replace(/\s+/g, ' ');
}

/**
 * Mengembalikan Nomor Urut Kabupaten/Kota Jawa Barat (1 - 27) sesuai daftar JAWA_BARAT_REGIONS.
 * Contoh: "Kabupaten Ciamis" -> 5, "Kota Sukabumi" -> 26.
 */
export function getRegionCode(kabupatenKota: string): number {
  const norm = normalizeRegionName(kabupatenKota);
  if (!norm) return 0;

  // 1. Exact match
  const exactIdx = JAWA_BARAT_REGIONS.findIndex(
    (reg) => normalizeRegionName(reg) === norm
  );
  if (exactIdx !== -1) return exactIdx + 1;

  // 2. Partial match (misal "Bandung" atau "Sukabumi")
  const partialIdx = JAWA_BARAT_REGIONS.findIndex((reg) => {
    const rNorm = normalizeRegionName(reg);
    return rNorm === `kabupaten ${norm}` || rNorm === `kota ${norm}` || rNorm.includes(norm);
  });
  if (partialIdx !== -1) return partialIdx + 1;

  return 0;
}

/**
 * Mengekstrak nomor urut angkatan dalam format Angka Romawi (misal: "Angkatan III - 2026" -> "III").
 */
export function extractAngkatanRoman(angkatan: string): string {
  const raw = (angkatan || '').trim();
  if (!raw) return 'I';

  // Hapus tahun 4 digit agar tidak terbaca sebagai angka angkatan
  const withoutYear = raw.replace(/\b(19|20)\d{2}\b/g, ' ');

  // 1. Cek pola kata kunci diikuti angka romawi atau arab, misal "Angkatan III", "Angkatan 3", "Gelombang II"
  const keywordMatch = withoutYear.match(
    /(?:angkatan|gelombang|batch|tahap)\s*[:\-]?\s*([ivxlcdm]+|\d+)/i
  );
  if (keywordMatch && keywordMatch[1]) {
    const token = keywordMatch[1].toUpperCase();
    if (/^\d+$/.test(token)) {
      return toRoman(parseInt(token, 10));
    }
    if (/^[IVXLCDM]+$/.test(token)) {
      return token;
    }
  }

  // 2. Cek angka romawi berdiri sendiri
  const romanMatch = withoutYear.match(
    /\b(M{0,3}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{1,3}))\b/i
  );
  if (romanMatch && romanMatch[1]) {
    return romanMatch[1].toUpperCase();
  }

  // 3. Cek angka arab berdiri sendiri
  const numMatch = withoutYear.match(/\b(\d{1,3})\b/);
  if (numMatch && numMatch[1]) {
    return toRoman(parseInt(numMatch[1], 10));
  }

  return 'I';
}

/**
 * Mengekstrak Tahun Anggaran 4 digit dari string angkatan (default tahun berjalan / 2026).
 */
export function extractBudgetYear(angkatan: string): string {
  const yearMatch = (angkatan || '').match(/\b(20\d{2})\b/);
  if (yearMatch && yearMatch[1]) {
    return yearMatch[1];
  }
  return String(new Date().getFullYear());
}

export interface GenerateClientIdParams {
  kabupatenKota: string;
  angkatan: string;
  existingClients?: Client[];
  usedIds?: Set<string>;
}

/**
 * Menghasilkan ID Anak Binaan dengan format:
 * [Nomor Urut Anak dalam Kategori]-[Nomor Urut Kab/Kota]-[Angkatan Romawi]-[Tahun Anggaran]
 * Contoh: 1-26-III-2026 (Anak urut ke-1, Kota Sukabumi #26, Angkatan III, Tahun 2026)
 */
export function generateClientId({
  kabupatenKota,
  angkatan,
  existingClients = [],
  usedIds,
}: GenerateClientIdParams): string {
  const regionCode = getRegionCode(kabupatenKota);
  const angkatanRoman = extractAngkatanRoman(angkatan);
  const year = extractBudgetYear(angkatan);
  const suffix = `-${regionCode}-${angkatanRoman}-${year}`;

  const allUsedIds = new Set<string>(usedIds ? Array.from(usedIds) : []);
  let maxSeqInId = 0;
  let categoryCount = 0;

  existingClients.forEach((c) => {
    if (!c) return;
    if (c.id) {
      allUsedIds.add(c.id);
      if (c.id.endsWith(suffix)) {
        const prefix = c.id.slice(0, c.id.length - suffix.length);
        if (/^\d+$/.test(prefix)) {
          const seq = parseInt(prefix, 10);
          if (seq > maxSeqInId) maxSeqInId = seq;
        }
      }
    }

    const cRegion = getRegionCode(c.formData?.kabupatenKota || '');
    const cRoman = extractAngkatanRoman(c.formData?.angkatan || '');
    const cYear = extractBudgetYear(c.formData?.angkatan || '');
    if (cRegion === regionCode && cRoman === angkatanRoman && cYear === year) {
      categoryCount++;
    }
  });

  // Juga periksa usedIds yang mungkin belum ada di existingClients (misal dalam batch impor Excel)
  allUsedIds.forEach((id) => {
    if (id.endsWith(suffix)) {
      const prefix = id.slice(0, id.length - suffix.length);
      if (/^\d+$/.test(prefix)) {
        const seq = parseInt(prefix, 10);
        if (seq > maxSeqInId) maxSeqInId = seq;
      }
    }
  });

  let nextSeq = Math.max(maxSeqInId, categoryCount) + 1;
  let candidateId = `${nextSeq}${suffix}`;
  while (allUsedIds.has(candidateId)) {
    nextSeq++;
    candidateId = `${nextSeq}${suffix}`;
  }

  return candidateId;
}
