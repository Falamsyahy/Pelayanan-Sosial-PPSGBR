import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut as fbSignOut, 
  onAuthStateChanged,
  User as FirebaseUser,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDoc,
  getDocFromServer, 
  collection, 
  getDocs, 
  setDoc, 
  deleteDoc, 
  onSnapshot 
} from 'firebase/firestore';
import { AppUserProfile, Client } from './types';

// Configuration for semarakppsgbr (User's project)
export const SEMARAK_FIREBASE_CONFIG = {
  apiKey: "AIzaSyDqdr3CGqm7I3RA4m7Rk5Jpf_2ouxw3iEQ",
  authDomain: "semarakppsgbr.firebaseapp.com",
  projectId: "semarakppsgbr",
  storageBucket: "semarakppsgbr.firebasestorage.app",
  messagingSenderId: "454538885456",
  appId: "1:454538885456:web:284bc81a33e9527a80d455",
  measurementId: "G-R62P2HFBB7"
};

// Initialize Firebase with semarakppsgbr
let app: FirebaseApp;
if (!getApps().length) {
  app = initializeApp(SEMARAK_FIREBASE_CONFIG);
} else {
  app = getApp();
}

// Auth and Firestore from semarakppsgbr
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export { onAuthStateChanged };

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): FirestoreErrorInfo {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return errInfo;
}

// Authentication methods for semarakppsgbr
export async function loginWithEmail(email: string, pass: string): Promise<FirebaseUser> {
  const cred = await signInWithEmailAndPassword(auth, email, pass);
  return cred.user;
}

export async function registerWithEmail(email: string, pass: string, name?: string): Promise<FirebaseUser> {
  const cred = await createUserWithEmailAndPassword(auth, email, pass);
  if (name && cred.user) {
    await updateProfile(cred.user, { displayName: name });
  }
  return cred.user;
}

export async function signInWithGoogle(): Promise<FirebaseUser> {
  try {
    const cred = await signInWithPopup(auth, googleProvider);
    return cred.user;
  } catch (error: any) {
    if (error?.code === 'auth/unauthorized-domain') {
      const currentHost = window.location.hostname;
      throw new Error(
        `Domain ${currentHost} belum diizinkan di Firebase Console semarakppsgbr. Silakan gunakan Login dengan Email & Password, atau tambahkan domain ini di Authentication > Settings > Authorized domains.`
      );
    }
    throw error;
  }
}

export async function logoutUser(): Promise<void> {
  await fbSignOut(auth);
}

// Test connection
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (e) {
    return false;
  }
}

// Firestore operations for clients
const CLIENTS_COLLECTION = 'clients';

/**
 * Recursively removes all undefined properties from an object or array.
 * Firestore strictly rejects documents that contain undefined values.
 */
export function removeUndefinedFields<T>(obj: T): T {
  if (obj === null || obj === undefined) {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj
      .filter((item) => item !== undefined)
      .map((item) => removeUndefinedFields(item)) as unknown as T;
  }

  if (typeof obj === 'object') {
    if (obj instanceof Date || obj instanceof RegExp) {
      return obj;
    }

    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined) {
        cleaned[key] = removeUndefinedFields(value);
      }
    }
    return cleaned as T;
  }

  return obj;
}

export async function fetchClients(): Promise<Record<string, Client>> {
  try {
    const snapshot = await getDocs(collection(db, CLIENTS_COLLECTION));
    const result: Record<string, Client> = {};
    snapshot.forEach((docSnap) => {
      result[docSnap.id] = docSnap.data() as Client;
    });
    return result;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, CLIENTS_COLLECTION);
    return {};
  }
}

export async function saveClient(client: Client): Promise<void> {
  const docPath = `${CLIENTS_COLLECTION}/${client.id}`;
  try {
    const cleanData = removeUndefinedFields({
      ...client,
      updatedAt: new Date().toISOString(),
    });
    await setDoc(doc(db, CLIENTS_COLLECTION, client.id), cleanData);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, docPath);
    throw error;
  }
}

export async function removeClient(clientId: string): Promise<void> {
  const docPath = `${CLIENTS_COLLECTION}/${clientId}`;
  try {
    await deleteDoc(doc(db, CLIENTS_COLLECTION, clientId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, docPath);
    throw error;
  }
}

export function subscribeClients(
  onData: (clients: Record<string, Client>) => void,
  onError?: (errInfo: FirestoreErrorInfo) => void
) {
  if (!auth.currentUser) {
    return () => {};
  }
  return onSnapshot(
    collection(db, CLIENTS_COLLECTION),
    (snapshot) => {
      const result: Record<string, Client> = {};
      snapshot.forEach((docSnap) => {
        result[docSnap.id] = docSnap.data() as Client;
      });
      onData(result);
    },
    (error) => {
      const errInfo = handleFirestoreError(error, OperationType.GET, CLIENTS_COLLECTION);
      if (onError) onError(errInfo);
    }
  );
}

// Admin & User Role Management (RBAC)
const USERS_COLLECTION = 'users';

export const ADMIN_EMAILS: string[] = [
  'falamsyahy@gmail.com',
  '199408162020121011@jabarprov.go.id',
];

export function isBootstrappedAdminEmail(email?: string | null): boolean {
  if (!email) return false;
  return ADMIN_EMAILS.includes(email.trim().toLowerCase());
}

export async function fetchUserProfile(uid: string): Promise<AppUserProfile | null> {
  const docPath = `${USERS_COLLECTION}/${uid}`;
  try {
    const snap = await getDoc(doc(db, USERS_COLLECTION, uid));
    if (!snap.exists()) return null;
    return snap.data() as AppUserProfile;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, docPath);
    return null;
  }
}

export async function syncUserProfile(user: FirebaseUser): Promise<AppUserProfile> {
  const docPath = `${USERS_COLLECTION}/${user.uid}`;
  const isDefaultAdmin = isBootstrappedAdminEmail(user.email);
  const now = new Date().toISOString();

  try {
    const ref = doc(db, USERS_COLLECTION, user.uid);
    const snap = await getDoc(ref);

    if (snap.exists()) {
      const existing = snap.data() as AppUserProfile;
      if (existing.disabled === true && !isDefaultAdmin) {
        throw new Error(
          'Akun Anda saat ini dinonaktifkan oleh Administrator. Hubungi Admin UPTD PPS Griya Bina Remaja.'
        );
      }

      const resolvedRole = isDefaultAdmin
        ? 'admin'
        : existing.role === 'admin'
        ? 'admin'
        : 'peksos';

      const resolvedName =
        user.displayName?.trim() ||
        existing.nama ||
        user.email ||
        'Pekerja Sosial';

      // Non-admin owners only update non-RBAC fields so strict Firestore rules allow the write
      const updatePayload: Partial<AppUserProfile> = isDefaultAdmin
        ? {
            uid: user.uid,
            email: (user.email || existing.email || '').toLowerCase(),
            nama: resolvedName,
            role: resolvedRole,
            disabled: false,
            lastLoginAt: now,
            updatedAt: now,
          }
        : {
            nama: resolvedName,
            lastLoginAt: now,
            updatedAt: now,
          };

      await setDoc(ref, removeUndefinedFields(updatePayload), { merge: true });

      return {
        ...existing,
        uid: user.uid,
        email: (user.email || existing.email || '').toLowerCase(),
        nama: resolvedName,
        role: resolvedRole,
        lastLoginAt: now,
        updatedAt: now,
      };
    }

    const newProfile: AppUserProfile = {
      uid: user.uid,
      email: (user.email || '').toLowerCase(),
      nama: user.displayName?.trim() || user.email || 'Pekerja Sosial',
      role: isDefaultAdmin ? 'admin' : 'peksos',
      disabled: false,
      createdAt: now,
      lastLoginAt: now,
      updatedAt: now,
    };

    await setDoc(ref, removeUndefinedFields(newProfile));
    return newProfile;
  } catch (error: any) {
    // If Firestore rule blocks user profile sync on legacy rules, still allow bootstrapped admin or basic profile in memory
    if (error?.message?.includes('dinonaktifkan')) {
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, docPath);
    return {
      uid: user.uid,
      email: (user.email || '').toLowerCase(),
      nama: user.displayName?.trim() || user.email || 'Pekerja Sosial',
      role: isDefaultAdmin ? 'admin' : 'peksos',
      disabled: false,
      lastLoginAt: now,
    };
  }
}

export async function fetchAllUsers(): Promise<AppUserProfile[]> {
  try {
    const snap = await getDocs(collection(db, USERS_COLLECTION));
    const users: AppUserProfile[] = [];
    snap.forEach((docSnap) => {
      const data = docSnap.data() as AppUserProfile;
      users.push({
        ...data,
        uid: data.uid || docSnap.id,
      });
    });
    return users.sort((a, b) => (a.nama || a.email).localeCompare(b.nama || b.email));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, USERS_COLLECTION);
    throw error;
  }
}

export async function updateUserByAdmin(
  targetUid: string,
  updates: Partial<Pick<AppUserProfile, 'role' | 'disabled' | 'nama'>>
): Promise<void> {
  const docPath = `${USERS_COLLECTION}/${targetUid}`;
  try {
    await setDoc(
      doc(db, USERS_COLLECTION, targetUid),
      removeUndefinedFields({
        ...updates,
        updatedAt: new Date().toISOString(),
      }),
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, docPath);
    throw error;
  }
}


