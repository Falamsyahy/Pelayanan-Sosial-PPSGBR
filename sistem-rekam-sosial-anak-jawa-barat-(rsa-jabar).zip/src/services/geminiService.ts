import { Client } from '../types';

export interface PemaknaanResponse {
  pemaknaan?: string;
  error?: string;
  fallback?: string;
}

export interface IntervensiResponse {
  tujuan: string;
  strategi: string;
  indikator?: string[];
  error?: string;
}

export interface KonsultasiResponse {
  jawaban?: string;
  error?: string;
}

export async function requestGeminiPemaknaan(client: Client): Promise<string> {
  const fd = client.formData;
  const res = await fetch('/api/ai/pemaknaan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      nama: client.nama,
      umur: client.umur,
      gender: client.gender,
      kronologi: fd.asesmenKronologi,
      tingkatRisiko: fd.tingkatRisiko,
      biologis: fd.asesmenBiologis,
      psikologis: fd.asesmenPsikologis,
      sosial: fd.asesmenSosial,
      spiritual: fd.asesmenSpiritual,
      kebutuhanDasar: fd.asesmenKebutuhanDasar,
      pemecahanMasalah: fd.asesmenPemecahanMasalah,
      peranSosial: fd.asesmenPeranSosial,
    }),
  });

  const data: PemaknaanResponse = await res.json();
  if (!res.ok && !data.fallback) {
    throw new Error(data.error || 'Gagal memproses pemaknaan dengan AI');
  }
  return data.pemaknaan || data.fallback || '';
}

export async function requestGeminiIntervensi(client: Client): Promise<IntervensiResponse> {
  const fd = client.formData;
  const res = await fetch('/api/ai/intervensi', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      nama: client.nama,
      umur: client.umur,
      jurusan: fd.jurusan,
      tingkatRisiko: fd.tingkatRisiko,
      kronologi: fd.asesmenKronologi,
      psikologis: fd.asesmenPsikologis,
      sosial: fd.asesmenSosial,
      pemaknaan: fd.asesmenPemaknaan,
    }),
  });

  const data: IntervensiResponse = await res.json();
  return data;
}

export async function requestGeminiKonsultasi(pertanyaan: string, client?: Client): Promise<string> {
  const res = await fetch('/api/ai/konsultasi', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      pertanyaan,
      clientData: client,
    }),
  });

  const data: KonsultasiResponse = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Gagal memproses konsultasi');
  }
  return data.jawaban || '';
}
