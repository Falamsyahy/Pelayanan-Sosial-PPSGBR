import { jsPDF } from 'jspdf';
import { safeHtml2Canvas } from '../utils/safeHtml2Canvas';
import { Client } from '../types';
import { KOPSURAT_BASE64 } from '../data/kopsuratBase64';

export type TabExportType = 'asesmen' | 'intervensi' | 'evaluasi' | 'lengkap';

interface ExportParams {
  tabType: TabExportType;
  client: Client;
  peksosName: string;
}

/**
 * Mencegah XSS dan HTML Injection dengan melakukan encode karakter berbahaya
 */
export function escapeHtml(str: unknown): string {
  if (str === null || str === undefined) return '';
  const s = String(str);
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Validasi ketat format URL gambar untuk mencegah JavaScript URI injection
 */
export function sanitizeImageUrl(url: unknown): string | null {
  if (typeof url !== 'string' || !url.trim()) return null;
  const trimmed = url.trim();
  if (/^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(trimmed)) {
    return trimmed;
  }
  if (trimmed.startsWith('/') && !trimmed.startsWith('//')) {
    return escapeHtml(trimmed);
  }
  return null;
}

/**
 * Menghasilkan HTML resmi berstandar Dinas Sosial Jawa Barat untuk setiap tab tahapan
 */
export function generateOfficialTabHtml({ tabType, client, peksosName }: ExportParams): string {
  const fd = client.formData || ({} as any);
  const nowStr = new Date().toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const rawKabKota = fd.kabupatenKota || 'Bandung';
  const kabKotaClean = escapeHtml(
    rawKabKota.replace('Kabupaten ', '').replace('Kota ', '')
  );

  // Title & Subtitle based on tab
  let docTitle = 'LAPORAN REKAM MEDIS SOSIAL ANAK';
  let docSubTitle = 'Sistem Informasi Rekam Medis Sosial & Manajemen Kasus Anak Terpadu (BPSS)';
  
  if (tabType === 'asesmen') {
    docTitle = 'LEMBAR ASESMEN KOMPREHENSIF BPSS (BIOPSIKOSOSIOSPIRITUAL)';
    docSubTitle = 'Tahap II: Penggalian Data, Dimensi BPSS & Pemaknaan Kasus Anak';
  } else if (tabType === 'intervensi') {
    docTitle = 'LEMBAR RENCANA & LOG PELAKSANAAN INTERVENSI SOSIAL';
    docSubTitle = 'Tahap III: Rencana Pelayanan, Sasaran Perubahan & Log Sesi Binaan';
  } else if (tabType === 'evaluasi') {
    docTitle = 'LEMBAR EVALUASI TERMINASI & AFTERCARE (BIMBINGAN LANJUT)';
    docSubTitle = 'Tahap IV: Capaian Perkembangan, Status Kasus & Keberlanjutan Sekolah';
  } else if (tabType === 'lengkap') {
    docTitle = 'LAPORAN SOSIAL LENGKAP (LAPSOS) HASIL PELAYANAN ANAK';
    docSubTitle = 'Dokumen Terpadu Asesmen, Rencana Layanan, Evaluasi & Rekomendasi';
  }

  // Identitas Singkat Table
  const identitasHtml = `
    <table style="width: 100%; border-collapse: collapse; margin-bottom: 14px; font-size: 11pt;">
      <tr>
        <td style="width: 25%; font-weight: bold; border: none; padding: 3px 0;">Nama Lengkap Klien</td>
        <td style="border: none; padding: 3px 0;">: <strong>${escapeHtml(client.nama || '-')}</strong></td>
        <td style="width: 20%; font-weight: bold; border: none; padding: 3px 0;">No. Registrasi / ID</td>
        <td style="border: none; padding: 3px 0;">: ${escapeHtml(client.id || '-')}</td>
      </tr>
      <tr>
        <td style="font-weight: bold; border: none; padding: 3px 0;">NIK / Identitas</td>
        <td style="border: none; padding: 3px 0;">: ${escapeHtml(fd.noIdentitas || '-')} (${escapeHtml(fd.statusIdentitas || '-')})</td>
        <td style="font-weight: bold; border: none; padding: 3px 0;">Angkatan Binaan</td>
        <td style="border: none; padding: 3px 0;">: ${escapeHtml(fd.angkatan || '-')}</td>
      </tr>
      <tr>
        <td style="font-weight: bold; border: none; padding: 3px 0;">Usia / Gender</td>
        <td style="border: none; padding: 3px 0;">: ${escapeHtml(client.umur || '-')} Tahun / ${escapeHtml(client.gender || '-')}</td>
        <td style="font-weight: bold; border: none; padding: 3px 0;">Jurusan Vokasi</td>
        <td style="border: none; padding: 3px 0;">: ${escapeHtml(fd.jurusan || '-')}</td>
      </tr>
      <tr>
        <td style="font-weight: bold; border: none; padding: 3px 0;">Kabupaten / Kota Asal</td>
        <td style="border: none; padding: 3px 0;">: ${escapeHtml(fd.kabupatenKota || '-')} (Kec. ${escapeHtml(fd.kecamatan || '-')})</td>
        <td style="font-weight: bold; border: none; padding: 3px 0;">Status Kasus Saat Ini</td>
        <td style="border: none; padding: 3px 0;">: <strong>${escapeHtml(client.status || '-')}</strong></td>
      </tr>
      <tr>
        <td style="font-weight: bold; border: none; padding: 3px 0; vertical-align: top;">Pengasuhan / Orang Tua</td>
        <td colspan="3" style="border: none; padding: 3px 0; vertical-align: top;">
          ${fd.tipePengasuh === 'Wali'
            ? `: <strong>Wali:</strong> ${escapeHtml(fd.namaWali || '-')} (${escapeHtml(fd.hubunganWali || 'Wali')}) - Alasan: ${escapeHtml(fd.alasanDenganWali || '-')} | <strong>Status Orang Tua:</strong> Ayah (${escapeHtml(fd.namaAyah || '-')}: <em>${escapeHtml(fd.statusAyah || 'Tidak Diketahui')}</em>), Ibu (${escapeHtml(fd.namaIbu || '-')}: <em>${escapeHtml(fd.statusIbu || 'Tidak Diketahui')}</em>)`
            : `: <strong>Ayah:</strong> ${escapeHtml(fd.namaAyah || fd.namaWali || '-')} (${escapeHtml(fd.statusAyah || 'Masih Hidup')}) | <strong>Ibu:</strong> ${escapeHtml(fd.namaIbu || '-')} (${escapeHtml(fd.statusIbu || 'Masih Hidup')}) | Kontak: ${escapeHtml(fd.kontakWali || '-')}`
          }
        </td>
      </tr>
    </table>
  `;

  // Specific content builder
  let contentHtml = '';

  // 1. ASESMEN TAB CONTENT
  if (tabType === 'asesmen' || tabType === 'lengkap') {
    const metodeStr = (fd.asesmenMetodePenggalian && fd.asesmenMetodePenggalian.length > 0)
      ? fd.asesmenMetodePenggalian.join(' • ')
      : 'Wawancara mendalam anak, observasi harian';

    const informanStr = (fd.asesmenSumberInforman && fd.asesmenSumberInforman.length > 0)
      ? fd.asesmenSumberInforman.join(' • ')
      : 'Anak binaan (primer), orang tua/wali';

    const instrumenStr = (fd.asesmenInstrumenDigunakan && fd.asesmenInstrumenDigunakan.length > 0)
      ? fd.asesmenInstrumenDigunakan.join(' • ')
      : 'Genogram 3 generasi, Ecomap relasi';

    const safeGenogramImage = sanitizeImageUrl(fd.genogramImage);
    const safeEcomapImage = sanitizeImageUrl(fd.ecomapImage);

    contentHtml += `
      <div style="margin-bottom: 16px;">
        <h3 style="font-size: 11pt; font-weight: bold; border-bottom: 1.5pt solid #000; padding-bottom: 3px; margin-bottom: 8px; text-transform: uppercase;">
          ${tabType === 'lengkap' ? 'II.' : 'I.'} Asesmen Kronologi & Metodologi Penggalian Data
        </h3>

        <div style="margin-bottom: 8px;">
          <p style="font-weight: bold; margin: 0 0 4px 0; font-size: 10pt;">KRONOLOGI & DESKRIPSI MASALAH ANAK:</p>
          <div style="border: 1pt solid #444; background: #fafafa; padding: 8px; font-size: 10pt; text-align: justify; line-height: 1.4;">
            ${fd.asesmenKronologi || 'Belum ada catatan deskripsi kronologi masalah.'}
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 10pt;">
          <tr>
            <td style="width: 30%; font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Metode Penggalian Data</td>
            <td style="border: 1pt solid #000; padding: 6px;">${metodeStr}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Sumber Informan Kunci</td>
            <td style="border: 1pt solid #000; padding: 6px;">${informanStr}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Instrumen Diagnostik Peksos</td>
            <td style="border: 1pt solid #000; padding: 6px;">${instrumenStr}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Status Kecukupan Data</td>
            <td style="border: 1pt solid #000; padding: 6px;"><strong>${fd.asesmenKecukupanData || 'Data Lengkap & Memadai (Data Saturated)'}</strong></td>
          </tr>
          ${fd.asesmenCatatanPenggalian ? `
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Catatan Lapangan & Triangulasi</td>
            <td style="border: 1pt solid #000; padding: 6px; font-style: italic;">${fd.asesmenCatatanPenggalian}</td>
          </tr>
          ` : ''}
        </table>

        <p style="font-weight: bold; margin: 10px 0 4px 0; font-size: 10pt;">TRIANGULASI INSTRUMEN DIAGNOSTIK (GENOGRAM, ECOMAP & SOCIAL ROADMAP):</p>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 10pt;">
          <tr>
            <td style="width: 25%; font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">1. Genogram (3 Generasi)</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">${fd.genogramCatatan || 'Pola relasi keluarga dan riwayat pengasuhan 3 generasi telah dipetakan.'}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">2. Ecomap Lingkungan</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">${fd.ecomapCatatan || 'Jejaring ekologis, sistem sumber dukungan luar, dan faktor stres lingkungan telah dipetakan.'}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">3. Social Roadmap</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">${fd.socialRoadmapCatatan || 'Peta target capaian 3 fase (Intake &rarr; Vokasi Asrama &rarr; Kemandirian Aftercare) telah dirumuskan.'}</td>
          </tr>
        </table>

        ${(safeGenogramImage || safeEcomapImage) ? `
        <div style="margin: 10px 0 12px 0;">
          <p style="font-weight: bold; margin: 0 0 6px 0; font-size: 10pt;">LAMPIRAN VISUALISASI DIAGNOSTIK PEKSOS:</p>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              ${safeGenogramImage ? `
              <td style="width: ${safeEcomapImage ? '50%' : '100%'}; border: 1pt solid #000; padding: 8px; text-align: center; vertical-align: top;">
                <div style="font-size: 9pt; font-weight: bold; margin-bottom: 6px; color: #1e3a8a;">DIAGRAM GENOGRAM 3 GENERASI</div>
                <img src="${safeGenogramImage}" style="max-width: 100%; max-height: 220px; object-fit: contain; border: 1pt solid #ddd;" alt="Diagram Genogram" />
              </td>
              ` : ''}
              ${safeEcomapImage ? `
              <td style="width: ${safeGenogramImage ? '50%' : '100%'}; border: 1pt solid #000; padding: 8px; text-align: center; vertical-align: top;">
                <div style="font-size: 9pt; font-weight: bold; margin-bottom: 6px; color: #0369a1;">DIAGRAM ECOMAP EKOLOGI SOSIAL</div>
                <img src="${safeEcomapImage}" style="max-width: 100%; max-height: 220px; object-fit: contain; border: 1pt solid #ddd;" alt="Diagram Ecomap" />
              </td>
              ` : ''}
            </tr>
          </table>
        </div>
        ` : ''}

        <p style="font-weight: bold; margin: 10px 0 4px 0; font-size: 10pt;">DINAMIKA 4 DIMENSI BIOPSIKOSOSIOSPIRITUAL (BPSS):</p>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 10pt;">
          <thead>
            <tr style="background-color: #e5e7eb;">
              <th style="width: 25%; border: 1pt solid #000; padding: 6px; text-align: left; font-weight: bold;">Dimensi</th>
              <th style="border: 1pt solid #000; padding: 6px; text-align: left; font-weight: bold;">Temuan Asesmen & Kondisi Anak</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="border: 1pt solid #000; padding: 6px; font-weight: bold; background-color: #f9fafb;">Biologis & Rekam Kesehatan Balai</td>
              <td style="border: 1pt solid #000; padding: 6px;">
                <div><strong>Antropometri:</strong> Gol. Darah: <strong>${escapeHtml(fd.kesehatanGolonganDarah || '-')}</strong> | TB: <strong>${escapeHtml(String(fd.kesehatanTinggiBadan || '-'))} cm</strong> | BB: <strong>${escapeHtml(String(fd.kesehatanBeratBadan || '-'))} kg</strong> | IMT: <strong>${escapeHtml(String(fd.kesehatanIMT || '-'))}</strong> (${escapeHtml(fd.kesehatanStatusGizi || 'Normal')})</div>
                <div style="margin-top: 3px;"><strong>Skrining Balai:</strong> Imunisasi: ${escapeHtml(fd.kesehatanStatusImunisasi || '-')} | Kulit: ${escapeHtml(fd.kesehatanPenyakitKulit || 'Bebas keluhan')} | Zat: ${escapeHtml(fd.kesehatanSkriningZat || 'Bebas zat')} | Alergi: ${escapeHtml(fd.kesehatanRiwayatAlergi || '-')}</div>
                ${fd.kesehatanCatatanKlinik ? `<div style="margin-top: 3px;"><strong>Catatan Klinik:</strong> ${escapeHtml(fd.kesehatanCatatanKlinik)}</div>` : ''}
                <div style="margin-top: 3px;"><strong>Deskripsi Fisik:</strong> ${escapeHtml(fd.asesmenBiologis || '-')}</div>
              </td>
            </tr>
            <tr>
              <td style="border: 1pt solid #000; padding: 6px; font-weight: bold; background-color: #f9fafb;">Psikologis / Emosi</td>
              <td style="border: 1pt solid #000; padding: 6px;">${escapeHtml(fd.asesmenPsikologis || '-')}</td>
            </tr>
            <tr>
              <td style="border: 1pt solid #000; padding: 6px; font-weight: bold; background-color: #f9fafb;">Sosial & Relasi</td>
              <td style="border: 1pt solid #000; padding: 6px;">${escapeHtml(fd.asesmenSosial || '-')}</td>
            </tr>
            <tr>
              <td style="border: 1pt solid #000; padding: 6px; font-weight: bold; background-color: #f9fafb;">Spiritual & Moral</td>
              <td style="border: 1pt solid #000; padding: 6px;">${escapeHtml(fd.asesmenSpiritual || '-')}</td>
            </tr>
          </tbody>
        </table>

        <p style="font-weight: bold; margin: 10px 0 4px 0; font-size: 10pt;">KAPASITAS COPING & KEBERFUNGSIAN SOSIAL:</p>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 10pt;">
          <tr>
            <td style="width: 33%; border: 1pt solid #000; padding: 6px; background-color: #f9fafb;">
              <strong>1. Pemenuhan Kebutuhan Dasar:</strong><br/>
              <span style="font-size: 9.5pt;">${escapeHtml(fd.asesmenKebutuhanDasar || '-')}</span>
            </td>
            <td style="width: 33%; border: 1pt solid #000; padding: 6px; background-color: #f9fafb;">
              <strong>2. Pemecahan Masalah:</strong><br/>
              <span style="font-size: 9.5pt;">${escapeHtml(fd.asesmenPemecahanMasalah || '-')}</span>
            </td>
            <td style="width: 34%; border: 1pt solid #000; padding: 6px; background-color: #f9fafb;">
              <strong>3. Pelaksanaan Peran Sosial:</strong><br/>
              <span style="font-size: 9.5pt;">${escapeHtml(fd.asesmenPeranSosial || '-')}</span>
            </td>
          </tr>
        </table>

        ${fd.asesmenPemaknaan ? `
        <div style="margin-top: 8px;">
          <p style="font-weight: bold; margin: 0 0 4px 0; font-size: 10pt;">ANALISIS & PEMAKNAAN TEORETIS PEKERJAAN SOSIAL (MEANING-MAKING):</p>
          <div style="border: 1pt solid #000; background: #fdfdfd; padding: 8px; font-size: 10pt; text-align: justify; line-height: 1.4;">
            ${escapeHtml(fd.asesmenPemaknaan)}
          </div>
        </div>
        ` : ''}
      </div>
    `;
  }

  // 2. INTERVENSI TAB CONTENT
  if (tabType === 'intervensi' || tabType === 'lengkap') {
    const logs = client.pelaksanaanIntervensi || [];
    const logRows = logs.length > 0 
      ? logs.map((item, idx) => `
          <tr>
            <td style="border: 1pt solid #000; padding: 6px; text-align: center; width: 6%;">${idx + 1}</td>
            <td style="border: 1pt solid #000; padding: 6px; width: 20%; font-weight: bold; white-space: nowrap;">
              ${escapeHtml(item.tanggal || '-')}<br/>
              <span style="font-size: 8pt; color: #4338ca; font-weight: bold;">[${escapeHtml(item.peranPelaksana || 'Pekerja Sosial')}]</span>
            </td>
            <td style="border: 1pt solid #000; padding: 6px;">
              <strong>${escapeHtml(item.deskripsi || '-')}</strong>
              ${item.subjective || item.objective || item.assessment || item.plan ? `
                <div style="font-size: 8.5pt; margin-top: 4px; padding-top: 4px; border-top: 0.5pt dashed #cbd5e1; color: #374151;">
                  ${item.subjective ? `<div><strong>S (Subjektif):</strong> <em>${escapeHtml(item.subjective)}</em></div>` : ''}
                  ${item.objective ? `<div><strong>O (Objektif):</strong> ${escapeHtml(item.objective)}</div>` : ''}
                  ${item.assessment ? `<div><strong>A (Asesmen):</strong> ${escapeHtml(item.assessment)}</div>` : ''}
                  ${item.plan ? `<div><strong>P (Planning):</strong> ${escapeHtml(item.plan)}</div>` : ''}
                </div>
              ` : ''}
            </td>
            <td style="border: 1pt solid #000; padding: 6px; width: 30%;">${escapeHtml(item.indikator || '-')}</td>
          </tr>
        `).join('')
      : `
        <tr>
          <td colspan="4" style="border: 1pt solid #000; padding: 10px; text-align: center; font-style: italic;">
            Belum ada catatan log pelaksanaan sesi intervensi yang tercatat.
          </td>
        </tr>
      `;

    contentHtml += `
      <div style="margin-bottom: 16px;">
        <h3 style="font-size: 11pt; font-weight: bold; border-bottom: 1.5pt solid #000; padding-bottom: 3px; margin-bottom: 8px; text-transform: uppercase;">
          ${tabType === 'lengkap' ? 'III.' : 'I.'} Rencana & Log Pelaksanaan Intervensi Sosial
        </h3>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 10pt;">
          <tr>
            <td style="width: 25%; font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Tujuan Intervensi</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">${escapeHtml(fd.intervensiTujuan || '-')}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Strategi & Pendekatan</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">${escapeHtml(fd.intervensiStrategi || '-')}</td>
          </tr>
        </table>

        <p style="font-weight: bold; margin: 10px 0 4px 0; font-size: 10pt;">LOG CATATAN PELAKSANAAN SESI PEMBINAAN & LAYANAN:</p>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 9.5pt;">
          <thead>
            <tr style="background-color: #e5e7eb;">
              <th style="border: 1pt solid #000; padding: 6px; text-align: center;">No</th>
              <th style="border: 1pt solid #000; padding: 6px; text-align: left;">Tanggal</th>
              <th style="border: 1pt solid #000; padding: 6px; text-align: left;">Tindakan / Layanan Diberikan</th>
              <th style="border: 1pt solid #000; padding: 6px; text-align: left;">Indikator Capaian / Respon Anak</th>
            </tr>
          </thead>
          <tbody>
            ${logRows}
          </tbody>
        </table>
      </div>
    `;
  }

  // 3. EVALUASI & AFTERCARE TAB CONTENT
  if (tabType === 'evaluasi' || tabType === 'lengkap') {
    contentHtml += `
      <div style="margin-bottom: 16px;">
        <h3 style="font-size: 11pt; font-weight: bold; border-bottom: 1.5pt solid #000; padding-bottom: 3px; margin-bottom: 8px; text-transform: uppercase;">
          ${tabType === 'lengkap' ? 'IV.' : 'I.'} Evaluasi Perkembangan & Status Akhir Kasus
        </h3>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 10pt;">
          <tr>
            <td style="width: 25%; font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Kurva Pertumbuhan Sosial</td>
            <td style="border: 1pt solid #000; padding: 6px;">
              Skor Baseline: <strong>${fd.tingkatRisiko === 'Kritis' ? '38' : fd.tingkatRisiko === 'Tinggi' ? '48' : '58'}/100</strong> &rarr; Skor Terkini: <strong>${fd.evaluasiSkorAkhir || (client.status === 'Terminasi (Selesai)' ? '90' : '82')}/100</strong> (Tren Keberfungsian Positif Berkelanjutan)
            </td>
          </tr>
          <tr>
            <td style="width: 25%; font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Skala Panca Karakter Jabar</td>
            <td style="border: 1pt solid #000; padding: 6px;">
              ${fd.pancaKarakterTerakhir ? `
                <strong>Béréhan:</strong> ${fd.pancaKarakterTerakhir.berehan}/100 | 
                <strong>Calakan:</strong> ${fd.pancaKarakterTerakhir.calakan}/100 | 
                <strong>Waringkas:</strong> ${fd.pancaKarakterTerakhir.waringkas}/100 | 
                <strong>Motékar:</strong> ${fd.pancaKarakterTerakhir.motekar}/100 | 
                <strong>Berséka:</strong> ${fd.pancaKarakterTerakhir.berseka}/100 
                &rarr; <strong>Komposit: ${fd.pancaKarakterTerakhir.skorKomposit}/100</strong>
                ${fd.pancaKarakterTerakhir.catatan ? `<div style="font-style: italic; margin-top: 3px; font-size: 9pt;">"${escapeHtml(fd.pancaKarakterTerakhir.catatan)}"</div>` : ''}
              ` : 'Instrumen kemandirian sosial Panca Karakter Jabar.'}
            </td>
          </tr>
          <tr>
            <td style="width: 25%; font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Capaian Perkembangan</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">${escapeHtml(fd.evaluasiPerkembangan || '-')}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Catatan Hambatan</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">${escapeHtml(fd.evaluasiHambatan || 'Tidak ada hambatan berarti.')}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Social Roadmap (3-Fase)</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">
              <strong>Lintasan Milestone:</strong> Fase 1: Intake & Kerentanan (${fd.tingkatRisiko || 'Risiko Terdata'}) &rarr; 
              Fase 2: Pembinaan Balai (${(client.pelaksanaanIntervensi || []).length} Sesi Terlaksana) &rarr; 
              Fase 3: Kemandirian & Reintegrasi (${fd.aftercareStatusPendidikan ? 'Teradvokasi' : 'Persiapan'}).<br/>
              <em>Catatan Capaian: ${escapeHtml(fd.socialRoadmapCatatan || 'Target transisi berjalan teratur.')}</em>
            </td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Dinamika Keluarga (Genogram)</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">${escapeHtml(fd.genogramCatatan || 'Kesiapan sistem asuhan keluarga terpantau kooperatif.')}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Jejaring Ekologis (Ecomap)</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">${escapeHtml(fd.ecomapCatatan || 'Keterhubungan dengan PKBM mitra dan lingkungan sosial positif.')}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Status Kasus / Terminasi</td>
            <td style="border: 1pt solid #000; padding: 6px;"><strong>${escapeHtml(client.status || '-')}</strong></td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Alasan / Rekomendasi Kasus</td>
            <td style="border: 1pt solid #000; padding: 6px; text-align: justify;">${escapeHtml(fd.terminasiAlasan || '-')}</td>
          </tr>
        </table>

        <h3 style="font-size: 11pt; font-weight: bold; border-bottom: 1.5pt solid #000; padding-bottom: 3px; margin: 12px 0 8px 0; text-transform: uppercase;">
          ${tabType === 'lengkap' ? 'V.' : 'II.'} Indikator Bimbingan Lanjut (Aftercare) & Keberlanjutan Sekolah
        </h3>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 10pt;">
          <tr>
            <td style="width: 25%; font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Jalur Pendidikan Aftercare</td>
            <td style="border: 1pt solid #000; padding: 6px;"><strong>${escapeHtml(fd.aftercareStatusPendidikan || 'Belum diisi / Dalam proses advokasi')}</strong></td>
            <td style="width: 25%; font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Jenjang / Paket Kesetaraan</td>
            <td style="border: 1pt solid #000; padding: 6px;">${escapeHtml(fd.aftercareJenjang || '-')}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Nama Sekolah / Lembaga PKBM</td>
            <td style="border: 1pt solid #000; padding: 6px;">${escapeHtml(fd.aftercareNamaSekolah || '-')}</td>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Status Keaktifan Siswa</td>
            <td style="border: 1pt solid #000; padding: 6px;">${escapeHtml(fd.aftercareStatusSiswa || '-')}</td>
          </tr>
          ${fd.aftercareCatatanPendidikan ? `
          <tr>
            <td style="font-weight: bold; border: 1pt solid #000; padding: 6px; background-color: #f3f4f6;">Log Pemantauan Peksos</td>
            <td colspan="3" style="border: 1pt solid #000; padding: 6px; text-align: justify; font-style: italic;">
              ${escapeHtml(fd.aftercareCatatanPendidikan)}
            </td>
          </tr>
          ` : ''}
        </table>

        ${(fd.aftercareFollowUps && fd.aftercareFollowUps.length > 0) ? `
        <h3 style="font-size: 11pt; font-weight: bold; border-bottom: 1.5pt solid #000; padding-bottom: 3px; margin: 12px 0 8px 0; text-transform: uppercase;">
          ${tabType === 'lengkap' ? 'VI.' : 'III.'} Buku Pantau Pasca-Binaan (Aftercare Follow-Up Logbook)
        </h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 9.5pt;">
          <thead>
            <tr style="background-color: #e5e7eb;">
              <th style="border: 1pt solid #000; padding: 5px; width: 15%; text-align: left;">Tanggal / Tahap</th>
              <th style="border: 1pt solid #000; padding: 5px; width: 18%; text-align: left;">Metode & Status</th>
              <th style="border: 1pt solid #000; padding: 5px; width: 32%; text-align: left;">Kondisi Sekolah/Kerja & Keluarga</th>
              <th style="border: 1pt solid #000; padding: 5px; text-align: left;">Catatan & Analisis Peksos</th>
            </tr>
          </thead>
          <tbody>
            ${fd.aftercareFollowUps.map((af: any) => `
              <tr>
                <td style="border: 1pt solid #000; padding: 5px; vertical-align: top;">
                  <strong>${escapeHtml(af.tanggal || '-')}</strong><br/>
                  <span style="font-size: 8pt; color: #4338ca; font-weight: bold;">${escapeHtml(af.periode || '-')}</span>
                </td>
                <td style="border: 1pt solid #000; padding: 5px; vertical-align: top;">
                  ${escapeHtml(af.metodeKontak || '-')}<br/>
                  <strong>[${escapeHtml(af.statusReintegrasi || '-')}]</strong>
                </td>
                <td style="border: 1pt solid #000; padding: 5px; vertical-align: top;">
                  <strong>Sekolah/Kerja:</strong> ${escapeHtml(af.kondisiSekolahKerja || '-')}<br/>
                  <strong>Keluarga:</strong> ${escapeHtml(af.kondisiKeluarga || '-')}
                </td>
                <td style="border: 1pt solid #000; padding: 5px; vertical-align: top; text-align: justify;">
                  ${escapeHtml(af.catatanPeksos || '-')}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        ` : ''}
      </div>
    `;
  }

  // Lembar Tanda Tangan
  const ttdHtml = `
    <div style="margin-top: 30px; display: flex; justify-content: space-between; font-size: 10.5pt;">
      <table style="width: 100%; border: none;">
        <tr>
          <td style="width: 50%; text-align: center; border: none; vertical-align: top;">
            <p style="margin: 0 0 60px 0; font-weight: bold;">Penerima Manfaat / Wali,</p>
            <p style="margin: 0; font-weight: bold; text-decoration: underline;">${escapeHtml(client.nama || 'Klien Anak')}</p>
          </td>
          <td style="width: 50%; text-align: center; border: none; vertical-align: top;">
            <p style="margin: 0 0 4px 0; color: #333;">${kabKotaClean}, ${nowStr}</p>
            <p style="margin: 0 0 60px 0; font-weight: bold;">Pekerja Sosial Pendamping,</p>
            <p style="margin: 0; font-weight: bold; text-decoration: underline;">${escapeHtml(peksosName || 'Pekerja Sosial Ahli')}</p>
          </td>
        </tr>
      </table>
    </div>
  `;

  // Full Document Outer Template
  return `
    <div style="font-family: 'Times New Roman', Times, serif; color: #111; line-height: 1.4; padding: 24px; max-width: 800px; margin: 0 auto; background: #fff;">
      <!-- Kop Surat Resmi Gambar Utuh UPTD PPS Griya Bina Remaja -->
      <div style="text-align: center; margin-bottom: 12px; border-bottom: 1.5pt solid #000; padding-bottom: 6px;">
        <img 
          src="${KOPSURAT_BASE64}" 
          alt="Kop Surat UPTD Pusat Pelayanan Sosial Griya Bina Remaja" 
          style="width: 100%; max-height: 110px; object-fit: contain; margin: 0 auto; display: block;" 
        />
      </div>

      <!-- Judul Dokumen -->
      <div style="text-align: center; margin-bottom: 14px;">
        <h2 style="margin: 0; font-size: 13pt; font-weight: bold; text-transform: uppercase; text-decoration: underline; letter-spacing: 0.5px;">
          ${docTitle}
        </h2>
        <p style="margin: 3px 0 0 0; font-size: 9pt; font-family: monospace; color: #4b5563;">
          Nomor Dokumen: ${client.id || 'RS'}/${tabType.toUpperCase()}/${new Date().getFullYear()}
        </p>
      </div>

      <!-- Identitas Ringkas Klien -->
      ${identitasHtml}

      <!-- Konten Spesifik -->
      ${contentHtml}

      <!-- Lembar Tanda Tangan -->
      ${ttdHtml}
    </div>
  `;
}

/**
 * Mengunduh dokumen dalam format Microsoft Word (.doc) yang kompatibel penuh dengan Word/WPS/Docs
 */
export function exportToWord(params: ExportParams): void {
  const { tabType, client } = params;
  const bodyHtml = generateOfficialTabHtml(params);

  const safeClientName = (client.nama || 'Anak_Binaan').replace(/[^a-zA-Z0-9_-]/g, '_');
  const safeClientId = (client.id || 'RS').replace(/[^a-zA-Z0-9_-]/g, '_');
  
  const prefixMap: Record<TabExportType, string> = {
    asesmen: 'Asesmen_BPSS',
    intervensi: 'Intervensi_Sosial',
    evaluasi: 'Evaluasi_Aftercare',
    lengkap: 'Laporan_Lengkap_Lapsos'
  };

  const filename = `${prefixMap[tabType]}_${safeClientName}_${safeClientId}.doc`;

  const wordDocumentHtml = `
    <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset='utf-8'>
        <title>${prefixMap[tabType]} - ${client.nama}</title>
        <style>
          @page {
            size: A4 portrait;
            margin: 2cm 2cm 2cm 2cm;
            mso-header-margin: 1cm;
            mso-footer-margin: 1cm;
          }
          body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 11pt;
            line-height: 1.4;
            color: #000;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10pt;
          }
          th, td {
            font-size: 10.5pt;
          }
        </style>
      </head>
      <body>
        ${bodyHtml}
      </body>
    </html>
  `;

  const blob = new Blob(['\ufeff', wordDocumentHtml], {
    type: 'application/msword;charset=utf-8'
  });

  const url = URL.createObjectURL(blob);
  const downloadLink = document.createElement('a');
  downloadLink.href = url;
  downloadLink.download = filename;
  document.body.appendChild(downloadLink);
  downloadLink.click();
  document.body.removeChild(downloadLink);
  URL.revokeObjectURL(url);
}

/**
 * Mengunduh dokumen dalam format PDF berstandar A4 menggunakan jsPDF dan html2canvas
 */
export async function exportToPdf(params: ExportParams): Promise<void> {
  const { tabType, client } = params;
  const bodyHtml = generateOfficialTabHtml(params);

  const safeClientName = (client.nama || 'Anak_Binaan').replace(/[^a-zA-Z0-9_-]/g, '_');
  const safeClientId = (client.id || 'RS').replace(/[^a-zA-Z0-9_-]/g, '_');

  const prefixMap: Record<TabExportType, string> = {
    asesmen: 'Asesmen_BPSS',
    intervensi: 'Intervensi_Sosial',
    evaluasi: 'Evaluasi_Aftercare',
    lengkap: 'Laporan_Lengkap_Lapsos'
  };

  const filename = `${prefixMap[tabType]}_${safeClientName}_${safeClientId}.pdf`;

  // Render on off-screen container with fixed A4 width (794px ~ 210mm at 96 DPI)
  const container = document.createElement('div');
  container.style.position = 'fixed';
  container.style.left = '-9999px';
  container.style.top = '0';
  container.style.width = '794px';
  container.style.backgroundColor = '#ffffff';
  container.style.zIndex = '-999';
  container.innerHTML = bodyHtml;
  document.body.appendChild(container);

  try {
    const canvas = await safeHtml2Canvas(container, {
      scale: 2, // 2x for sharp text
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      windowWidth: 794
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.95);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true
    });

    const pdfWidth = pdf.internal.pageSize.getWidth(); // 210mm
    const pdfHeight = pdf.internal.pageSize.getHeight(); // 297mm
    const imgHeight = (canvas.height * pdfWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, imgHeight, undefined, 'FAST');
    heightLeft -= pdfHeight;

    while (heightLeft > 0) {
      position -= pdfHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, imgHeight, undefined, 'FAST');
      heightLeft -= pdfHeight;
    }

    pdf.save(filename);
  } finally {
    document.body.removeChild(container);
  }
}
