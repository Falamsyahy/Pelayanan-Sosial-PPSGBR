import * as XLSX from 'xlsx';
import { Client } from '../types';

export interface ExportExcelOptions {
  angkatanFilter?: string | string[];
  customFilename?: string;
}

/**
 * Memeriksa apakah seorang anak binaan terdaftar pada angkatan yang dipilih
 */
export function isClientInAngkatanFilter(client: Client, filter?: string | string[]): boolean {
  if (!filter || filter === 'all') return true;
  if (Array.isArray(filter)) {
    if (filter.length === 0 || filter.includes('all')) return true;
    const clientAng = (client.formData?.angkatan || '').trim();
    if (!clientAng) return false;
    
    // Pecah jika anak terdaftar di multi-angkatan (misal "Angkatan II, Angkatan III" atau "Angkatan II dan Angkatan III")
    const clientTokens = clientAng.split(/,|\bdan\b|&|\/|;/i).map(s => s.toLowerCase().trim()).filter(Boolean);
    const filterTokens = filter.map(s => s.toLowerCase().trim()).filter(Boolean);

    return clientTokens.some(ct =>
      filterTokens.some(ft => {
        if (ct === ft) return true;
        // Strip out year suffix if present (e.g. "angkatan ii - 2026" -> "angkatan ii")
        const ctBase = ct.split('-')[0].trim();
        const ftBase = ft.split('-')[0].trim();
        return ctBase === ftBase || ct.includes(ftBase) || ft.includes(ctBase);
      })
    );
  } else {
    const single = filter.toLowerCase().trim();
    if (!single || single === 'all') return true;
    const clientAng = (client.formData?.angkatan || '').toLowerCase().trim();
    if (!clientAng) return false;
    const clientTokens = clientAng.split(/,|\bdan\b|&|\/|;/i).map(s => s.trim()).filter(Boolean);
    const singleBase = single.split('-')[0].trim();
    return clientTokens.some(ct => {
      const ctBase = ct.split('-')[0].trim();
      return ctBase === singleBase || ct.includes(singleBase) || single.includes(ctBase);
    });
  }
}

/**
 * Mengekspor daftar anak binaan ke dalam format Excel (.xlsx) resmi dengan kolom Angkatan Masuk
 */
export function exportClientsToExcel(clients: Client[], options?: ExportExcelOptions): void {
  if (!clients || clients.length === 0) {
    throw new Error('Tidak ada data anak untuk diekspor.');
  }

  // Filter berdasarkan angkatan (bisa single string atau array multi-angkatan)
  let targetClients = clients;

  if (options?.angkatanFilter) {
    targetClients = clients.filter(c => isClientInAngkatanFilter(c, options.angkatanFilter));
  }

  if (targetClients.length === 0) {
    throw new Error('Tidak ada data anak pada angkatan yang dipilih.');
  }

  // 1. Sheet Utama: Rekap Data Lengkap Anak
  const headers = [
    "No",
    "ID Registrasi",
    "Angkatan Masuk",                  // KOLOM ANGKATAN DITAMPILKAN UTAMA
    "Nama Lengkap Anak Binaan",
    "Status Anak Binaan",
    "Jurusan Vokasi",
    "NIK / No. Identitas",
    "Jenis Kelamin",
    "Usia (Thn)",
    "Tempat Lahir",
    "Tanggal Lahir",
    "Agama",
    "Kabupaten/Kota Asal Daerah",
    "Kecamatan",
    "Desa/Kelurahan",
    "Alamat Lengkap",
    "Pendidikan Terakhir",
    "Kondisi Pendidikan Terakhir",
    "Status Pengasuhan",
    "Nama Ayah Kandung",
    "Status Keberadaan Ayah",
    "Nama Ibu Kandung",
    "Status Keberadaan Ibu",
    "Nama Wali",
    "Hubungan Wali",
    "Alasan Bersama Wali",
    "Kontak Telepon / WA",
    "Pekerjaan Orang Tua / Wali",
    "Penghasilan Bulanan",
    "Bantuan Sosial (PKH/dll)",
    "Status BPJS",
    "Desil DTKS",
    "Histori Pekerja Anak",
    "Riwayat Tinggal di Jalan",
    "Tingkat Risiko (Red Flag)",
    "Riwayat Penyakit",
    "Jalur Pendidikan Aftercare",
    "Nama Sekolah / PKBM Aftercare",
    "Status Keaktifan Belajar",
    "Total Sesi Intervensi"
  ];

  const rows: any[][] = [headers];

  targetClients.forEach((c, index) => {
    const fd = c.formData || ({} as any);
    const logs = c.pelaksanaanIntervensi || [];

    // Pastikan Angkatan memiliki nilai fallback yang informatif
    const angkatanMasuk = fd.angkatan && fd.angkatan.trim() 
      ? fd.angkatan 
      : 'Angkatan I - 2026';

    rows.push([
      index + 1,
      c.id,
      angkatanMasuk,                    // KOLOM ANGKATAN
      c.nama,
      c.status,
      fd.jurusan || '-',
      fd.noIdentitas ? `'${fd.noIdentitas}` : '-', // Kutip agar angka NIK tidak terpotong oleh Excel
      c.gender,
      c.umur || '-',
      fd.tempatLahir || '-',
      fd.tanggalLahir || '-',
      fd.agama || '-',
      fd.kabupatenKota || '-',
      fd.kecamatan || '-',
      fd.desa || '-',
      fd.alamat || '-',
      fd.pendidikan || '-',
      fd.kondisiPendidikan || '-',
      fd.tipePengasuh || 'Orang Tua',
      fd.namaAyah || (fd.tipePengasuh !== 'Wali' ? fd.namaWali : '-'),
      fd.statusAyah || 'Masih Hidup',
      fd.namaIbu || '-',
      fd.statusIbu || 'Masih Hidup',
      fd.tipePengasuh === 'Wali' ? (fd.namaWali || '-') : '-',
      fd.tipePengasuh === 'Wali' ? (fd.hubunganWali || '-') : '-',
      fd.tipePengasuh === 'Wali' ? (fd.alasanDenganWali || '-') : '-',
      fd.kontakWali ? `'${fd.kontakWali}` : '-',
      fd.pekerjaanOrangTua || '-',
      fd.penghasilanBulanan || '-',
      fd.bantuan || '-',
      fd.bpjs || '-',
      fd.desil || '-',
      `${fd.pekerjaAnak || 'Tidak'} ${fd.pekerjaAnakTahun ? `(${fd.pekerjaAnakTahun})` : ''}`,
      fd.tinggalJalan || 'Tidak',
      fd.tingkatRisiko || 'Rendah',
      c.riwayatPenyakit && c.riwayatPenyakit.length > 0 ? c.riwayatPenyakit.join('; ') : 'Tidak Ada',
      fd.aftercareStatusPendidikan || '-',
      fd.aftercareNamaSekolah || '-',
      fd.aftercareStatusSiswa || '-',
      logs.length
    ]);
  });

  const wsMain = XLSX.utils.aoa_to_sheet(rows);

  // Lebar kolom terformat rapi
  wsMain['!cols'] = [
    { wch: 5 },  // No
    { wch: 15 }, // ID
    { wch: 22 }, // Angkatan Masuk (PROMINENT)
    { wch: 32 }, // Nama
    { wch: 22 }, // Status
    { wch: 22 }, // Jurusan
    { wch: 20 }, // NIK
    { wch: 14 }, // Gender
    { wch: 10 }, // Usia
    { wch: 16 }, // Tempat Lahir
    { wch: 14 }, // Tanggal Lahir
    { wch: 12 }, // Agama
    { wch: 25 }, // Kab/Kota
    { wch: 20 }, // Kecamatan
    { wch: 20 }, // Desa
    { wch: 35 }, // Alamat
    { wch: 18 }, // Pendidikan
    { wch: 30 }, // Kondisi Pendidikan
    { wch: 24 }, // Wali
    { wch: 16 }, // Kontak
    { wch: 22 }, // Pekerjaan
    { wch: 18 }, // Penghasilan
    { wch: 24 }, // Bansos
    { wch: 20 }, // BPJS
    { wch: 12 }, // Desil
    { wch: 22 }, // Pekerja Anak
    { wch: 20 }, // Tinggal di Jalan
    { wch: 15 }, // Tingkat Risiko
    { wch: 25 }, // Riwayat Penyakit
    { wch: 25 }, // Jalur Aftercare
    { wch: 30 }, // Sekolah/PKBM
    { wch: 25 }, // Status Belajar
    { wch: 16 }  // Total Sesi
  ];

  // 2. Sheet Rekapitulasi Per Angkatan
  const angkatanMap: Record<string, { total: number; aktif: number; selesai: number; dropOut: number; referal: number }> = {};
  
  targetClients.forEach(c => {
    const a = (c.formData?.angkatan && c.formData.angkatan.trim()) ? c.formData.angkatan.trim() : 'Angkatan I - 2026';
    if (!angkatanMap[a]) {
      angkatanMap[a] = { total: 0, aktif: 0, selesai: 0, dropOut: 0, referal: 0 };
    }
    angkatanMap[a].total++;
    if (c.status === 'Kasus Aktif') angkatanMap[a].aktif++;
    else if (c.status === 'Terminasi (Selesai)') angkatanMap[a].selesai++;
    else if (c.status === 'Drop Out') angkatanMap[a].dropOut++;
    else if (c.status === 'Referal (Rujukan)') angkatanMap[a].referal++;
  });

  const summaryHeaders = [
    "No",
    "Angkatan / Gelombang Masuk",
    "Total Anak Binaan",
    "Kasus Aktif (Dalam Asrama)",
    "Terminasi (Lulus / Mandiri)",
    "Drop Out",
    "Referal (Rujukan Luar)"
  ];

  const summaryRows: any[][] = [summaryHeaders];
  Object.keys(angkatanMap).sort().forEach((ang, idx) => {
    const s = angkatanMap[ang];
    summaryRows.push([
      idx + 1,
      ang,
      s.total,
      s.aktif,
      s.selesai,
      s.dropOut,
      s.referal
    ]);
  });

  const wsSummary = XLSX.utils.aoa_to_sheet(summaryRows);
  wsSummary['!cols'] = [
    { wch: 6 },
    { wch: 26 },
    { wch: 18 },
    { wch: 25 },
    { wch: 25 },
    { wch: 12 },
    { wch: 22 }
  ];

  // 3. Buat Workbook Excel
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, wsMain, "Rekap_Data_Anak");
  XLSX.utils.book_append_sheet(wb, wsSummary, "Ringkasan_Per_Angkatan");

  // Format Nama File
  const dateStr = new Date().toISOString().split('T')[0];
  let filename = `Rekap_Data_Anak_RSA_Jabar_${dateStr}.xlsx`;
  
  if (options?.customFilename) {
    filename = options.customFilename;
  } else if (options?.angkatanFilter) {
    if (Array.isArray(options.angkatanFilter) && options.angkatanFilter.length > 0 && !options.angkatanFilter.includes('all')) {
      const cleanParts = options.angkatanFilter.map(a => 
        a.split('-')[0].trim().replace(/[^a-zA-Z0-9_-]/g, '_')
      );
      const label = cleanParts.length === 1 
        ? cleanParts[0]
        : cleanParts.join('_dan_');
      filename = `Rekap_Data_Anak_${label}_${dateStr}.xlsx`;
    } else if (typeof options.angkatanFilter === 'string' && options.angkatanFilter !== 'all') {
      const safeAngkatan = options.angkatanFilter.split('-')[0].trim().replace(/[^a-zA-Z0-9_-]/g, '_');
      filename = `Rekap_Data_Anak_${safeAngkatan}_${dateStr}.xlsx`;
    }
  }

  XLSX.writeFile(wb, filename);
}
