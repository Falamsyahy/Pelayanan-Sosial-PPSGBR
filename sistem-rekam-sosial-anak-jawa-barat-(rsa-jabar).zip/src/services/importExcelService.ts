import * as XLSX from 'xlsx';
import { Client, ClientStatus, RiskLevel } from '../types';
import { generateClientId } from '../utils/clientIdGenerator';

export interface ExcelImportRowPreview {
  id: string;
  nama: string;
  gender: 'Laki-laki' | 'Perempuan';
  umur: number;
  angkatan: string;
  jurusan: string;
  kabupatenKota: string;
  nik: string;
  status: ClientStatus;
  isValid: boolean;
  validationError?: string;
}

export interface ExcelImportResult {
  clients: Client[];
  previews: ExcelImportRowPreview[];
  totalRows: number;
  validCount: number;
  invalidCount: number;
  errors: string[];
}

/**
 * Normalisasi format tanggal dari berbagai kemungkinan input Excel (serial number atau string)
 */
function parseExcelDate(val: any): string {
  if (!val) return '';

  // Jika Excel menyimpan tanggal sebagai number serial (misal 44204)
  if (typeof val === 'number') {
    try {
      const dateObj = XLSX.SSF.parse_date_code(val);
      if (dateObj) {
        const y = String(dateObj.y).padStart(4, '0');
        const m = String(dateObj.m).padStart(2, '0');
        const d = String(dateObj.d).padStart(2, '0');
        return `${y}-${m}-${d}`;
      }
    } catch (_) {}
  }

  const str = String(val).trim();
  // Format DD/MM/YYYY atau DD-MM-YYYY
  const dmyMatch = str.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
  if (dmyMatch) {
    const d = dmyMatch[1].padStart(2, '0');
    const m = dmyMatch[2].padStart(2, '0');
    const y = dmyMatch[3];
    return `${y}-${m}-${d}`;
  }

  // Format YYYY-MM-DD
  const ymdMatch = str.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
  if (ymdMatch) {
    const y = ymdMatch[1];
    const m = ymdMatch[2].padStart(2, '0');
    const d = ymdMatch[3].padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  return str;
}

/**
 * Normalisasi Jenis Kelamin
 */
function normalizeGender(val: any): 'Laki-laki' | 'Perempuan' {
  const s = String(val || '').toLowerCase().trim();
  if (s.startsWith('p') || s.includes('wanita') || s.includes('perempuan') || s === 'f') {
    return 'Perempuan';
  }
  return 'Laki-laki';
}

/**
 * Normalisasi Status Anak
 */
function normalizeStatus(val: any): ClientStatus {
  const s = String(val || '').trim();
  if (!s) return 'Kasus Aktif';
  if (s.toLowerCase().includes('calon') || s.toLowerCase().includes('seleksi')) {
    return 'Calon Klien (Proses Seleksi)';
  }
  if (s.toLowerCase().includes('terminasi') || s.toLowerCase().includes('selesai') || s.toLowerCase().includes('lulus')) {
    return 'Terminasi (Selesai)';
  }
  if (s.toLowerCase().includes('drop')) {
    return 'Drop Out';
  }
  if (s.toLowerCase().includes('referal') || s.toLowerCase().includes('rujukan')) {
    return 'Referal (Rujukan)';
  }
  return 'Kasus Aktif';
}

/**
 * Normalisasi Tingkat Risiko
 */
function normalizeRisk(val: any): RiskLevel {
  const s = String(val || '').toLowerCase().trim();
  if (s.includes('kritis')) return 'Kritis';
  if (s.includes('tinggi')) return 'Tinggi';
  if (s.includes('sedang')) return 'Sedang';
  return 'Rendah';
}

/**
 * Helper untuk mencocokkan header kolom secara toleran (case-insensitive & whitespace-tolerant)
 */
function findRowValue(row: Record<string, any>, possibleKeys: string[]): any {
  const rowKeys = Object.keys(row);
  for (const target of possibleKeys) {
    const normalizedTarget = target.toLowerCase().replace(/[^a-z0-9]/g, '');
    for (const key of rowKeys) {
      const normalizedKey = key.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (normalizedKey === normalizedTarget || normalizedKey.includes(normalizedTarget)) {
        const val = row[key];
        if (val !== undefined && val !== null && String(val).trim() !== '') {
          return val;
        }
      }
    }
  }
  return '';
}

/**
 * Mengurai file Excel (.xlsx / .xls) menjadi daftar Client valid
 */
export async function parseExcelClientFile(
  file: File,
  existingClients: Client[] = []
): Promise<ExcelImportResult> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });

  if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
    throw new Error('Berkas Excel tidak memiliki sheet yang valid.');
  }

  // Pilih sheet pertama atau sheet dengan nama 'Rekap_Data_Anak' / 'Data_Anak'
  const sheetName = workbook.SheetNames.find(n => 
    n.toLowerCase().includes('rekap') || 
    n.toLowerCase().includes('anak') || 
    n.toLowerCase().includes('import') ||
    n.toLowerCase().includes('data')
  ) || workbook.SheetNames[0];

  const worksheet = workbook.Sheets[sheetName];
  if (!worksheet) {
    throw new Error(`Lembar kerja "${sheetName}" tidak ditemukan.`);
  }

  // Ambil baris sebagai objek JSON (header sebagai properti)
  const rawRows: Record<string, any>[] = XLSX.utils.sheet_to_json(worksheet, {
    defval: '',
    raw: false, // Convert format agar teks tetap terbaca sesuai tampilan
  });

  if (!rawRows || rawRows.length === 0) {
    throw new Error('Lembar kerja Excel kosong, tidak ditemukan baris data anak.');
  }

  const clients: Client[] = [];
  const previews: ExcelImportRowPreview[] = [];
  const errors: string[] = [];
  const batchUsedIds = new Set<string>();
  const allKnownIds = new Set<string>(existingClients.map((c) => c.id).filter(Boolean));

  rawRows.forEach((row, index) => {
    const rowNum = index + 2; // +1 untuk 1-based, +1 untuk header row

    // 1. Ekstraksi Nama (Wajib)
    const rawNama = String(findRowValue(row, [
      'Nama Lengkap Anak Binaan',
      'Nama Lengkap',
      'Nama Anak',
      'Nama',
      'Full Name',
      'Nama Klien'
    ])).trim();

    if (!rawNama) {
      // Lewati baris kosong tanpa nama
      return;
    }

    // 2. Ekstraksi ID Registrasi (dibaca dulu, auto-generate dilakukan setelah daerah & angkatan diekstrak)
    let rawId = String(findRowValue(row, [
      'ID Registrasi',
      'ID',
      'No Registrasi',
      'Kode Anak',
      'ID Klien'
    ])).trim();

    // 3. Ekstraksi Biodata Dasar
    const gender = normalizeGender(findRowValue(row, ['Jenis Kelamin', 'Gender', 'JK', 'Sex']));
    
    const rawTanggalLahir = parseExcelDate(findRowValue(row, [
      'Tanggal Lahir',
      'Tgl Lahir',
      'Birth Date',
      'Tgl_Lahir'
    ]));

    let umur = parseInt(String(findRowValue(row, ['Usia (Thn)', 'Usia', 'Umur', 'Age'])), 10);
    if (isNaN(umur) || umur <= 0) {
      if (rawTanggalLahir) {
        const birthYear = new Date(rawTanggalLahir).getFullYear();
        if (!isNaN(birthYear) && birthYear > 1990) {
          umur = Math.max(0, new Date().getFullYear() - birthYear);
        } else {
          umur = 15; // default wajar remaja
        }
      } else {
        umur = 15;
      }
    }

    const angkatan = String(findRowValue(row, [
      'Angkatan Masuk',
      'Angkatan',
      'Gelombang',
      'Batch',
      'Tahun Angkatan'
    ])).trim() || 'Angkatan I - 2026';

    const jurusan = String(findRowValue(row, [
      'Jurusan Vokasi',
      'Jurusan',
      'Kejuruan',
      'Vokasi',
      'Keahlian'
    ])).trim() || 'Otomotif';

    const status = normalizeStatus(findRowValue(row, [
      'Status Anak Binaan',
      'Status',
      'Status Kasus',
      'Status Binaan'
    ]));

    // 4. Wilayah & Alamat
    const kabupatenKota = String(findRowValue(row, [
      'Kabupaten/Kota Asal Daerah',
      'Kabupaten/Kota',
      'Kabupaten',
      'Kota',
      'Kab/Kota'
    ])).trim() || 'Kota Bandung';

    if (!rawId || batchUsedIds.has(rawId)) {
      rawId = generateClientId({
        kabupatenKota,
        angkatan,
        existingClients: [...existingClients, ...clients],
        usedIds: allKnownIds,
      });
    }
    batchUsedIds.add(rawId);
    allKnownIds.add(rawId);

    const kecamatan = String(findRowValue(row, ['Kecamatan', 'Kec'])).trim();
    const desa = String(findRowValue(row, ['Desa/Kelurahan', 'Desa', 'Kelurahan'])).trim();
    const alamat = String(findRowValue(row, ['Alamat Lengkap', 'Alamat'])).trim();
    const tempatLahir = String(findRowValue(row, ['Tempat Lahir', 'Tmp Lahir'])).trim() || kabupatenKota;
    const agama = String(findRowValue(row, ['Agama', 'Religion'])).trim() || 'Islam';

    // 5. NIK & Kontak
    let rawNik = String(findRowValue(row, [
      'NIK / No. Identitas',
      'NIK',
      'No Identitas',
      'Nomor Induk Kependudukan',
      'No KTP/KIA'
    ])).trim();
    // Hilangkan kutip depan yang biasa ada di ekspor Excel
    if (rawNik.startsWith("'")) rawNik = rawNik.slice(1).trim();

    let kontakWali = String(findRowValue(row, ['Kontak Wali', 'No HP', 'No Telepon', 'Kontak'])).trim();
    if (kontakWali.startsWith("'")) kontakWali = kontakWali.slice(1).trim();

    const rawTipePengasuh = String(findRowValue(row, ['Status Pengasuhan', 'Tipe Pengasuh', 'Pengasuhan'])).toLowerCase();
    const tipePengasuh: 'Orang Tua' | 'Wali' = rawTipePengasuh.includes('wali') ? 'Wali' : 'Orang Tua';

    const namaAyah = String(findRowValue(row, ['Nama Ayah Kandung', 'Nama Ayah', 'Ayah'])).trim();
    const statusAyah = String(findRowValue(row, ['Status Ayah', 'Kondisi Ayah'])).trim() || 'Masih Hidup';
    const pekerjaanAyah = String(findRowValue(row, ['Pekerjaan Ayah'])).trim();

    const namaIbu = String(findRowValue(row, ['Nama Ibu Kandung', 'Nama Ibu', 'Ibu'])).trim();
    const statusIbu = String(findRowValue(row, ['Status Ibu', 'Kondisi Ibu'])).trim() || 'Masih Hidup';
    const pekerjaanIbu = String(findRowValue(row, ['Pekerjaan Ibu'])).trim();

    const namaWali = String(findRowValue(row, ['Nama Orang Tua / Wali', 'Nama Wali', 'Orang Tua', 'Wali'])).trim() || namaAyah || namaIbu;
    const hubunganWali = String(findRowValue(row, ['Hubungan Wali', 'Hubungan dengan Wali', 'Hubungan'])).trim();
    const alasanDenganWali = String(findRowValue(row, ['Alasan Bersama Wali', 'Alasan Tinggal Bersama Wali', 'Alasan'])).trim();

    const pekerjaanWali = String(findRowValue(row, ['Pekerjaan Orang Tua', 'Pekerjaan', 'Pekerjaan Wali'])).trim();
    const penghasilan = String(findRowValue(row, ['Penghasilan Bulanan', 'Penghasilan'])).trim() || '< Rp 1 Juta';
    const bantuan = String(findRowValue(row, ['Bantuan Sosial (PKH/dll)', 'Bantuan Sosial', 'Bantuan'])).trim() || 'Tidak Menerima';
    const bpjs = String(findRowValue(row, ['Status BPJS', 'BPJS'])).trim() || 'BPJS PBI (Pemerintah)';
    const desil = String(findRowValue(row, ['Desil DTKS', 'Desil'])).trim() || 'Desil 1';

    // 6. Asesmen Risiko & Kasus
    const tingkatRisiko = normalizeRisk(findRowValue(row, [
      'Tingkat Risiko (Red Flag)',
      'Tingkat Risiko',
      'Risiko',
      'Risk Level'
    ]));

    const rawPenyakit = String(findRowValue(row, [
      'Riwayat Penyakit',
      'Penyakit',
      'Riwayat Medis'
    ])).trim();

    const riwayatPenyakit: string[] = rawPenyakit && rawPenyakit !== '-' && rawPenyakit.toLowerCase() !== 'tidak ada'
      ? rawPenyakit.split(/;|,|\band\b/i).map(s => s.trim()).filter(Boolean)
      : [];

    const pendidikan = String(findRowValue(row, ['Pendidikan Terakhir', 'Pendidikan'])).trim() || 'SMP / Sederajat';
    const kondisiPendidikan = String(findRowValue(row, ['Kondisi Pendidikan Terakhir', 'Kondisi Pendidikan'])).trim();
    const pekerjaAnak = String(findRowValue(row, ['Histori Pekerja Anak', 'Pekerja Anak'])).trim() || 'Tidak Pernah';
    const tinggalJalan = String(findRowValue(row, ['Riwayat Tinggal di Jalan', 'Tinggal di Jalan'])).trim() || 'Tidak Pernah';

    // Aftercare
    const aftercareStatusPendidikan = String(findRowValue(row, ['Jalur Pendidikan Aftercare', 'Aftercare Pendidikan'])).trim() || 'Pendidikan Non-Formal (PKBM)';
    const aftercareNamaSekolah = String(findRowValue(row, ['Nama Sekolah / PKBM Aftercare', 'Nama Sekolah Aftercare'])).trim();
    const aftercareStatusSiswa = String(findRowValue(row, ['Status Keaktifan Belajar', 'Status Belajar Aftercare'])).trim();

    // 7. Konstruksi Model Client
    const client: Client = {
      id: rawId,
      nama: rawNama,
      umur,
      gender,
      status,
      peksosEmail: 'peksos@jabarprov.go.id',
      riwayatPenyakit,
      pelaksanaanIntervensi: [],
      formData: {
        kabupatenKota,
        kecamatan,
        desa,
        alamat,
        tempatLahir,
        tanggalLahir: rawTanggalLahir,
        agama,
        angkatan,
        statusIdentitas: rawNik ? 'Memiliki KTP/KIA' : 'Belum Memiliki',
        noIdentitas: rawNik,
        pendidikan,
        jurusan,
        putusSekolah: kondisiPendidikan.toLowerCase().includes('putus') ? 'Ya, Sedang Putus Sekolah' : 'Tidak (Lancar)',
        kondisiPendidikan,
        tipePengasuh,
        namaAyah,
        statusAyah: statusAyah as any,
        pekerjaanAyah,
        namaIbu,
        statusIbu: statusIbu as any,
        pekerjaanIbu,
        namaWali,
        hubunganWali,
        alasanDenganWali,
        kontakWali,
        pekerjaanOrangTua: pekerjaanWali || pekerjaanAyah,
        penghasilanBulanan: penghasilan,
        desil,
        bantuan,
        bpjs,
        pekerjaAnak,
        pekerjaAnakTahun: '',
        tinggalJalan,
        tingkatRisiko,
        asesmenKronologi: `Data anak dimasukkan melalui impor Excel resmi pada ${new Date().toLocaleDateString('id-ID')}. Asesmen awal disesuaikan dengan data dukung lapangan.`,
        asesmenBiologis: `Kondisi fisik anak terpantau secara visual sehat. Riwayat penyakit: ${riwayatPenyakit.join(', ') || 'Bebas keluhan'}.`,
        asesmenPsikologis: 'Memerlukan orientasi lingkungan asrama dan observasi penyesuaian diri berkelanjutan.',
        asesmenSosial: `Berasal dari ${kabupatenKota}. Perlu bimbingan sosialisasi kelompok teman sebaya di asrama binaan.`,
        asesmenSpiritual: `Menganut agama ${agama}, diarahkan mengikuti bimbingan mental spiritual rutin.`,
        asesmenKebutuhanDasar: 'Kebutuhan asrama, seragam praktik vokasi, dan nutrisi gizi terjamin di balai.',
        asesmenPemecahanMasalah: 'Menempuh pendekatan pembinaan terpadu vokasional.',
        asesmenPeranSosial: 'Sebagai peserta binaan aktif program pemulihan sosial.',
        asesmenPemaknaan: '',
        intervensiTujuan: `Meningkatkan keterampilan vokasi jurusan ${jurusan} serta kemandirian sosial anak secara terukur.`,
        intervensiStrategi: 'Pelatihan vokasional bengkel/kejuruan, bimbingan kelompok asrama, dan supervisi casework peksos.',
        aiIntervensiTujuan: '',
        aiIntervensiStrategi: '',
        aiIntervensiIndikator: [],
        aiIntervensiGeneratedAt: '',
        evaluasiPerkembangan: 'Peserta binaan baru tercatat dalam rekam medis sosial.',
        evaluasiHambatan: '',
        terminasiStatus: status,
        terminasiAlasan: '',
        aftercareStatusPendidikan,
        aftercareNamaSekolah,
        aftercareStatusSiswa,
        aftercareFollowUps: [],
        pancaKarakterHistory: [],
        seleksiCatatan: 'Diimpor dari berkas Excel resmi.',
        seleksiKeputusan: status
      }
    };

    clients.push(client);

    previews.push({
      id: rawId,
      nama: rawNama,
      gender,
      umur,
      angkatan,
      jurusan,
      kabupatenKota,
      nik: rawNik || '-',
      status,
      isValid: true
    });
  });

  return {
    clients,
    previews,
    totalRows: rawRows.length,
    validCount: clients.length,
    invalidCount: rawRows.length - clients.length,
    errors
  };
}

/**
 * Membuat dan mengunduh Template Excel Standar Import Data Anak Binaan
 */
export function downloadExcelImportTemplate(): void {
  const headers = [
    "No",
    "ID Registrasi",
    "Angkatan Masuk",
    "Nama Lengkap Anak Binaan",
    "Status Anak Binaan",
    "Jurusan Vokasi",
    "NIK / No. Identitas",
    "Jenis Kelamin",
    "Usia (Thn)",
    "Tempat Lahir",
    "Tanggal Lahir",
    "Agama",
    "Kabupaten/Kota Asal Daerah",
    "Kecamatan",
    "Desa/Kelurahan",
    "Alamat Lengkap",
    "Pendidikan Terakhir",
    "Kondisi Pendidikan Terakhir",
    "Nama Orang Tua / Wali",
    "Kontak Wali",
    "Pekerjaan Orang Tua",
    "Penghasilan Bulanan",
    "Bantuan Sosial (PKH/dll)",
    "Status BPJS",
    "Desil DTKS",
    "Histori Pekerja Anak",
    "Riwayat Tinggal di Jalan",
    "Tingkat Risiko (Red Flag)",
    "Riwayat Penyakit"
  ];

  const sampleRows: any[][] = [
    headers,
    [
      1,
      "1-1-II-2026",
      "Angkatan II - 2026",
      "Muhammad Rizky Pratama",
      "Kasus Aktif",
      "Otomotif",
      "'3204011204100001",
      "Laki-laki",
      16,
      "Bandung",
      "2010-04-12",
      "Islam",
      "Kabupaten Bandung",
      "Majalaya",
      "Majakerta",
      "Kp. Sukamaju RT 03/RW 04",
      "SMP / Sederajat",
      "Lulus SMP, Terkendala Biaya Lanjut SMA",
      "Dedi Suryadi",
      "'081320456789",
      "Buruh Tani",
      "< Rp 1 Juta",
      "PKH (Program Keluarga Harapan)",
      "BPJS PBI (Pemerintah)",
      "Desil 1",
      "Ya, Pernah Bekerja (2024)",
      "Tidak Pernah",
      "Sedang",
      "Asma Ringan"
    ],
    [
      2,
      "1-8-II-2026",
      "Angkatan II - 2026",
      "Dewi Lestari",
      "Kasus Aktif",
      "Menjahit / Konveksi",
      "'3205025508110002",
      "Perempuan",
      15,
      "Garut",
      "2011-08-15",
      "Islam",
      "Kabupaten Garut",
      "Tarogong Kaler",
      "Rancabango",
      "Jl. Cipanas Baru No. 12",
      "SMP / Sederajat",
      "Putus Sekolah Kelas 2 SMP",
      "Kokom Komalasari",
      "'085721345678",
      "Pedagang Asongan",
      "< Rp 1 Juta",
      "BPNT (Sembako)",
      "BPJS PBI (Pemerintah)",
      "Desil 1",
      "Pernah Membantu Orang Tua Jualan",
      "Tidak Pernah",
      "Rendah",
      "Tidak Ada"
    ],
    [
      3,
      "", // Contoh ID dikosongkan agar digenerate otomatis oleh sistem
      "Angkatan II - 2026",
      "Fajar Ramadhan",
      "Calon Klien (Proses Seleksi)",
      "Komputer & Jaringan",
      "'3273012011090003",
      "Laki-laki",
      17,
      "Kota Bandung",
      "2009-11-20",
      "Islam",
      "Kota Bandung",
      "Kiaracondong",
      "Babakan Surabaya",
      "Jl. Stasiun Lama No. 45",
      "SMA / Sederajat",
      "Rentan Putus Sekolah Kelas 2 SMK",
      "Asep Hendra",
      "'082122334455",
      "Pengemudi Ojek Online",
      "Rp 1 - 2 Juta",
      "KIP (Kartu Indonesia Pintar)",
      "BPJS Non-PBI",
      "Desil 2",
      "Tidak Pernah",
      "Tidak Pernah",
      "Rendah",
      "Alergi Dingin"
    ]
  ];

  const ws = XLSX.utils.aoa_to_sheet(sampleRows);

  ws['!cols'] = [
    { wch: 5 },  // No
    { wch: 16 }, // ID
    { wch: 22 }, // Angkatan
    { wch: 30 }, // Nama
    { wch: 22 }, // Status
    { wch: 22 }, // Jurusan
    { wch: 22 }, // NIK
    { wch: 14 }, // Gender
    { wch: 10 }, // Usia
    { wch: 16 }, // Tempat Lahir
    { wch: 14 }, // Tgl Lahir
    { wch: 12 }, // Agama
    { wch: 25 }, // Kab/Kota
    { wch: 20 }, // Kecamatan
    { wch: 20 }, // Desa
    { wch: 32 }, // Alamat
    { wch: 18 }, // Pendidikan
    { wch: 30 }, // Kondisi
    { wch: 24 }, // Wali
    { wch: 18 }, // Kontak
    { wch: 22 }, // Pekerjaan
    { wch: 18 }, // Penghasilan
    { wch: 24 }, // Bansos
    { wch: 22 }, // BPJS
    { wch: 12 }, // Desil
    { wch: 24 }, // Pekerja Anak
    { wch: 20 }, // Jalan
    { wch: 16 }, // Risiko
    { wch: 24 }  // Penyakit
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Format_Import_Anak");

  XLSX.writeFile(wb, "Template_Import_Data_Anak_RSA_Jabar.xlsx");
}
