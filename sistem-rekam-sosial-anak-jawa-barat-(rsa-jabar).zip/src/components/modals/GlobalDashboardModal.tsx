import React, { useState, useMemo } from 'react';
import { 
  X, 
  Search, 
  Users, 
  ExternalLink, 
  BarChart3, 
  PieChart as PieIcon, 
  MapPin, 
  AlertTriangle, 
  ShieldAlert, 
  TrendingUp, 
  GraduationCap, 
  Filter,
  CheckCircle2,
  FileSpreadsheet
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from 'recharts';
import { Client, RiskLevel } from '../../types';
import { exportClientsToExcel } from '../../services/exportExcelService';

interface GlobalDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  clients: Client[];
  onSelectClient: (id: string) => void;
  allAngkatanList: string[];
}

// Color palettes for Recharts
const RISK_COLORS: Record<RiskLevel, string> = {
  Rendah: '#10b981', // Emerald
  Sedang: '#f59e0b', // Amber
  Tinggi: '#f97316', // Orange
  Kritis: '#ef4444', // Red
};

const CASE_PALETTE = [
  '#0284c7', // Sky
  '#6366f1', // Indigo
  '#8b5cf6', // Purple
  '#ec4899', // Pink
  '#f59e0b', // Amber
  '#10b981', // Emerald
  '#14b8a6', // Teal
];

const ANGKATAN_PALETTE = [
  '#0284c7', // Sky
  '#10b981', // Emerald
  '#8b5cf6', // Purple
  '#f59e0b', // Amber
  '#ec4899', // Pink
];

// Helper for custom Recharts tooltip
const CustomChartTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900/95 text-white p-3 rounded-xl shadow-xl text-xs border border-slate-700 backdrop-blur-xs min-w-[150px]">
        {label && <p className="font-bold text-slate-200 border-b border-slate-700 pb-1 mb-1.5">{label}</p>}
        {payload.map((item: any, index: number) => (
          <div key={`tooltip-${index}`} className="flex items-center justify-between gap-3 py-0.5">
            <span className="flex items-center gap-1.5 text-slate-300">
              <span
                className="w-2.5 h-2.5 rounded-full inline-block"
                style={{ backgroundColor: item.color || item.fill || '#38bdf8' }}
              />
              {item.name}:
            </span>
            <span className="font-bold text-white font-mono">{item.value} {item.unit || ''}</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export const GlobalDashboardModal: React.FC<GlobalDashboardModalProps> = ({
  isOpen,
  onClose,
  clients,
  onSelectClient,
  allAngkatanList,
}) => {
  // Navigation tabs: 'visual' or 'table'
  const [activeView, setActiveView] = useState<'visual' | 'table'>('visual');

  // Filters
  const [selectedAngkatan, setSelectedAngkatan] = useState<string>('');
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterRisk, setFilterRisk] = useState<string>('');

  // 1. Data subset filtered by Angkatan for Visualizations
  const vizClients = useMemo(() => {
    if (!selectedAngkatan) return clients;
    return clients.filter((c) => (c?.formData?.angkatan || '').includes(selectedAngkatan));
  }, [clients, selectedAngkatan]);

  // 2. Data filtered for Table search
  const tableFilteredList = useMemo(() => {
    return clients.filter((c) => {
      if (!c) return false;
      const q = search.toLowerCase();
      const matchSearch =
        !q ||
        (c.nama || '').toLowerCase().includes(q) ||
        (c.id || '').toLowerCase().includes(q) ||
        ((c.formData?.kabupatenKota || '').toLowerCase().includes(q)) ||
        ((c.formData?.jurusan || '').toLowerCase().includes(q));

      const matchAngkatan = !selectedAngkatan || (c.formData?.angkatan || '').includes(selectedAngkatan);
      const matchStatus = !filterStatus || c.status === filterStatus;
      const matchRisk = !filterRisk || c.formData?.tingkatRisiko === filterRisk;

      return matchSearch && matchAngkatan && matchStatus && matchRisk;
    });
  }, [clients, search, selectedAngkatan, filterStatus, filterRisk]);

  // 3. Analytics: Risk Level Distribution
  const riskChartData = useMemo(() => {
    const counts: Record<RiskLevel, number> = {
      Rendah: 0,
      Sedang: 0,
      Tinggi: 0,
      Kritis: 0,
    };

    vizClients.forEach((c) => {
      const r = c?.formData?.tingkatRisiko || 'Rendah';
      if (counts[r] !== undefined) {
        counts[r]++;
      } else {
        counts['Rendah']++;
      }
    });

    const total = vizClients.length || 1;
    return [
      { name: 'Rendah', value: counts.Rendah, percent: Math.round((counts.Rendah / total) * 100), color: RISK_COLORS.Rendah },
      { name: 'Sedang', value: counts.Sedang, percent: Math.round((counts.Sedang / total) * 100), color: RISK_COLORS.Sedang },
      { name: 'Tinggi', value: counts.Tinggi, percent: Math.round((counts.Tinggi / total) * 100), color: RISK_COLORS.Tinggi },
      { name: 'Kritis', value: counts.Kritis, percent: Math.round((counts.Kritis / total) * 100), color: RISK_COLORS.Kritis },
    ].filter((item) => item.value > 0);
  }, [vizClients]);

  // 4. Analytics: Case Types / Social Problems Classification
  const caseTypeChartData = useMemo(() => {
    const counts: Record<string, number> = {
      'Pekerja Anak & Jalanan': 0,
      'Putus Sekolah / Belajar': 0,
      'Disfungsi Keluarga / Yatim': 0,
      'Anak Terlantar / Rentan Pengasuhan': 0,
      'Trauma & Krisis Emosi': 0,
      'Kerentanan Ekonomi (Desil 1)': 0,
    };

    vizClients.forEach((c) => {
      const fd = c?.formData || ({} as any);
      const text = `${fd.asesmenKronologi || ''} ${fd.kondisiPendidikan || ''} ${c?.status || ''} ${fd.asesmenPemaknaan || ''}`.toLowerCase();

      // Detection rules (Non-ABH focused)
      if (fd.pekerjaAnak === 'Ya, Pernah Bekerja' || fd.tinggalJalan === 'Ya, Pernah' || text.includes('ngamen') || text.includes('jalanan') || text.includes('kuli') || text.includes('bengkel')) {
        counts['Pekerja Anak & Jalanan']++;
      }
      if ((fd.putusSekolah || '').includes('Ya') || text.includes('putus sekolah') || text.includes('berhenti sekolah') || text.includes('mangkir')) {
        counts['Putus Sekolah / Belajar']++;
      }
      if (text.includes('cerai') || text.includes('orang tua tiri') || text.includes('yatim') || text.includes('broken home')) {
        counts['Disfungsi Keluarga / Yatim']++;
      }
      if (text.includes('terlantar') || text.includes('penelantaran') || text.includes('tanpa wali') || text.includes('pengasuhan') || text.includes('satgas')) {
        counts['Anak Terlantar / Rentan Pengasuhan']++;
      }
      if (fd.tingkatRisiko === 'Kritis' || text.includes('trauma') || text.includes('ptsd') || text.includes('memar') || text.includes('kekerasan')) {
        counts['Trauma & Krisis Emosi']++;
      }
      if (fd.desil === 'Desil 1' || fd.penghasilanBulanan === '< Rp 1 Juta') {
        counts['Kerentanan Ekonomi (Desil 1)']++;
      }
    });

    return Object.entries(counts)
      .map(([name, count], index) => ({
        name,
        jumlah: count,
        color: CASE_PALETTE[index % CASE_PALETTE.length],
      }))
      .filter((d) => d.jumlah > 0)
      .sort((a, b) => b.jumlah - a.jumlah);
  }, [vizClients]);

  // 5. Analytics: Regional Distribution per Angkatan (Kabupaten / Kota Jawa Barat)
  const regionChartData = useMemo(() => {
    // Top regions
    const regionCounts: Record<string, number> = {};
    vizClients.forEach((c) => {
      const reg = c?.formData?.kabupatenKota?.trim() || 'Lainnya / Tidak Tercatat';
      regionCounts[reg] = (regionCounts[reg] || 0) + 1;
    });

    return Object.entries(regionCounts)
      .map(([region, count]) => ({
        region: region.replace('Kabupaten ', 'Kab. ').replace('Kota ', 'Kota '),
        fullRegion: region,
        jumlah: count,
      }))
      .sort((a, b) => b.jumlah - a.jumlah)
      .slice(0, 8); // Top 8 regions for neat layout
  }, [vizClients]);

  // 6. Analytics: Trend per Angkatan (Cohort Intake & Status Progression)
  const cohortTrendData = useMemo(() => {
    const cohorts = allAngkatanList.length > 0 ? allAngkatanList : ['Angkatan I - 2026'];
    
    return cohorts.map((ang) => {
      const cohortMembers = clients.filter((c) => (c?.formData?.angkatan || '').includes(ang));
      
      const aktif = cohortMembers.filter((c) => (c?.status || '').includes('Aktif')).length;
      const seleksi = cohortMembers.filter((c) => (c?.status || '').includes('Seleksi') || (c?.status || '').includes('Calon')).length;
      const terminasi = cohortMembers.filter((c) => (c?.status || '').includes('Terminasi')).length;
      const rujukanLainnya = cohortMembers.filter((c) => (c?.status || '').includes('Referal') || (c?.status || '').includes('Drop') || (c?.status || '').includes('Tolak')).length;

      return {
        angkatan: ang.replace('Angkatan ', 'Angk. '),
        fullAngkatan: ang,
        'Kasus Aktif': aktif,
        'Proses Seleksi': seleksi,
        'Selesai Terminasi': terminasi,
        'Rujukan / Drop': rujukanLainnya,
        total: cohortMembers.length,
      };
    });
  }, [clients, allAngkatanList]);

  // Summary Metrics
  const summaryMetrics = useMemo(() => {
    const total = vizClients.length;
    const active = vizClients.filter((c) => (c?.status || '').includes('Aktif')).length;
    const highRisk = vizClients.filter((c) => c?.formData?.tingkatRisiko === 'Kritis' || c?.formData?.tingkatRisiko === 'Tinggi').length;
    const completed = vizClients.filter((c) => (c?.status || '').includes('Terminasi')).length;

    // Top origin
    const regCount: Record<string, number> = {};
    vizClients.forEach((c) => {
      if (c?.formData?.kabupatenKota) {
        regCount[c.formData.kabupatenKota] = (regCount[c.formData.kabupatenKota] || 0) + 1;
      }
    });
    let topRegion = '-';
    let maxCount = 0;
    Object.entries(regCount).forEach(([r, count]) => {
      if (count > maxCount) {
        maxCount = count;
        topRegion = r.replace('Kabupaten ', 'Kab. ');
      }
    });

    return { total, active, highRisk, completed, topRegion, topRegionCount: maxCount };
  }, [vizClients]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-xs no-print">
      <div className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-linear-to-r from-sky-700 via-cyan-700 to-indigo-800 px-6 py-4 flex items-center justify-between text-white shrink-0 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center border border-white/20 shadow-xs">
              <BarChart3 className="w-5 h-5 text-sky-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base sm:text-lg">Dashboard Global & Visualisasi Data</h3>
                <span className="text-[10px] bg-white/20 text-white font-bold px-2 py-0.5 rounded-full border border-white/30">
                  BPSS Jawa Barat
                </span>
              </div>
              <p className="text-xs text-sky-100">
                Analitik Tren Jenis Kasus, Pemetaan Tingkat Risiko, & Persebaran Wilayah Binaan
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition"
            title="Tutup Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* View Switcher & Global Angkatan Selector */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shrink-0">
          {/* Navigation Pill Buttons */}
          <div className="flex items-center bg-slate-200/80 p-1 rounded-xl">
            <button
              onClick={() => setActiveView('visual')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition shadow-2xs ${
                activeView === 'visual'
                  ? 'bg-white text-sky-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Grafik & Analisis Visual</span>
            </button>
            <button
              onClick={() => setActiveView('table')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition shadow-2xs ${
                activeView === 'table'
                  ? 'bg-white text-sky-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Tabel Kasus ({tableFilteredList.length})</span>
            </button>
          </div>

          {/* Angkatan Filter (Active on both views) */}
          <div className="flex items-center gap-2 w-full sm:w-auto flex-wrap sm:flex-nowrap">
            <span className="text-xs font-bold text-slate-600 flex items-center gap-1 whitespace-nowrap">
              <Filter className="w-3.5 h-3.5 text-sky-600" />
              Filter Angkatan:
            </span>
            <select
              value={selectedAngkatan}
              onChange={(e) => setSelectedAngkatan(e.target.value)}
              className="rounded-xl border border-slate-300 py-1.5 px-3 text-xs bg-white text-slate-800 font-bold focus:ring-2 focus:ring-sky-500 shadow-2xs w-full sm:w-56"
            >
              <option value="">Semua Angkatan (Kumulatif)</option>
              {allAngkatanList.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </select>

            {/* Tombol Ekspor Excel Sesuai Filter */}
            <button
              type="button"
              onClick={() => {
                exportClientsToExcel(vizClients, {
                  angkatanFilter: selectedAngkatan || 'all'
                });
              }}
              className="bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs px-3.5 py-1.5 rounded-xl shadow-2xs transition flex items-center justify-center gap-1.5 shrink-0 w-full sm:w-auto"
              title="Unduh seluruh data anak sesuai filter saat ini ke file Excel lengkap dengan kolom Angkatan Masuk"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
              <span>Unduh Excel ({vizClients.length})</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto flex-1 p-4 sm:p-6 space-y-6 bg-slate-50/50">
          
          {/* Top KPI Metrics Row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center border border-sky-100 shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] font-semibold text-slate-500">Total Anak Binaan</p>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-xl font-black text-slate-900">{summaryMetrics.total}</span>
                  <span className="text-[10px] text-slate-400">jiwa</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-100 shrink-0">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] font-semibold text-slate-500">Kasus Aktif Berjalan</p>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-xl font-black text-blue-700">{summaryMetrics.active}</span>
                  <span className="text-[10px] text-blue-500 font-medium">binaan asrama</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100 shrink-0">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] font-semibold text-slate-500">Risiko Kritis & Tinggi</p>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-xl font-black text-rose-700">{summaryMetrics.highRisk}</span>
                  <span className="text-[10px] text-rose-500 font-medium">butuh atensi</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100 shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] font-semibold text-slate-500">Asal Wilayah Terbanyak</p>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-sm font-black text-slate-800 truncate max-w-[130px]" title={summaryMetrics.topRegion}>
                    {summaryMetrics.topRegion}
                  </span>
                  <span className="text-[10px] text-emerald-600 font-bold">({summaryMetrics.topRegionCount})</span>
                </div>
              </div>
            </div>
          </div>

          {/* VIEW 1: VISUAL CHARTS (RECHARTS) */}
          {activeView === 'visual' && (
            <div className="space-y-6">
              
              {/* Row 1: Case Type Trend (BarChart) & Risk Distribution (PieChart) */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* 1. Tren Jenis Kasus & Masalah Utama (7 Cols) */}
                <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col">
                  <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                        <BarChart3 className="w-4 h-4 text-sky-600" />
                        Tren Jenis Kasus & Masalah Sosial
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Frekuensi klasifikasi kerentanan anak binaan {selectedAngkatan ? `(${selectedAngkatan})` : '(Seluruh Angkatan)'}
                      </p>
                    </div>
                    <span className="text-[10px] font-semibold bg-sky-50 text-sky-700 px-2.5 py-1 rounded-md border border-sky-200">
                      Recharts BarChart
                    </span>
                  </div>

                  <div className="h-64 sm:h-72 w-full">
                    {caseTypeChartData.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-xs text-slate-400 italic">
                        Tidak ada data kasus untuk angkatan ini.
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={caseTypeChartData}
                          layout="vertical"
                          margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                          <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                          <YAxis
                            type="category"
                            dataKey="name"
                            tick={{ fontSize: 11, fill: '#334155', fontWeight: 600 }}
                            width={140}
                          />
                          <RechartsTooltip content={<CustomChartTooltip />} />
                          <Bar
                            dataKey="jumlah"
                            name="Jumlah Anak"
                            radius={[0, 6, 6, 0]}
                            barSize={20}
                          >
                            {caseTypeChartData.map((entry, index) => (
                              <Cell key={`cell-case-${index}`} fill={entry.color} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-[11px] text-slate-500">
                    <span>*Terdeteksi dari variabel asesmen, riwayat jalanan, putus sekolah, & dimensi psikososial.</span>
                    <span className="font-semibold text-slate-700">Total Identifikasi: {caseTypeChartData.reduce((acc, c) => acc + c.jumlah, 0)} kasus</span>
                  </div>
                </div>

                {/* 2. Distribusi Tingkat Risiko (5 Cols) */}
                <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col">
                  <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                        <PieIcon className="w-4 h-4 text-amber-500" />
                        Distribusi Tingkat Risiko (Red Flag)
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Proporsi tingkat kedaruratan & intervensi
                      </p>
                    </div>
                    <span className="text-[10px] font-semibold bg-amber-50 text-amber-800 px-2 py-0.5 rounded-md border border-amber-200">
                      Donut Chart
                    </span>
                  </div>

                  <div className="h-56 sm:h-64 w-full relative">
                    {riskChartData.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-xs text-slate-400 italic">
                        Tidak ada data risiko.
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <RechartsTooltip content={<CustomChartTooltip />} />
                          <Pie
                            data={riskChartData}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            innerRadius={55}
                            outerRadius={85}
                            paddingAngle={3}
                          >
                            {riskChartData.map((entry, index) => (
                              <Cell key={`cell-risk-${index}`} fill={entry.color} stroke="#ffffff" strokeWidth={2} />
                            ))}
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                    )}
                  </div>

                  {/* Custom Legend with Count Badges */}
                  <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-100 text-xs">
                    <div className="flex items-center justify-between p-2 rounded-lg bg-emerald-50/70 border border-emerald-200">
                      <span className="flex items-center gap-1.5 font-bold text-emerald-900 text-[11px]">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Rendah
                      </span>
                      <span className="font-mono font-black text-emerald-800">
                        {riskChartData.find((r) => r.name === 'Rendah')?.value || 0}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded-lg bg-amber-50/70 border border-amber-200">
                      <span className="flex items-center gap-1.5 font-bold text-amber-900 text-[11px]">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Sedang
                      </span>
                      <span className="font-mono font-black text-amber-800">
                        {riskChartData.find((r) => r.name === 'Sedang')?.value || 0}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded-lg bg-orange-50/70 border border-orange-200">
                      <span className="flex items-center gap-1.5 font-bold text-orange-900 text-[11px]">
                        <span className="w-2.5 h-2.5 rounded-full bg-orange-500" /> Tinggi
                      </span>
                      <span className="font-mono font-black text-orange-800">
                        {riskChartData.find((r) => r.name === 'Tinggi')?.value || 0}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded-lg bg-rose-50/70 border border-rose-200">
                      <span className="flex items-center gap-1.5 font-bold text-rose-900 text-[11px]">
                        <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> Kritis
                      </span>
                      <span className="font-mono font-black text-rose-800">
                        {riskChartData.find((r) => r.name === 'Kritis')?.value || 0}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Row 2: Regional Distribution (BarChart) & Cohort Trend (Stacked AreaChart) */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* 3. Persebaran Wilayah Asal Kabupaten/Kota (7 Cols) */}
                <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col">
                  <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                        <MapPin className="w-4 h-4 text-emerald-600" />
                        Persebaran Wilayah Asal Anak Binaan
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Kabupaten / Kota Jawa Barat penerima manfaat {selectedAngkatan ? `(${selectedAngkatan})` : '(Top 8 Daerah)'}
                      </p>
                    </div>
                    <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-md border border-emerald-200">
                      Grafik Wilayah
                    </span>
                  </div>

                  <div className="h-64 sm:h-72 w-full">
                    {regionChartData.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-xs text-slate-400 italic">
                        Tidak ada data wilayah untuk filter ini.
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={regionChartData}
                          margin={{ top: 10, right: 20, left: -10, bottom: 25 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis
                            dataKey="region"
                            angle={-20}
                            textAnchor="end"
                            interval={0}
                            height={45}
                            tick={{ fontSize: 10, fill: '#475569' }}
                          />
                          <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                          <RechartsTooltip content={<CustomChartTooltip />} />
                          <Bar
                            dataKey="jumlah"
                            name="Jumlah Anak"
                            fill="#0ea5e9"
                            radius={[6, 6, 0, 0]}
                            barSize={26}
                          >
                            {regionChartData.map((_, index) => (
                              <Cell
                                key={`cell-reg-${index}`}
                                fill={index === 0 ? '#0284c7' : index === 1 ? '#0ea5e9' : '#38bdf8'}
                              />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>

                {/* 4. Tren Status & Progresi Kasus per Angkatan (5 Cols) */}
                <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col">
                  <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                        <TrendingUp className="w-4 h-4 text-indigo-600" />
                        Tren Kasus per Angkatan
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Progresi intake, intervensi, & terminasi antar angkatan
                      </p>
                    </div>
                    <span className="text-[10px] font-semibold bg-indigo-50 text-indigo-800 px-2 py-0.5 rounded-md border border-indigo-200">
                      Komparasi Angkatan
                    </span>
                  </div>

                  <div className="h-64 sm:h-72 w-full">
                    {cohortTrendData.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-xs text-slate-400 italic">
                        Belum ada riwayat angkatan.
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={cohortTrendData}
                          margin={{ top: 10, right: 10, left: -15, bottom: 20 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="angkatan" tick={{ fontSize: 10, fill: '#475569' }} />
                          <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                          <RechartsTooltip content={<CustomChartTooltip />} />
                          <Legend wrapperStyle={{ fontSize: 10, paddingTop: 10 }} />
                          <Bar dataKey="Kasus Aktif" stackId="a" fill="#0284c7" />
                          <Bar dataKey="Proses Seleksi" stackId="a" fill="#f59e0b" />
                          <Bar dataKey="Selesai Terminasi" stackId="a" fill="#10b981" />
                          <Bar dataKey="Rujukan / Drop" stackId="a" fill="#f43f5e" />
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* VIEW 2: DETAILED DATA TABLE */}
          {activeView === 'table' && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
              
              {/* Filter Sub-Toolbar */}
              <div className="p-4 border-b border-slate-200 bg-slate-50/80 flex flex-col md:flex-row gap-2.5">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Cari berdasarkan Nama, ID Klien, Kabupaten/Kota, atau Jurusan..."
                    className="w-full rounded-xl border border-slate-300 py-2 pl-9 pr-3 text-xs bg-white focus:ring-2 focus:ring-sky-500"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value)}
                    className="rounded-xl border border-slate-300 py-2 px-3 text-xs bg-white text-slate-700 font-semibold focus:ring-2 focus:ring-sky-500"
                  >
                    <option value="">Semua Status Kasus</option>
                    <option value="Calon Klien (Proses Seleksi)">Calon Klien</option>
                    <option value="Kasus Aktif">Kasus Aktif</option>
                    <option value="Terminasi (Selesai)">Terminasi Selesai</option>
                    <option value="Referal (Rujukan)">Referal</option>
                    <option value="Drop Out">Drop Out</option>
                    <option value="Ditolak (Tidak Memenuhi Syarat)">Ditolak</option>
                  </select>

                  <select
                    value={filterRisk}
                    onChange={(e) => setFilterRisk(e.target.value)}
                    className="rounded-xl border border-slate-300 py-2 px-3 text-xs bg-white text-slate-700 font-semibold focus:ring-2 focus:ring-sky-500"
                  >
                    <option value="">Semua Tingkat Risiko</option>
                    <option value="Rendah">Risiko Rendah</option>
                    <option value="Sedang">Risiko Sedang</option>
                    <option value="Tinggi">Risiko Tinggi</option>
                    <option value="Kritis">Risiko Kritis</option>
                  </select>
                </div>
              </div>

              {/* Table Body */}
              <div className="overflow-x-auto max-h-[50vh]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold uppercase tracking-wider border-b border-slate-200 sticky top-0 z-10">
                    <tr>
                      <th className="py-3 px-3 w-12 text-center">No</th>
                      <th className="py-3 px-3">Nama Lengkap & Gender</th>
                      <th className="py-3 px-3">ID Kasus</th>
                      <th className="py-3 px-3">Asal Kab/Kota</th>
                      <th className="py-3 px-3">Angkatan</th>
                      <th className="py-3 px-3">Jurusan Vokasional</th>
                      <th className="py-3 px-3 text-center">Tingkat Risiko</th>
                      <th className="py-3 px-3 text-center">Status Binaan</th>
                      <th className="py-3 px-3 w-20 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {tableFilteredList.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-12 text-center text-xs text-slate-500 italic">
                          Tidak ditemukan data anak yang cocok dengan kata kunci atau filter yang dipilih.
                        </td>
                      </tr>
                    ) : (
                      tableFilteredList.map((c, idx) => {
                        const fd = c?.formData || ({} as any);
                        const risk = fd.tingkatRisiko || 'Rendah';
                        const cStatus = c?.status || 'Calon Klien';

                        let badgeClass = 'bg-slate-100 text-slate-800';
                        if (cStatus.includes('Aktif')) badgeClass = 'bg-sky-50 text-sky-800 border-sky-300';
                        else if (cStatus.includes('Terminasi')) badgeClass = 'bg-emerald-50 text-emerald-800 border-emerald-300';
                        else if (cStatus.includes('Seleksi')) badgeClass = 'bg-amber-50 text-amber-800 border-amber-300';
                        else if (cStatus.includes('Drop') || cStatus.includes('Tolak')) badgeClass = 'bg-rose-50 text-rose-800 border-rose-300';

                        let riskBadge = 'bg-emerald-50 text-emerald-700 border-emerald-200';
                        if (risk === 'Sedang') riskBadge = 'bg-amber-50 text-amber-700 border-amber-200';
                        else if (risk === 'Tinggi') riskBadge = 'bg-orange-50 text-orange-700 border-orange-200';
                        else if (risk === 'Kritis') riskBadge = 'bg-rose-50 text-rose-700 border-rose-300 animate-pulse';

                        return (
                          <tr key={c.id} className="hover:bg-slate-50/80 transition">
                            <td className="py-2.5 px-3 text-center font-mono text-slate-500">{idx + 1}</td>
                            <td className="py-2.5 px-3">
                              <span className="font-bold text-slate-900 block">{c.nama}</span>
                              <span className="text-[11px] text-slate-500 font-normal">
                                {c.umur} tahun • {c.gender}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 font-mono text-xs text-slate-600">{c.id}</td>
                            <td className="py-2.5 px-3 text-slate-700">{fd.kabupatenKota || '-'}</td>
                            <td className="py-2.5 px-3 font-medium text-slate-700">{fd.angkatan || '-'}</td>
                            <td className="py-2.5 px-3 font-semibold text-cyan-800">{fd.jurusan || '-'}</td>
                            <td className="py-2.5 px-3 text-center">
                              <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${riskBadge}`}>
                                {risk}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-center">
                              <span className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold border ${badgeClass}`}>
                                {c.status}
                              </span>
                              {fd.aftercareStatusPendidikan && (
                                <span className="block mt-1 text-[9px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded truncate max-w-[130px] mx-auto" title={`${fd.aftercareStatusPendidikan} - ${fd.aftercareNamaSekolah || ''}`}>
                                  🎓 {fd.aftercareStatusPendidikan.includes('PKBM') ? 'PKBM' : 'Formal'}: {fd.aftercareJenjang ? fd.aftercareJenjang.split(' ')[0] : 'Aktif'}
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-center">
                              <button
                                onClick={() => {
                                  onSelectClient(c.id);
                                  onClose();
                                }}
                                className="bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200 px-2.5 py-1 rounded-lg text-xs font-bold inline-flex items-center gap-1 shadow-2xs transition"
                                title="Buka Profil & Rekam Kasus"
                              >
                                <ExternalLink className="w-3 h-3" /> Buka
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* Table Footer */}
              <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500 px-4">
                <span>Menampilkan <strong>{tableFilteredList.length}</strong> dari total <strong>{clients.length}</strong> anak binaan</span>
                <span className="hidden sm:inline">Klik tombol <strong>Buka</strong> untuk membuka langsung formulir rekam medis/sosial anak</span>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Data tersinkronisasi langsung dengan Firebase & Penyimpanan Lokal BPSS.</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition shadow-2xs"
          >
            Tutup Dashboard
          </button>
        </div>

      </div>
    </div>
  );
};
