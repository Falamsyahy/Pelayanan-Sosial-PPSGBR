import React, { useRef, useState } from 'react';
import { 
  X, 
  FolderLock, 
  Upload, 
  FileText, 
  Image, 
  File, 
  Trash2, 
  Eye, 
  Download, 
  CheckCircle2, 
  AlertCircle,
  Filter,
  Plus,
  HardDrive,
  Sparkles,
  ShieldCheck,
  Archive
} from 'lucide-react';
import { Client, ClientAttachmentItem, ClientAttachmentCategory } from '../../types';

interface DigitalAttachmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: Client;
  onSaveAttachment: (item: ClientAttachmentItem) => Promise<{ success: boolean; error?: string }>;
  onDeleteAttachment: (id: string) => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
  peksosName?: string;
}

const CATEGORIES: ClientAttachmentCategory[] = [
  'Kartu Keluarga (KK)',
  'Akta Kelahiran',
  'KTP / KIA Anak',
  'Surat Rujukan / Rekomendasi Dinsos',
  'Surat Pernyataan / Izin Binaan Orang Tua',
  'Surat Bebas Narkoba / Skrining Medis',
  'Ijazah / Rapor Terakhir',
  'Sertifikat Pelatihan Vokasi',
  'Foto Dokumentasi Home Visit',
  'Dokumen Pendukung Lainnya',
];

function inferMimeType(file: File): string {
  if (file.type && file.type.trim()) return file.type.trim();
  const lower = file.name.toLowerCase();
  if (lower.endsWith('.pdf')) return 'application/pdf';
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.webp')) return 'image/webp';
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  return 'application/octet-stream';
}

function isValidBase64DataUrl(dataUrl: string): boolean {
  const match = (dataUrl || '').match(/^data:([^;]+);base64,([A-Za-z0-9+/=]+)$/);
  return Boolean(match && match[2] && match[2].length >= 16);
}

/**
 * Kompresi otomatis gambar berbasis HTML5 Canvas di sisi peramban.
 * Menjamin foto kamera HP (3-4MB) diperkecil menjadi ~60-150KB namun tetap tajam
 * dan terbaca jelas sehingga aman disimpan di Firestore (maks 1MB) & LocalStorage.
 */
async function processAttachmentFile(
  file: File
): Promise<{ dataUrl: string; sizeKb: number; tipeFile: string }> {
  if (!file || file.size === 0) {
    throw new Error('Berkas kosong (0 bytes) atau tidak terbaca.');
  }

  const detectedMime = inferMimeType(file);
  const isImage =
    detectedMime.startsWith('image/') ||
    /\.(png|jpe?g|webp|gif|bmp)$/i.test(file.name);

  if (!isImage) {
    // Batas maksimal PDF agar tetap muat setelah encode Base64 (+33%) di Firestore 1MB
    if (file.size > 700 * 1024) {
      throw new Error(
        `Ukuran file PDF "${file.name}" (${Math.round(file.size / 1024)} KB) terlalu besar untuk penyimpanan langsung (maks. 700 KB agar aman di Firestore 1 MB). Silakan kompres PDF atau unggah sebagai Foto/JPG.`
      );
    }

    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = String(e.target?.result || '');
        if (!isValidBase64DataUrl(result)) {
          reject(new Error('Gagal membaca isi berkas ke format Base64 yang valid.'));
          return;
        }
        const sizeBytes = Math.round((result.split(',')[1].length * 3) / 4);
        resolve({
          dataUrl: result,
          sizeKb: Math.max(1, Math.round(sizeBytes / 1024)),
          tipeFile: detectedMime,
        });
      };
      reader.onerror = () => reject(new Error('Gagal membaca berkas dari perangkat Anda.'));
      reader.readAsDataURL(file);
    });
  }

  return new Promise((resolve, reject) => {
    const img = new window.Image();
    const objectUrl = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      if (!img.width || !img.height) {
        reject(new Error('Dimensi gambar tidak valid atau berkas gambar rusak.'));
        return;
      }

      const renderAt = (maxDim: number, quality: number): { dataUrl: string; sizeKb: number } => {
        let width = img.width;
        let height = img.height;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, width);
        canvas.height = Math.max(1, height);
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          throw new Error('Browser tidak mendukung pemrosesan kanvas gambar.');
        }
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        const sizeBytes = Math.round(((compressedDataUrl.split(',')[1] || '').length * 3) / 4);
        return {
          dataUrl: compressedDataUrl,
          sizeKb: Math.max(1, Math.round(sizeBytes / 1024)),
        };
      };

      try {
        // Kompresi adaptif agar ukuran base64 aman (< 220 KB) untuk dokumen Firestore
        let output = renderAt(1400, 0.78);
        if (output.sizeKb > 220) output = renderAt(1200, 0.65);
        if (output.sizeKb > 220) output = renderAt(1000, 0.52);

        if (!isValidBase64DataUrl(output.dataUrl)) {
          reject(new Error('Hasil kompresi gambar kosong. Silakan pilih file gambar lain (JPG/PNG).'));
          return;
        }

        resolve({
          dataUrl: output.dataUrl,
          sizeKb: output.sizeKb,
          tipeFile: 'image/jpeg',
        });
      } catch (err: any) {
        reject(new Error(err?.message || 'Gagal mengompresi gambar.'));
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(
        new Error(
          'Format gambar tidak dapat dibaca browser (jika dari iPhone/HEIC, silakan ubah ke JPG/PNG terlebih dahulu).'
        )
      );
    };
    img.src = objectUrl;
  });
}

interface PendingAttachment {
  namaBerkas: string;
  tipeFile: string;
  ukuranKb: number;
  dataUrl: string;
}

export const DigitalAttachmentModal: React.FC<DigitalAttachmentModalProps> = ({
  isOpen,
  onClose,
  client,
  onSaveAttachment,
  onDeleteAttachment,
  onShowToast,
  peksosName = 'Pekerja Sosial',
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedCategory, setSelectedCategory] = useState<ClientAttachmentCategory>('Kartu Keluarga (KK)');
  const [keterangan, setKeterangan] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [previewItem, setPreviewItem] = useState<ClientAttachmentItem | null>(null);
  const [pendingFile, setPendingFile] = useState<PendingAttachment | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [statusFeedback, setStatusFeedback] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  if (!isOpen) return null;

  const attachments = client.berkasDigital || [];

  const filteredAttachments = filterCategory === 'all'
    ? attachments
    : attachments.filter(a => a.kategori === filterCategory);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setStatusFeedback(null);

    if (file.size === 0) {
      const msg = 'File yang dipilih berukuran 0 bytes (kosong). Silakan pilih berkas yang valid.';
      setStatusFeedback({ type: 'error', text: msg });
      onShowToast(msg, 'error');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    // Validate size (max 8MB sebelum kompresi untuk gambar)
    if (file.size > 8 * 1024 * 1024) {
      const msg = 'Ukuran berkas melebihi batas maksimal 8 MB.';
      setStatusFeedback({ type: 'error', text: msg });
      onShowToast(msg, 'error');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setIsProcessing(true);
    try {
      const { dataUrl, sizeKb, tipeFile } = await processAttachmentFile(file);

      setPendingFile({
        namaBerkas: file.name,
        tipeFile,
        ukuranKb: sizeKb,
        dataUrl,
      });
      setStatusFeedback({
        type: 'success',
        text: `Berkas "${file.name}" (${sizeKb} KB) siap disimpan! Klik tombol "Simpan Berkas" di bawah untuk mengarsipkan.`,
      });
    } catch (err: any) {
      const errMsg = err instanceof Error ? err.message : 'Format berkas tidak didukung atau gagal dibaca.';
      setPendingFile(null);
      setStatusFeedback({ type: 'error', text: errMsg });
      onShowToast(errMsg, 'error');
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleConfirmSave = async () => {
    setStatusFeedback(null);
    setIsSaving(true);
    try {
      const candidateItem: ClientAttachmentItem = {
        id: pendingFile ? `att-${Date.now()}` : '',
        namaBerkas: pendingFile?.namaBerkas || '',
        kategori: selectedCategory,
        tipeFile: pendingFile?.tipeFile || '',
        ukuranKb: pendingFile?.ukuranKb || 0,
        dataUrl: pendingFile?.dataUrl || '',
        tanggalUnggah: new Date().toISOString().split('T')[0],
        diunggahOleh: peksosName,
        ...(keterangan.trim() ? { keterangan: keterangan.trim() } : {}),
      };

      const res = await onSaveAttachment(candidateItem);
      if (res.success) {
        const savedName = candidateItem.namaBerkas;
        setPendingFile(null);
        setKeterangan('');
        setStatusFeedback({
          type: 'success',
          text: `Berhasil! Berkas "${savedName}" (${selectedCategory}) telah tersimpan ke rekam klien.`,
        });
      } else {
        setStatusFeedback({
          type: 'error',
          text: res.error || 'Gagal menyimpan berkas. Pastikan file telah dipilih dan tidak kosong.',
        });
      }
    } catch (err: any) {
      const msg = err?.message || 'Terjadi kesalahan saat menyimpan berkas.';
      setStatusFeedback({ type: 'error', text: msg });
      onShowToast(msg, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Unduh seluruh arsip berkas klien dalam format paket JSON
  const handleExportAllAttachments = () => {
    if (attachments.length === 0) {
      onShowToast('Belum ada berkas untuk dicadangkan.', 'error');
      return;
    }

    const payload = {
      clientId: client.id,
      namaKlien: client.nama,
      tanggalEkspor: new Date().toISOString(),
      jumlahBerkas: attachments.length,
      berkasDigital: attachments
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Cadangan_Berkas_${(client.nama || 'Klien').replace(/\s+/g, '_')}_${client.id}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast(`Cadangan ${attachments.length} berkas berhasil diunduh ke komputer Anda!`, 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="bg-linear-to-r from-sky-800 via-sky-700 to-indigo-700 px-6 py-4 flex items-center justify-between text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white font-bold">
              <FolderLock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base leading-tight">
                  Lampiran Berkas Digital Klien (Digital Case Files)
                </h3>
                <span className="bg-sky-400/30 text-white border border-sky-300/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  Dokumen Pendukung
                </span>
              </div>
              <p className="text-xs text-sky-100 mt-0.5">
                Klien: <strong>{client.nama}</strong> ({client.id}) — Arsip digital aman terhubung dengan rekam medis sosial
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {attachments.length > 0 && (
              <button
                type="button"
                onClick={handleExportAllAttachments}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-white/20 hover:bg-white/30 text-white rounded-lg transition shadow-2xs"
                title="Cadangkan seluruh berkas digital klien ke file arsip JSON di komputer Anda"
              >
                <Archive className="w-3.5 h-3.5 text-sky-200" />
                <span>Cadangkan Arsip ({attachments.length})</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition"
              title="Tutup Modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          
          {/* Banner Penjelasan Arsitektur Penyimpanan Bebas Hosting */}
          <div className="bg-sky-50 border border-sky-200 rounded-xl p-3.5 flex items-start gap-3 text-sky-950 shadow-2xs">
            <HardDrive className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-sky-900">Arsitektur Penyimpanan Terpadu & Bebas Biaya Hosting Eksternal</span>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-1.5 py-0.2 rounded border border-emerald-300">
                  Otomatis Kompresi Gambar
                </span>
              </div>
              <p className="text-sky-800 leading-relaxed text-[11px]">
                Dokumen digital (KK, Akta, Surat, Foto) disimpan terenkripsi (Base64) langsung di dalam database rekam sosial klien & peramban lokal tanpa memerlukan biaya sewa server hosting terpisah. Sistem secara otomatis mengompresi foto kamera HP berukuran besar (3–4 MB) menjadi sangat ringkas (~60–150 KB) dengan teks tetap tajam, sehingga hemat kuota dan aman di Cloud Firestore (maks 1 MB/dokumen).
              </p>
            </div>
          </div>
          
          {/* Upload Card */}
          <div className="bg-linear-to-br from-sky-50/70 to-indigo-50/50 p-4 sm:p-5 rounded-2xl border-2 border-sky-200 space-y-3.5 shadow-xs">
            <div className="flex items-center justify-between border-b border-sky-200/80 pb-2.5">
              <span className="text-xs font-bold text-sky-950 flex items-center gap-2">
                <Upload className="w-4 h-4 text-sky-600" />
                <span>Unggah Dokumen / Foto Bukti Pendukung Baru:</span>
              </span>
              <span className="text-[10px] text-slate-500 font-medium">Gambar (maks 8 MB, dikompresi) / PDF (maks 700 KB)</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Kategori Dokumen Resmi:
                </label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value as ClientAttachmentCategory)}
                  className="w-full rounded-lg border border-slate-300 py-2 px-3 text-xs bg-white text-slate-800 font-bold focus:ring-2 focus:ring-sky-500"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Keterangan / Catatan Dokumen (Opsional):
                </label>
                <input
                  type="text"
                  value={keterangan}
                  onChange={(e) => setKeterangan(e.target.value)}
                  placeholder="Contoh: Scan KK terbaru dari Disdukcapil..."
                  className="w-full rounded-lg border border-slate-300 py-2 px-3 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            <input
              type="file"
              ref={fileInputRef}
              accept="image/*,application/pdf,.pdf,.jpg,.jpeg,.png,.webp"
              onChange={handleFileChange}
              className="hidden"
            />

            {/* Pratinjau Berkas Terpilih Sebelum Disimpan */}
            {pendingFile && (
              <div className="bg-white border border-emerald-300 rounded-xl p-3 flex items-center justify-between gap-3 shadow-2xs">
                <div className="flex items-center gap-3 min-w-0">
                  {pendingFile.tipeFile.startsWith('image/') ? (
                    <img
                      src={pendingFile.dataUrl}
                      alt={pendingFile.namaBerkas}
                      className="w-12 h-12 rounded-lg object-cover border border-slate-200 shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center shrink-0">
                      <FileText className="w-6 h-6 text-rose-600" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-900 truncate">{pendingFile.namaBerkas}</p>
                    <p className="text-[11px] text-emerald-700 font-semibold">
                      {selectedCategory} • {pendingFile.ukuranKb} KB (Base64 Valid)
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setPendingFile(null);
                    setStatusFeedback(null);
                  }}
                  className="text-xs text-rose-600 hover:text-rose-800 font-bold px-2 py-1 rounded hover:bg-rose-50 shrink-0"
                >
                  Batalkan
                </button>
              </div>
            )}

            {/* Inline Status Feedback */}
            {statusFeedback && (
              <div
                className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                  statusFeedback.type === 'error'
                    ? 'bg-rose-50 border-rose-300 text-rose-900'
                    : 'bg-emerald-50 border-emerald-300 text-emerald-900'
                }`}
              >
                {statusFeedback.type === 'error' ? (
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                )}
                <span className="font-semibold leading-relaxed">{statusFeedback.text}</span>
              </div>
            )}

            <div className="pt-1 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <p className="text-[11px] text-slate-500 italic">
                1. Pilih file foto/PDF KK → 2. Klik <strong>Simpan Berkas</strong> agar tersimpan permanen.
              </p>
              <div className="flex items-center gap-2 self-end sm:self-auto">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isProcessing || isSaving}
                  className="bg-white hover:bg-sky-50 text-sky-700 border border-sky-300 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-2xs transition disabled:opacity-50"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isProcessing ? 'Memproses...' : pendingFile ? 'Ganti File' : 'Pilih Berkas'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleConfirmSave}
                  disabled={isProcessing || isSaving}
                  className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition disabled:opacity-50"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isSaving ? 'Menyimpan...' : 'Simpan Berkas'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Filter & Daftar Dokumen */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-200 pb-2">
              <span className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-sky-600" />
                <span>Dokumen Tersimpan ({attachments.length}):</span>
              </span>

              {/* Filter Kategori */}
              <div className="flex items-center gap-2 text-xs">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="rounded-lg border border-slate-200 py-1 px-2.5 text-xs bg-white text-slate-700"
                >
                  <option value="all">Semua Kategori ({attachments.length})</option>
                  {CATEGORIES.map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
            </div>

            {filteredAttachments.length === 0 ? (
              <div className="text-center py-10 px-4 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 space-y-2">
                <FileText className="w-10 h-10 mx-auto text-slate-400" />
                <p className="text-xs font-bold text-slate-700">Belum Ada Dokumen Terunggah</p>
                <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                  Unggah berkas KK, Akta Kelahiran, Surat Pernyataan Orang Tua, atau Sertifikat Pelatihan Vokasi untuk melengkapi rekam anak.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {filteredAttachments.map((item) => {
                  const isImage = item.tipeFile.startsWith('image/');
                  const isPdf = item.tipeFile.includes('pdf');

                  return (
                    <div 
                      key={item.id}
                      className="bg-white rounded-xl border border-slate-200 hover:border-sky-300 p-3 shadow-2xs transition flex flex-col justify-between space-y-2.5"
                    >
                      <div>
                        {/* Header Item */}
                        <div className="flex items-start justify-between gap-1 mb-2">
                          <span className="text-[10px] font-bold bg-sky-50 text-sky-800 border border-sky-200 px-2 py-0.5 rounded-full truncate max-w-[170px]">
                            {item.kategori}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {item.ukuranKb} KB
                          </span>
                        </div>

                        {/* Thumbnail / Icon */}
                        <div 
                          onClick={() => setPreviewItem(item)}
                          className="h-28 w-full bg-slate-100 rounded-lg overflow-hidden flex items-center justify-center cursor-pointer border border-slate-200/80 hover:opacity-90 transition group relative"
                        >
                          {isImage && item.dataUrl ? (
                            <img 
                              src={item.dataUrl} 
                              alt={item.namaBerkas}
                              className="w-full h-full object-cover"
                            />
                          ) : isPdf ? (
                            <div className="flex flex-col items-center text-rose-600 gap-1">
                              <FileText className="w-8 h-8" />
                              <span className="text-[10px] font-bold">DOKUMEN PDF</span>
                            </div>
                          ) : (
                            <File className="w-8 h-8 text-slate-400" />
                          )}

                          <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-xs font-bold transition">
                            <Eye className="w-4 h-4 mr-1" /> Pratinjau
                          </div>
                        </div>

                        {/* Nama File & Keterangan */}
                        <div className="mt-2 space-y-0.5">
                          <p className="text-xs font-bold text-slate-900 truncate" title={item.namaBerkas}>
                            {item.namaBerkas}
                          </p>
                          {item.keterangan && (
                            <p className="text-[11px] text-slate-500 line-clamp-1 italic">
                              "{item.keterangan}"
                            </p>
                          )}
                          <p className="text-[10px] text-slate-400">
                            Diunggah: {item.tanggalUnggah} ({item.diunggahOleh})
                          </p>
                        </div>
                      </div>

                      {/* Footer Actions */}
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() => setPreviewItem(item)}
                          className="text-xs font-bold text-sky-700 hover:text-sky-900 flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Lihat</span>
                        </button>

                        <div className="flex items-center gap-1">
                          {item.dataUrl && (
                            <a
                              href={item.dataUrl}
                              download={item.namaBerkas}
                              className="text-slate-500 hover:text-slate-800 p-1 hover:bg-slate-100 rounded"
                              title="Unduh Berkas"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </a>
                          )}

                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`Hapus berkas "${item.namaBerkas}"?`)) {
                                onDeleteAttachment(item.id);
                                onShowToast('Berkas dihapus.', 'success');
                              }
                            }}
                            className="text-rose-500 hover:text-rose-700 p-1 hover:bg-rose-50 rounded"
                            title="Hapus Berkas"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500">
            Penyimpanan dokumen terenkripsi sesuai UU Perlindungan Data Anak
          </span>

          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition shadow-2xs"
          >
            Tutup
          </button>
        </div>

      </div>

      {/* Lightbox Preview Modal */}
      {previewItem && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl border border-slate-700">
            <div className="bg-slate-900 text-white px-5 py-3 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold truncate max-w-md">{previewItem.namaBerkas}</h4>
                <p className="text-[10px] text-slate-400">{previewItem.kategori} • {previewItem.ukuranKb} KB</p>
              </div>
              <div className="flex items-center gap-2">
                {previewItem.dataUrl && (
                  <a
                    href={previewItem.dataUrl}
                    download={previewItem.namaBerkas}
                    className="bg-white/20 hover:bg-white/30 text-white text-xs font-bold px-3 py-1 rounded-lg flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" /> Unduh
                  </a>
                )}
                <button 
                  onClick={() => setPreviewItem(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-md"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-4 flex-1 overflow-auto bg-slate-950 flex items-center justify-center min-h-[300px]">
              {previewItem.tipeFile.startsWith('image/') && previewItem.dataUrl ? (
                <img 
                  src={previewItem.dataUrl} 
                  alt={previewItem.namaBerkas} 
                  className="max-h-[70vh] max-w-full object-contain rounded"
                />
              ) : previewItem.tipeFile.includes('pdf') && previewItem.dataUrl ? (
                <iframe 
                  src={previewItem.dataUrl} 
                  title={previewItem.namaBerkas} 
                  className="w-full h-[70vh] rounded border-0"
                />
              ) : (
                <div className="text-center text-slate-400 space-y-2 p-8">
                  <File className="w-12 h-12 mx-auto text-slate-500" />
                  <p className="text-xs">Pratinjau langsung tidak tersedia untuk tipe berkas ini.</p>
                  <a
                    href={previewItem.dataUrl}
                    download={previewItem.namaBerkas}
                    className="inline-block bg-sky-600 text-white text-xs font-bold px-4 py-2 rounded-lg"
                  >
                    Unduh untuk Melihat
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
