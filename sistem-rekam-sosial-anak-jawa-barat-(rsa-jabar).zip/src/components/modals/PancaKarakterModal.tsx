import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  CheckCircle2, 
  Award, 
  Heart, 
  Brain, 
  Zap, 
  Wrench, 
  Droplets,
  HelpCircle,
  Save,
  Clock,
  History
} from 'lucide-react';
import { Client, PancaKarakterScores } from '../../types';

interface PancaKarakterModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: Client;
  onChangeField: (key: string, value: any) => void;
  peksosName?: string;
  onShowToast?: (msg: string, type?: 'success' | 'error') => void;
}

interface DimensionConfig {
  key: keyof Pick<PancaKarakterScores, 'berehan' | 'calakan' | 'waringkas' | 'motekar' | 'berseka'>;
  title: string;
  slogan: string;
  subLabel: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bgColor: string;
  borderColor: string;
  accentBadge: string;
  levels: {
    level: number;
    score: number;
    label: string;
    description: string;
  }[];
}

const DIMENSIONS: DimensionConfig[] = [
  {
    key: 'berehan',
    title: 'Béréhan',
    slogan: 'Solidaritas Sosial, Empati & Kedermawanan',
    subLabel: 'Kepedulian terhadap kawan di asrama, kerelaan berbagi, dan kepekaan sosial.',
    icon: Heart,
    color: 'text-rose-600',
    bgColor: 'bg-rose-50/70',
    borderColor: 'border-rose-200',
    accentBadge: 'bg-rose-100 text-rose-800 border-rose-300',
    levels: [
      { level: 1, score: 20, label: 'Perlu Pendampingan', description: 'Cenderung individualis/egosentris, sering memicu perselisihan di asrama, enggan berbagi.' },
      { level: 2, score: 40, label: 'Mulai Berkembang', description: 'Mau menolong bila diarahkan pengasuh; empati masih terbatas pada kelompok teman dekat.' },
      { level: 3, score: 60, label: 'Berkembang Baik', description: 'Peduli dan rela membantu teman asrama tanpa diminta; menghargai keberagaman latar belakang.' },
      { level: 4, score: 80, label: 'Mandiri & Suportif', description: 'Menjadi penengah konflik kamar, sigap merawat kawan yang sakit, aktif membangun keakraban.' },
      { level: 5, score: 100, label: 'Teladan Kedermawanan', description: 'Jiwa sosial luar biasa, mempelopori aksi tolong-menolong balai, ikhlas berbagi rezeki dan waktu.' },
    ],
  },
  {
    key: 'calakan',
    title: 'Calakan',
    slogan: 'Kecerdasan, Kognitif & Berpikir Kritis',
    subLabel: 'Daya tangkap belajar di PKBM, literasi-numerasi, dan pemecahan masalah (problem solving).',
    icon: Brain,
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50/70',
    borderColor: 'border-indigo-200',
    accentBadge: 'bg-indigo-100 text-indigo-800 border-indigo-300',
    levels: [
      { level: 1, score: 20, label: 'Perlu Pendampingan', description: 'Kesulitan memahami instruksi dasar, pasif dalam kelas kesetaraan PKBM, literasi rendah.' },
      { level: 2, score: 40, label: 'Mulai Berkembang', description: 'Mampu menangkap materi sederhana dengan panduan intensif tutor; motivasi belajar bertahap.' },
      { level: 3, score: 60, label: 'Berkembang Baik', description: 'Aktif mengikuti pelajaran PKBM, mampu memecahkan persoalan harian secara logis.' },
      { level: 4, score: 80, label: 'Kritis & Cepat Tanggap', description: 'Daya analisa tajam, kritis bertanya, inisiatif membaca mandiri, menjadi tutor sebaya bagi kawan.' },
      { level: 5, score: 100, label: 'Cemerlang & Visioner', description: 'Prestasi kognitif unggul, mampu menganalisis risiko keputusan, berwawasan luas dan solutif.' },
    ],
  },
  {
    key: 'waringkas',
    title: 'Waringkas',
    slogan: 'Ketangkasan, Sigap & Kedisiplinan Waktu',
    subLabel: 'Kepatuhan terhadap tata tertib (bangun pagi, piket, apel), kebugaran fisik, dan etos kerja.',
    icon: Zap,
    color: 'text-amber-600',
    bgColor: 'bg-amber-50/70',
    borderColor: 'border-amber-200',
    accentBadge: 'bg-amber-100 text-amber-800 border-amber-300',
    levels: [
      { level: 1, score: 20, label: 'Perlu Pendampingan', description: 'Sering terlambat bangun pagi/apel, abai jadwal asrama, fisik mudah lelah dan kurang bertenaga.' },
      { level: 2, score: 40, label: 'Mulai Berkembang', description: 'Disiplin saat diawasi ketat petugas; mulai membiasakan rutinitas fisik dan piket asrama.' },
      { level: 3, score: 60, label: 'Berkembang Baik', description: 'Tepat waktu mengikuti seluruh agenda balai secara konsisten, tangkas dan cekatan beraktivitas.' },
      { level: 4, score: 80, label: 'Sigap & Berstamina', description: 'Ketahanan fisik prima, inisiatif menyelesaikan tugas piket lebih awal, etos kerja tinggi.' },
      { level: 5, score: 100, label: 'Panutan Disiplin', description: 'Keteladanan kedisiplinan balai (role model), sigap memimpin barisan/apel, tangguh pantang mengeluh.' },
    ],
  },
  {
    key: 'motekar',
    title: 'Motékar',
    slogan: 'Kreativitas, Keterampilan Vokasi & Wirausaha',
    subLabel: 'Kemahiran praktik bengkel/kriya, inovasi karya, daya juang (grit), dan inisiatif kemandirian.',
    icon: Wrench,
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50/70',
    borderColor: 'border-emerald-200',
    accentBadge: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    levels: [
      { level: 1, score: 20, label: 'Perlu Pendampingan', description: 'Enggan mencoba praktik vokasi, cepat menyerah bila menemukan kesulitan teknis peralatan.' },
      { level: 2, score: 40, label: 'Mulai Berkembang', description: 'Mengikuti praktik vokasi sesuai instruksi minimum; memerlukan asistensi instruktur bertahap.' },
      { level: 3, score: 60, label: 'Berkembang Baik', description: 'Menguasai keterampilan dasar kejuruan sesuai SOP; hasil karya rapi dan berfungsi baik.' },
      { level: 4, score: 80, label: 'Kreatif & Terampil', description: 'Kreatif menghasilkan variasi karya baru, berani bereksperimen, menunjukkan bakat wirausaha.' },
      { level: 5, score: 100, label: 'Inovator Mandiri', description: 'Keahlian vokasi matang siap kerja/wirausaha, inovatif memecahkan masalah teknis, bermental juara.' },
    ],
  },
  {
    key: 'berseka',
    title: 'Berséka',
    slogan: 'Kebersihan Diri-Lingkungan & Keluhuran Spiritual',
    subLabel: 'Higienitas personal, kerapian kamar, etika sopan santun, kejujuran moral, dan ketaatan ibadah.',
    icon: Droplets,
    color: 'text-cyan-600',
    bgColor: 'bg-cyan-50/70',
    borderColor: 'border-cyan-200',
    accentBadge: 'bg-cyan-100 text-cyan-800 border-cyan-300',
    levels: [
      { level: 1, score: 20, label: 'Perlu Pendampingan', description: 'Abai kebersihan diri (jarang mandi/cuci baju), kamar berantakan, enggan menjalankan ibadah.' },
      { level: 2, score: 40, label: 'Mulai Berkembang', description: 'Menjaga kebersihan bila ditegur pengasuh; mulai rutin ibadah meski sesekali perlu diingatkan.' },
      { level: 3, score: 60, label: 'Berkembang Baik', description: 'Higienis, berpakaian rapi dan wangi, kamar bersih teratur, tertib menjalankan ibadah tepat waktu.' },
      { level: 4, score: 80, label: 'Bersih & Berakhlak', description: 'Menjaga kebersihan lingkungan bersama secara proaktif, santun dalam bertutur, integritas jujur.' },
      { level: 5, score: 100, label: 'Kesucian Lahir-Batin', description: 'Teladan kesucian lahir dan batin, menjunjung tinggi nilai spiritual, amanah dan menjadi panutan asrama.' },
    ],
  },
];

export const PancaKarakterModal: React.FC<PancaKarakterModalProps> = ({
  isOpen,
  onClose,
  client,
  onChangeField,
  peksosName,
  onShowToast,
}) => {
  const fd = client.formData || ({} as any);

  // Initialize scores with current history / last scores or default 60
  const lastScore = fd.pancaKarakterTerakhir || ({} as Partial<PancaKarakterScores>);
  
  const [berehan, setBerehan] = useState<number>(lastScore.berehan || 60);
  const [calakan, setCalakan] = useState<number>(lastScore.calakan || 60);
  const [waringkas, setWaringkas] = useState<number>(lastScore.waringkas || 60);
  const [motekar, setMotekar] = useState<number>(lastScore.motekar || 60);
  const [berseka, setBerseka] = useState<number>(lastScore.berseka || 60);
  const [catatan, setCatatan] = useState<string>(lastScore.catatan || '');
  const [showHistory, setShowHistory] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentScores: Record<string, number> = {
    berehan,
    calakan,
    waringkas,
    motekar,
    berseka,
  };

  const handleScoreChange = (key: string, value: number) => {
    if (key === 'berehan') setBerehan(value);
    else if (key === 'calakan') setCalakan(value);
    else if (key === 'waringkas') setWaringkas(value);
    else if (key === 'motekar') setMotekar(value);
    else if (key === 'berseka') setBerseka(value);
  };

  // Calculate composite score
  const skorKomposit = Math.round((berehan + calakan + waringkas + motekar + berseka) / 5);

  const getKategori = (score: number) => {
    if (score >= 85) return { label: 'Optimal & Mandiri (Sangat Unggul)', color: 'text-emerald-700 bg-emerald-100 border-emerald-300' };
    if (score >= 70) return { label: 'Berkembang Baik (Adaptif)', color: 'text-sky-700 bg-sky-100 border-sky-300' };
    if (score >= 50) return { label: 'Cukup (Perlu Pemantauan Terarah)', color: 'text-amber-700 bg-amber-100 border-amber-300' };
    return { label: 'Perlu Pendampingan Intensif', color: 'text-rose-700 bg-rose-100 border-rose-300' };
  };

  const kategori = getKategori(skorKomposit);

  const handleSaveRubrik = () => {
    const today = new Date().toISOString().split('T')[0];
    const newEntry: PancaKarakterScores = {
      id: `panca-${Date.now()}`,
      tanggal: today,
      berehan,
      calakan,
      waringkas,
      motekar,
      berseka,
      skorKomposit,
      catatan: catatan.trim(),
      penilai: peksosName || 'Pekerja Sosial Balai',
    };

    const existingHistory = fd.pancaKarakterHistory || [];
    const updatedHistory = [newEntry, ...existingHistory];

    onChangeField('pancaKarakterHistory', updatedHistory);
    onChangeField('pancaKarakterTerakhir', newEntry);

    // Synchronize to overall evaluation scores so Growth Chart reflects immediately
    onChangeField('evaluasiSkorAkhir', skorKomposit);
    onChangeField('evaluasiSkorSosial', berehan);
    onChangeField('evaluasiSkorPsikologis', calakan);
    onChangeField('evaluasiSkorBiologis', Math.round((waringkas + berseka) / 2));
    onChangeField('evaluasiSkorKemandirian', motekar);

    // Auto-append summary into evaluasiPerkembangan if currently empty
    if (!fd.evaluasiPerkembangan) {
      const summaryText = `Evaluasi Skala Kemandirian Panca Karakter Jabar: Skor Komposit ${skorKomposit}/100 (${kategori.label}). Béréhan: ${berehan}, Calakan: ${calakan}, Waringkas: ${waringkas}, Motékar: ${motekar}, Berséka: ${berseka}. ${catatan ? `Catatan: ${catatan}` : ''}`;
      onChangeField('evaluasiPerkembangan', summaryText);
    }

    if (onShowToast) {
      onShowToast(`Skor Rubrik Panca Karakter Jabar berhasil disimpan (Komposit: ${skorKomposit}/100)!`, 'success');
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-linear-to-r from-emerald-800 via-teal-800 to-indigo-900 text-white p-5 flex items-center justify-between shrink-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 text-amber-300 shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-black tracking-tight">
                  Rubrik Kemandirian Sosial: Panca Karakter Jabar
                </h2>
                <span className="text-[10px] uppercase font-extrabold bg-amber-400 text-slate-900 px-2 py-0.5 rounded-full shadow-xs">
                  Kearifan Lokal Jawa Barat
                </span>
              </div>
              <p className="text-xs text-emerald-100/90 mt-0.5">
                Klien: <strong className="text-white">{client.nama}</strong> ({client.id}) • {fd.kabupatenKota || 'Jawa Barat'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/70 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto flex-1 text-slate-800 text-sm">
          
          {/* Cultural Banner */}
          <div className="bg-linear-to-r from-emerald-50 via-teal-50 to-sky-50 border-2 border-emerald-300/80 p-4 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <h3 className="font-extrabold text-xs text-emerald-950 uppercase tracking-wide">
                  5 Nilai Karakter Remaja Binaan (Griya Bina Remaja Lembang)
                </h3>
              </div>
              <p className="text-xs text-emerald-900 leading-relaxed">
                <strong>Béréhan</strong> (Empati & Solidaritas) • <strong>Calakan</strong> (Cerdas & Kritis) • <strong>Waringkas</strong> (Tangkas & Disiplin) • <strong>Motékar</strong> (Kreatif & Vokasional) • <strong>Berséka</strong> (Bersih & Religius).
              </p>
            </div>

            {/* Score pill preview */}
            <div className="bg-white px-4 py-2 rounded-xl border border-emerald-300 shadow-xs shrink-0 flex items-center gap-3">
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase block">Skor Komposit</span>
                <span className="text-2xl font-black text-emerald-700">{skorKomposit}</span>
                <span className="text-xs text-slate-400">/100</span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-1 rounded-lg border uppercase ${kategori.color}`}>
                {kategori.label}
              </span>
            </div>
          </div>

          {/* Toggle History View */}
          {(fd.pancaKarakterHistory || []).length > 0 && (
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setShowHistory(!showHistory)}
                className="text-xs font-bold text-indigo-700 hover:text-indigo-900 flex items-center gap-1.5 bg-indigo-50 px-3 py-1.5 rounded-lg border border-indigo-200 transition"
              >
                <History className="w-3.5 h-3.5" />
                <span>{showHistory ? 'Sembunyikan Riwayat Penilaian' : `Lihat Riwayat (${(fd.pancaKarakterHistory || []).length} kali penilaian)`}</span>
              </button>
            </div>
          )}

          {/* History Panel */}
          {showHistory && (
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5 uppercase">
                <Clock className="w-3.5 h-3.5 text-indigo-600" />
                Riwayat Pengukuran Skala Panca Karakter Klien
              </h4>
              <div className="divide-y divide-slate-200 bg-white rounded-lg border border-slate-200 overflow-hidden text-xs">
                {(fd.pancaKarakterHistory || []).map((item: PancaKarakterScores, idx: number) => (
                  <div key={item.id || idx} className="p-3 flex items-center justify-between gap-2 hover:bg-slate-50">
                    <div>
                      <span className="font-bold text-slate-900">{item.tanggal}</span>
                      <span className="text-slate-400 mx-2">•</span>
                      <span className="text-slate-600">Oleh: {item.penilai || 'Peksos'}</span>
                      {item.catatan && <p className="text-slate-500 italic mt-0.5">"{item.catatan}"</p>}
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <span className="font-black text-emerald-700 text-sm">{item.skorKomposit}</span>
                        <span className="text-[10px] text-slate-400">/100</span>
                      </div>
                      <div className="text-[10px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                        B:{item.berehan} C:{item.calakan} W:{item.waringkas} M:{item.motekar} S:{item.berseka}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5 Dimensions Form */}
          <div className="space-y-5">
            {DIMENSIONS.map((dim, idx) => {
              const currentScore = currentScores[dim.key];
              const IconComp = dim.icon;

              return (
                <div 
                  key={dim.key} 
                  className={`rounded-xl border-2 ${dim.borderColor} ${dim.bgColor} p-4 sm:p-5 space-y-3 transition shadow-xs`}
                >
                  {/* Dimension Title & Current Score */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200/80 pb-2.5">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-8 h-8 rounded-lg bg-white shadow-2xs flex items-center justify-center ${dim.color} border border-slate-200`}>
                        <IconComp className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-extrabold text-slate-900">
                            {idx + 1}. Karakter {dim.title}
                          </h4>
                          <span className="text-xs font-semibold text-slate-600 italic">
                            ({dim.slogan})
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-0.5">{dim.subLabel}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                      <span className="text-xs text-slate-500">Skor:</span>
                      <span className={`text-base font-black px-3 py-1 rounded-lg border ${dim.accentBadge}`}>
                        {currentScore} <span className="text-[10px] font-normal">/ 100</span>
                      </span>
                    </div>
                  </div>

                  {/* Level Rubric Buttons (1 - 5) */}
                  <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 pt-1">
                    {dim.levels.map((lvl) => {
                      const isSelected = currentScore === lvl.score;

                      return (
                        <button
                          key={lvl.level}
                          type="button"
                          onClick={() => handleScoreChange(dim.key, lvl.score)}
                          className={`p-2.5 rounded-xl border text-left transition relative flex flex-col justify-between ${
                            isSelected
                              ? 'bg-white border-slate-900 shadow-md ring-2 ring-slate-800'
                              : 'bg-white/80 border-slate-200 hover:border-slate-400 hover:bg-white'
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <span className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded ${
                                isSelected ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700'
                              }`}>
                                Level {lvl.level}
                              </span>
                              <span className="text-[11px] font-black text-slate-800">{lvl.score} Poin</span>
                            </div>
                            <h5 className="text-[11px] font-bold text-slate-900 leading-snug line-clamp-1">
                              {lvl.label}
                            </h5>
                            <p className="text-[10px] text-slate-600 mt-1 leading-relaxed line-clamp-3">
                              {lvl.description}
                            </p>
                          </div>

                          {isSelected && (
                            <div className="mt-2 pt-1.5 border-t border-slate-100 flex items-center gap-1 text-[10px] font-bold text-emerald-700">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              <span>Terpilih</span>
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Catatan Peksos / Evaluasi Kualitatif */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <span>Catatan Dinamika & Rekomendasi Pembinaan Lanjutan:</span>
            </label>
            <textarea
              rows={3}
              value={catatan}
              onChange={(e) => setCatatan(e.target.value)}
              placeholder="Tuliskan catatan kemajuan spesifik (misal: Béréhan meningkat signifikan saat piket asrama, Motékar sangat menonjol di bengkel las, perlu bimbingan kedisiplinan bangun pagi)..."
              className="w-full rounded-lg border border-slate-300 p-2.5 text-xs text-slate-800 bg-white focus:ring-2 focus:ring-emerald-500 shadow-2xs"
            />
          </div>

        </div>

        {/* Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-600 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Skor komposit ({skorKomposit}/100) langsung memperbarui Kurva Pertumbuhan Anak (*Child Growth Chart*).</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-bold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 transition shadow-2xs"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleSaveRubrik}
              className="w-full sm:w-auto px-5 py-2 rounded-xl text-xs font-bold text-white bg-linear-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 transition flex items-center justify-center gap-2 shadow-md"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Penilaian Panca Karakter</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
