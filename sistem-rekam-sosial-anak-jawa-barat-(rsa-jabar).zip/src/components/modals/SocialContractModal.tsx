import React, { useState, useEffect } from 'react';
import { 
  X, 
  FileCheck, 
  Printer, 
  ShieldCheck, 
  Calendar, 
  UserCheck, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Building2, 
  Home, 
  Award, 
  Save, 
  RotateCcw,
  Edit3
} from 'lucide-react';
import { Client, SocialContractData } from '../../types';

interface SocialContractModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: Client;
  onSaveSocialContract: (contract: SocialContractData) => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
  peksosName?: string;
}

// Helper to add exactly 3 months to date YYYY-MM-DD
function calculateThreeMonthsLater(startDateStr: string): string {
  try {
    const [y, m, d] = startDateStr.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    date.setMonth(date.getMonth() + 3);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  } catch {
    return startDateStr;
  }
}

export const SocialContractModal: React.FC<SocialContractModalProps> = ({
  isOpen,
  onClose,
  client,
  onSaveSocialContract,
  onShowToast,
  peksosName = 'Pekerja Sosial Balai',
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [isPreview, setIsPreview] = useState(false);

  // Form Fields
  const [nomorKontrak, setNomorKontrak] = useState('');
  const [tanggalMulai, setTanggalMulai] = useState(new Date().toISOString().split('T')[0]);
  const [tanggalSelesai, setTanggalSelesai] = useState(calculateThreeMonthsLater(new Date().toISOString().split('T')[0]));
  const durasiBulan = 3; // Strict 3 months rule

  const [namaKepalaBalai, setNamaKepalaBalai] = useState('Dra. Hj. Sri Wahyuni, M.Si');
  const [nipKepalaBalai, setNipKepalaBalai] = useState('19740512 199803 2 004');
  const [namaPeksosPendamping, setNamaPeksosPendamping] = useState(peksosName);

  const [namaWali, setNamaWali] = useState('');
  const [hubunganWali, setHubunganWali] = useState('Orang Tua Kandung');
  const [nikWali, setNikWali] = useState('');
  const [alamatWali, setAlamatWali] = useState('');

  const [namaAnak, setNamaAnak] = useState('');
  const [jurusanVokasi, setJurusanVokasi] = useState('');
  const [asramaBinaan, setAsramaBinaan] = useState('Asrama Remaja Putera Mandiri');
  const [komitmenKhusus, setKomitmenKhusus] = useState(
    'Klien anak berkomitmen mengikuti seluruh tahapan rehabilitasi sosial, bimbingan mental spiritual, penanaman karakter Jabar (Berehan, Calakan, Waringkas, Motekar, Berseka), serta pelatihan vokasi secara disiplin selama 3 bulan penuh tanpa melanggar tata tertib asrama balai.'
  );
  const [statusKontrak, setStatusKontrak] = useState<'Aktif Berjalan' | 'Selesai 3 Bulan' | 'Dibatalkan / Terminasi Dini'>('Aktif Berjalan');
  const [tanggalTandaTangan, setTanggalTandaTangan] = useState(new Date().toISOString().split('T')[0]);
  const [ditandatangani, setDitandatangani] = useState(true);

  // Initialize from client data or defaults
  useEffect(() => {
    if (client.kontrakPelayanan) {
      const k = client.kontrakPelayanan;
      setNomorKontrak(k.nomorKontrak);
      setTanggalMulai(k.tanggalMulai);
      setTanggalSelesai(k.tanggalSelesai || calculateThreeMonthsLater(k.tanggalMulai));
      setNamaKepalaBalai(k.namaKepalaBalai || 'Dra. Hj. Sri Wahyuni, M.Si');
      setNipKepalaBalai(k.nipKepalaBalai || '19740512 199803 2 004');
      setNamaPeksosPendamping(k.namaPeksosPendamping || peksosName);
      setNamaWali(k.namaWali || client.formData.namaWali || '');
      setHubunganWali(k.hubunganWali || 'Orang Tua Kandung');
      setNikWali(k.nikWali || '');
      setAlamatWali(k.alamatWali || client.formData.tinggalJalan || 'Jawa Barat');
      setNamaAnak(k.namaAnak || client.nama);
      setJurusanVokasi(k.jurusanVokasi || client.formData.jurusan || 'Keterampilan Vokasional Balai');
      setAsramaBinaan(k.asramaBinaan || 'Asrama Remaja Putera Mandiri');
      setKomitmenKhusus(k.komitmenKhusus || '');
      setStatusKontrak(k.statusKontrak || 'Aktif Berjalan');
      setTanggalTandaTangan(k.tanggalTandaTangan || new Date().toISOString().split('T')[0]);
      setDitandatangani(k.ditandatangani ?? true);
      setIsEditing(false);
    } else {
      // Default new contract
      const today = new Date().toISOString().split('T')[0];
      const defaultNo = `KPS/PPS-GBR/JBR/${new Date().getFullYear()}/${String(client.id || '001').slice(-4)}`;
      setNomorKontrak(defaultNo);
      setTanggalMulai(today);
      setTanggalSelesai(calculateThreeMonthsLater(today));
      setNamaKepalaBalai('Dra. Hj. Sri Wahyuni, M.Si');
      setNipKepalaBalai('19740512 199803 2 004');
      setNamaPeksosPendamping(peksosName);
      setNamaWali(client.formData.namaWali || 'Wali / Orang Tua Klien');
      setHubunganWali('Orang Tua Kandung');
      setNikWali('3204' + Math.floor(100000000000 + Math.random() * 900000000000));
      setAlamatWali(client.formData.tinggalJalan || 'Provinsi Jawa Barat');
      setNamaAnak(client.nama);
      setJurusanVokasi(client.formData.jurusan || 'Keterampilan Vokasional Balai');
      setAsramaBinaan('Asrama Remaja Putera Mandiri');
      setStatusKontrak('Aktif Berjalan');
      setTanggalTandaTangan(today);
      setDitandatangani(true);
      setIsEditing(true); // Open edit mode for new contract
    }
  }, [client, isOpen, peksosName]);

  // Handle start date change: auto update end date
  const handleStartDateChange = (val: string) => {
    setTanggalMulai(val);
    setTanggalSelesai(calculateThreeMonthsLater(val));
  };

  const handleSave = () => {
    if (!nomorKontrak.trim()) {
      onShowToast('Nomor kontrak wajib diisi.', 'error');
      return;
    }
    if (!tanggalMulai) {
      onShowToast('Tanggal mulai kontrak wajib diisi.', 'error');
      return;
    }

    const contract: SocialContractData = {
      nomorKontrak: nomorKontrak.trim(),
      tanggalMulai,
      tanggalSelesai,
      durasiBulan: 3,
      namaKepalaBalai,
      nipKepalaBalai,
      namaPeksosPendamping,
      namaWali,
      hubunganWali,
      nikWali,
      alamatWali,
      namaAnak,
      jurusanVokasi,
      asramaBinaan,
      komitmenKhusus,
      statusKontrak,
      tanggalTandaTangan,
      ditandatangani,
    };

    onSaveSocialContract(contract);
    setIsEditing(false);
    onShowToast('Kontrak Pelayanan Sosial 3 Bulan berhasil disimpan!', 'success');
  };

  const handlePrint = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-800 flex items-center justify-center shadow-xs">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 tracking-tight">Kontrak Pelayanan Sosial Binaan</h2>
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-sky-100 text-sky-800 border border-sky-300">
                  Periode Standar 3 Bulan
                </span>
                <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${
                  statusKontrak === 'Aktif Berjalan' ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' :
                  statusKontrak === 'Selesai 3 Bulan' ? 'bg-blue-100 text-blue-800 border border-blue-300' :
                  'bg-rose-100 text-rose-800 border border-rose-300'
                }`}>
                  {statusKontrak}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Perjanjian Tripartit Resmi: Balai Rehabilitasi Sosial - Orang Tua/Wali - Klien Remaja ({client.nama})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!isEditing && (
              <>
                <button
                  type="button"
                  onClick={() => setIsPreview(!isPreview)}
                  className="px-3 py-1.5 text-xs font-medium border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  {isPreview ? 'Tampilan Ringkas' : 'Tinjau Draft Surat'}
                </button>
                <button
                  type="button"
                  onClick={handlePrint}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-100 transition-colors shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Cetak Kontrak
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditing(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-sky-700 text-white rounded-lg hover:bg-sky-800 transition-colors shadow-xs"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  Edit Kontrak
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              title="Tutup Modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* Banner Informasi 3 Bulan */}
          <div className="bg-sky-50 border border-sky-200 rounded-xl p-4 flex items-start gap-3 text-sky-900">
            <ShieldCheck className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <p className="font-semibold text-sky-950">
                Landasan Operasional Kontrak Pelayanan Sosial 3 Bulan (Standar Balai)
              </p>
              <p className="text-sky-800 leading-relaxed">
                Berdasarkan Standar Pelayanan Minimal (SPM) UPTD PPS Griya Bina Remaja Dinsos Jabar, masa resosialisasi dan vokasi bagi anak remaja binaan berlangsung selama <strong>3 (tiga) bulan penuh</strong>. Kontrak ini menjamin kepastian hak klien memperoleh pemenuhan kebutuhan dasar & pelatihan gratis, serta mengikat komitmen wali untuk menerima kembali anak pasca-terminasi.
              </p>
            </div>
          </div>

          {isEditing ? (
            /* ================= EDIT MODE ================= */
            <div className="space-y-6">
              {/* Nomor & Jadwal Kontrak */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nomor Surat Kontrak <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={nomorKontrak}
                    onChange={(e) => setNomorKontrak(e.target.value)}
                    placeholder="Contoh: KPS/PPS-GBR/JBR/2026/0142"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-sky-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tanggal Mulai Layanan <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={tanggalMulai}
                    onChange={(e) => handleStartDateChange(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-sky-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tanggal Selesai (Otomatis Tepat 3 Bulan)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="date"
                      value={tanggalSelesai}
                      readOnly
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-slate-100 text-slate-700 font-semibold cursor-not-allowed"
                    />
                    <span className="text-xs px-2 py-1 bg-sky-100 text-sky-800 rounded font-bold shrink-0">
                      3 Bulan
                    </span>
                  </div>
                </div>
              </div>

              {/* Tiga Pihak Terlibat */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Pihak 1: Balai */}
                <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                  <div className="flex items-center gap-2 text-sky-800 border-b border-slate-100 pb-2">
                    <Building2 className="w-4 h-4 text-sky-700" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">Pihak I (Penyelenggara Balai)</h3>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">Nama Kepala Balai</label>
                    <input
                      type="text"
                      value={namaKepalaBalai}
                      onChange={(e) => setNamaKepalaBalai(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">NIP Kepala Balai</label>
                    <input
                      type="text"
                      value={nipKepalaBalai}
                      onChange={(e) => setNipKepalaBalai(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">Pekerja Sosial Pendamping</label>
                    <input
                      type="text"
                      value={namaPeksosPendamping}
                      onChange={(e) => setNamaPeksosPendamping(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                </div>

                {/* Pihak 2: Wali / Orang Tua */}
                <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                  <div className="flex items-center gap-2 text-indigo-800 border-b border-slate-100 pb-2">
                    <UserCheck className="w-4 h-4 text-indigo-700" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">Pihak II (Orang Tua / Wali)</h3>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">Nama Lengkap Wali</label>
                    <input
                      type="text"
                      value={namaWali}
                      onChange={(e) => setNamaWali(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">Hubungan Hubungan Keluarga</label>
                    <input
                      type="text"
                      value={hubunganWali}
                      onChange={(e) => setHubunganWali(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">NIK KTP Wali</label>
                    <input
                      type="text"
                      value={nikWali}
                      onChange={(e) => setNikWali(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">Alamat Domisili Wali</label>
                    <input
                      type="text"
                      value={alamatWali}
                      onChange={(e) => setAlamatWali(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                </div>

                {/* Pihak 3: Anak Remaja Binaan */}
                <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                  <div className="flex items-center gap-2 text-emerald-800 border-b border-slate-100 pb-2">
                    <Award className="w-4 h-4 text-emerald-700" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">Pihak III (Klien Binaan)</h3>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">Nama Lengkap Klien</label>
                    <input
                      type="text"
                      value={namaAnak}
                      onChange={(e) => setNamaAnak(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500 bg-slate-50 font-medium"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">Kejuruan Vokasi Dipilih</label>
                    <input
                      type="text"
                      value={jurusanVokasi}
                      onChange={(e) => setJurusanVokasi(e.target.value)}
                      placeholder="Misal: Otomotif, Tata Busana, Barista"
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">Penempatan Asrama</label>
                    <input
                      type="text"
                      value={asramaBinaan}
                      onChange={(e) => setAsramaBinaan(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-0.5">Status Kontrak</label>
                    <select
                      value={statusKontrak}
                      onChange={(e: any) => setStatusKontrak(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-sky-500 bg-white"
                    >
                      <option value="Aktif Berjalan">Aktif Berjalan (Dalam Masa 3 Bulan)</option>
                      <option value="Selesai 3 Bulan">Selesai 3 Bulan (Terminasi Tuntas)</option>
                      <option value="Dibatalkan / Terminasi Dini">Dibatalkan / Terminasi Dini</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Komitmen Khusus Klien & Wali */}
              <div className="bg-white border border-slate-200 rounded-xl p-4">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Komitmen Khusus & Rencana Reintegrasi Sosial (3 Bulan)
                </label>
                <textarea
                  rows={3}
                  value={komitmenKhusus}
                  onChange={(e) => setKomitmenKhusus(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-sky-500"
                  placeholder="Tuliskan komitmen khusus klien atau kesepakatan keluarga..."
                />
              </div>

              {/* Tanggal & Penandatanganan */}
              <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <div className="flex items-center gap-3">
                  <label className="text-xs font-semibold text-slate-700">Tanggal Penandatanganan:</label>
                  <input
                    type="date"
                    value={tanggalTandaTangan}
                    onChange={(e) => setTanggalTandaTangan(e.target.value)}
                    className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  />
                </div>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
                  <input
                    type="checkbox"
                    checked={ditandatangani}
                    onChange={(e) => setDitandatangani(e.target.checked)}
                    className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500 border-slate-300"
                  />
                  <span>Telah ditandatangani dan disepakati oleh seluruh pihak (Balai, Wali, Anak)</span>
                </label>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-2">
                {client.kontrakPelayanan && (
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 text-xs font-medium border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Batal Edit
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleSave}
                  className="flex items-center gap-1.5 px-5 py-2 text-xs font-semibold bg-sky-700 text-white rounded-lg hover:bg-sky-800 transition-colors shadow-xs"
                >
                  <Save className="w-4 h-4" />
                  Simpan Kontrak Pelayanan 3 Bulan
                </button>
              </div>
            </div>
          ) : (
            /* ================= VIEW / PREVIEW SURAT RESMI ================= */
            <div className="space-y-6">
              
              {/* Ringkasan Status & Timeline 3 Bulan */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
                <div>
                  <span className="text-[11px] text-slate-500 uppercase font-semibold block">Nomor Kontrak</span>
                  <span className="text-xs font-mono font-bold text-slate-800">{nomorKontrak}</span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 uppercase font-semibold block">Masa Layanan (3 Bulan)</span>
                  <span className="text-xs font-semibold text-slate-800">
                    {tanggalMulai} s.d. {tanggalSelesai}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 uppercase font-semibold block">Kejuruan Vokasi</span>
                  <span className="text-xs font-semibold text-slate-800">{jurusanVokasi || '-'}</span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 uppercase font-semibold block">Status Persetujuan</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    {ditandatangani ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Disepakati & Bermaterai
                      </span>
                    ) : (
                      <span className="text-xs font-medium text-amber-600">Menunggu Tanda Tangan</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Surat Perjanjian Resmi (Printable Card) */}
              <div id="print-social-contract" className="bg-white border border-slate-300 rounded-xl p-6 sm:p-8 space-y-6 shadow-sm">
                
                {/* KOP SURAT PEMERINTAH DAERAH */}
                <div className="border-b-2 border-slate-800 pb-4 text-center relative">
                  <div className="flex items-center justify-center gap-4 mb-1">
                    <div className="w-14 h-14 bg-sky-900 text-white rounded-lg flex items-center justify-center font-bold text-xs p-1 text-center shadow-xs">
                      JABAR JUARA
                    </div>
                    <div>
                      <h3 className="text-xs sm:text-sm font-semibold tracking-wider text-slate-800 uppercase">
                        Pemerintah Daerah Provinsi Jawa Barat
                      </h3>
                      <h2 className="text-sm sm:text-base font-extrabold text-slate-950 uppercase tracking-tight">
                        Dinas Sosial - UPTD PPS Griya Bina Remaja
                      </h2>
                      <p className="text-[11px] text-slate-600 mt-0.5">
                        Jl. Ciumbuleuit No. 107, Hegarmanah, Kec. Cidadap, Kota Bandung, Jawa Barat 40141
                      </p>
                    </div>
                  </div>
                </div>

                {/* Judul Perjanjian */}
                <div className="text-center space-y-1">
                  <h3 className="text-sm sm:text-base font-extrabold uppercase text-slate-900 underline underline-offset-4 tracking-wide">
                    Surat Kontrak Pelayanan Sosial Remaja
                  </h3>
                  <p className="text-xs font-medium text-slate-600">
                    Nomor: <span className="font-mono">{nomorKontrak}</span>
                  </p>
                </div>

                {/* Pembukaan Surat */}
                <p className="text-xs text-slate-700 leading-relaxed text-justify">
                  Pada hari ini, tanggal <strong>{tanggalTandaTangan}</strong>, bertempat di Kantor UPTD PPS Griya Bina Remaja Dinas Sosial Provinsi Jawa Barat, yang bertanda tangan di bawah ini sepakat mengikatkan diri dalam Kontrak Pelayanan Sosial Rehabilitasi Binaan Remaja dengan ketentuan sebagai berikut:
                </p>

                {/* Identitas 3 Pihak */}
                <div className="space-y-3 text-xs text-slate-800">
                  {/* Pihak I */}
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <p className="font-bold text-slate-900 mb-1">I. PIHAK PERTAMA (Pihak Penyelenggara Layanan):</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-slate-700 pl-3">
                      <div>Nama Kepala Balai: <strong>{namaKepalaBalai}</strong></div>
                      <div>NIP: <strong>{nipKepalaBalai}</strong></div>
                      <div>Peksos Pendamping: <strong>{namaPeksosPendamping}</strong></div>
                      <div>Jabatan: Kepala UPTD PPS Griya Bina Remaja Dinsos Jabar</div>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 pl-3">
                      Bertindak untuk dan atas nama UPTD PPS Griya Bina Remaja Dinas Sosial Provinsi Jawa Barat, selanjutnya disebut <strong>PIHAK PERTAMA</strong>.
                    </p>
                  </div>

                  {/* Pihak II */}
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <p className="font-bold text-slate-900 mb-1">II. PIHAK KEDUA (Pihak Orang Tua / Wali):</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-slate-700 pl-3">
                      <div>Nama Wali: <strong>{namaWali}</strong></div>
                      <div>Hubungan: <strong>{hubunganWali}</strong></div>
                      <div>NIK Wali: <strong>{nikWali || '-'}</strong></div>
                      <div>Alamat: <strong>{alamatWali}</strong></div>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 pl-3">
                      Selaku orang tua kandung/wali yang sah atas anak penerima manfaat, selanjutnya disebut <strong>PIHAK KEDUA</strong>.
                    </p>
                  </div>

                  {/* Pihak III */}
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <p className="font-bold text-slate-900 mb-1">III. PIHAK KETIGA (Klien Binaan Remaja):</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-slate-700 pl-3">
                      <div>Nama Klien: <strong>{namaAnak}</strong></div>
                      <div>Asrama: <strong>{asramaBinaan}</strong></div>
                      <div>Pilihan Kejuruan: <strong>{jurusanVokasi}</strong></div>
                      <div>Status Binaan: Klien Remaja Putus Sekolah / PPKS</div>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 pl-3">
                      Selaku penerima manfaat langsung pelayanan sosial dan pelatihan kemandirian, selanjutnya disebut <strong>PIHAK KETIGA</strong>.
                    </p>
                  </div>
                </div>

                {/* Pasal-Pasal Perjanjian */}
                <div className="space-y-4 text-xs text-slate-800">
                  
                  {/* Pasal 1 */}
                  <div>
                    <h4 className="font-bold text-slate-950 uppercase text-xs border-b border-slate-200 pb-1">
                      Pasal 1: Jangka Waktu Pelayanan Sosial (3 Bulan)
                    </h4>
                    <p className="mt-1.5 leading-relaxed text-justify text-slate-700">
                      Pelayanan rehabilitasi sosial dan bimbingan kemandirian vokasional disepakati berlangsung selama <strong>3 (tiga) bulan kalender</strong> terhitung mulai tanggal <strong>{tanggalMulai}</strong> sampai dengan tanggal <strong>{tanggalSelesai}</strong>.
                    </p>
                  </div>

                  {/* Pasal 2 */}
                  <div>
                    <h4 className="font-bold text-slate-950 uppercase text-xs border-b border-slate-200 pb-1">
                      Pasal 2: Hak Klien dan Tanggung Jawab Pihak Pertama (Balai)
                    </h4>
                    <ol className="mt-1.5 list-decimal pl-5 space-y-1 text-slate-700">
                      <li>Menyediakan asrama hunian yang layak, aman, dan tertib.</li>
                      <li>Memberikan permakanan sehat dan bergizi sebanyak 3 (tiga) kali sehari secara cuma-cuma tanpa dipungut biaya apapun.</li>
                      <li>Memberikan bimbingan fisik dasar, pemeriksaan kesehatan klinik balai, dan bimbingan mental spiritual.</li>
                      <li>Memberikan pelatihan keterampilan kerja vokasional bersertifikat sesuai kejuruan yang dipilih (<strong>{jurusanVokasi}</strong>).</li>
                      <li>Menugaskan Pekerja Sosial Profesional untuk pendampingan konseling individual dan advokasi sosial.</li>
                    </ol>
                  </div>

                  {/* Pasal 3 */}
                  <div>
                    <h4 className="font-bold text-slate-950 uppercase text-xs border-b border-slate-200 pb-1">
                      Pasal 3: Kewajiban dan Tata Tertib Klien (Pihak Ketiga)
                    </h4>
                    <ol className="mt-1.5 list-decimal pl-5 space-y-1 text-slate-700">
                      <li>Mentaati tata tertib asrama balai, hadir tepat waktu dalam apel dan seluruh sesi pelatihan.</li>
                      <li>Dilarang keras membawa, menyimpan, maupun mengonsumsi rokok, miras, lem/inhalan, senjata tajam, dan NAPZA.</li>
                      <li>Dilarang melakukan perundungan (bullying), perkelahian, pencurian, atau tindakan melawan hukum lainnya.</li>
                      <li>Menginternalisasi dan mempraktikkan panca karakter Jabar: <em>Berehan</em> (peduli sesama), <em>Calakan</em> (cerdas dan mau belajar), <em>Waringkas</em> (sehat & sigap), <em>Motekar</em> (kreatif berdaya cipta), dan <em>Berseka</em> (bersih & rapi).</li>
                    </ol>
                  </div>

                  {/* Pasal 4 */}
                  <div>
                    <h4 className="font-bold text-slate-950 uppercase text-xs border-b border-slate-200 pb-1">
                      Pasal 4: Peran, Hak, dan Kewajiban Orang Tua / Wali (Pihak Kedua)
                    </h4>
                    <ol className="mt-1.5 list-decimal pl-5 space-y-1 text-slate-700">
                      <li>Mendukung penuh proses pembinaan selama 3 bulan dan tidak menarik anak sebelum program tuntas tanpa alasan kedaruratan yang disetujui balai.</li>
                      <li>Hadir dalam kegiatan <em>Family Gathering / Home Visit</em> atau pertemuan konsultasi orang tua berkala bila diundang.</li>
                      <li>Bersedia menjemput dan menerima kembali anak pada saat acara reuni/terminasi 3 bulan serta mendukung rencana kemandirian kerja atau sekolah lanjut anak di keluarga/masyarakat.</li>
                    </ol>
                  </div>

                  {/* Pasal 5 */}
                  <div>
                    <h4 className="font-bold text-slate-950 uppercase text-xs border-b border-slate-200 pb-1">
                      Pasal 5: Komitmen Khusus Reintegrasi
                    </h4>
                    <p className="mt-1.5 leading-relaxed text-justify text-slate-700 italic bg-slate-50 p-2.5 rounded border border-slate-200">
                      "{komitmenKhusus || 'Tidak ada komitmen khusus tambahan.'}"
                    </p>
                  </div>

                  {/* Penutup */}
                  <p className="text-xs text-slate-700 leading-relaxed text-justify pt-2">
                    Demikian surat kontrak pelayanan sosial ini dibuat dalam rangkap 3 (tiga) bermaterai cukup dan mempunyai kekuatan hukum yang sama bagi para pihak untuk dilaksanakan dengan penuh rasa tanggung jawab.
                  </p>
                </div>

                {/* Kolom Tanda Tangan Tiga Pihak */}
                <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-200 text-center text-xs text-slate-800">
                  
                  {/* TTD Pihak Kedua (Wali) */}
                  <div className="flex flex-col items-center justify-between h-36">
                    <div>
                      <p className="font-semibold text-slate-700">PIHAK KEDUA</p>
                      <p className="text-[11px] text-slate-500">Orang Tua / Wali Klien</p>
                    </div>
                    <div className="w-20 h-10 border border-dashed border-slate-300 rounded flex items-center justify-center text-[10px] text-slate-400">
                      Materai Rp 10.000
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 underline">{namaWali || '(Nama Wali)'}</p>
                      <p className="text-[10px] text-slate-500">Wali Klien Binaan</p>
                    </div>
                  </div>

                  {/* TTD Pihak Ketiga (Anak) */}
                  <div className="flex flex-col items-center justify-between h-36">
                    <div>
                      <p className="font-semibold text-slate-700">PIHAK KETIGA</p>
                      <p className="text-[11px] text-slate-500">Klien Remaja Binaan</p>
                    </div>
                    <div className="text-[10px] text-slate-400 italic">
                      [Tanda Tangan Klien]
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 underline">{namaAnak}</p>
                      <p className="text-[10px] text-slate-500">Penerima Manfaat</p>
                    </div>
                  </div>

                  {/* TTD Pihak Pertama (Balai) */}
                  <div className="flex flex-col items-center justify-between h-36">
                    <div>
                      <p className="font-semibold text-slate-700">PIHAK PERTAMA</p>
                      <p className="text-[11px] text-slate-500">UPTD PPS Griya Bina Remaja</p>
                    </div>
                    <div className="text-[10px] text-slate-400 italic">
                      [Stempel Balai & TTD]
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 underline">{namaKepalaBalai}</p>
                      <p className="text-[10px] text-slate-500">NIP. {nipKepalaBalai}</p>
                    </div>
                  </div>

                </div>

                {/* Saksi Peksos */}
                <div className="pt-4 border-t border-dashed border-slate-200 text-center">
                  <p className="text-[11px] text-slate-500">Mengetahui & Mendampingi:</p>
                  <p className="text-xs font-bold text-slate-900 underline mt-6">{namaPeksosPendamping}</p>
                  <p className="text-[10px] text-slate-500">Pekerja Sosial Pendamping Kasus</p>
                </div>

              </div>

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Standar Pelayanan Sosial 3 Bulan UPTD PPS Griya Bina Remaja Dinsos Jabar</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 font-medium border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
