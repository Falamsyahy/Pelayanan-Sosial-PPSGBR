import React, { useState } from 'react';
import { 
  X, 
  Users, 
  Plus, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  FileText, 
  Printer, 
  Trash2, 
  Eye, 
  ShieldCheck, 
  AlertTriangle,
  UserCheck,
  Stethoscope,
  Wrench,
  Brain,
  Home
} from 'lucide-react';
import { Client, CaseConferenceItem, CaseConferenceType } from '../../types';

interface CaseConferenceModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: Client;
  onSaveCaseConference: (item: CaseConferenceItem) => void;
  onDeleteCaseConference: (id: string) => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
  peksosName?: string;
}

export const CaseConferenceModal: React.FC<CaseConferenceModalProps> = ({
  isOpen,
  onClose,
  client,
  onSaveCaseConference,
  onDeleteCaseConference,
  onShowToast,
  peksosName = 'Pekerja Sosial',
}) => {
  const [viewMode, setViewMode] = useState<'list' | 'create' | 'preview'>('list');
  const [previewItem, setPreviewItem] = useState<CaseConferenceItem | null>(null);

  // Form State
  const [tanggal, setTanggal] = useState(new Date().toISOString().split('T')[0]);
  const [waktu, setWaktu] = useState('09:00');
  const [jenisSidang, setJenisSidang] = useState<CaseConferenceType>('Sidang Perkembangan (Progress Review)');
  const [judul, setJudul] = useState('');
  const [pimpinanSidang, setPimpinanSidang] = useState('Kepala UPTD PPS Griya Bina Remaja');
  const [notulis, setNotulis] = useState(peksosName);
  const [pesertaHadir, setPesertaHadir] = useState<string[]>([
    peksosName,
    'Instruktur Vokasi',
    'Pengasuh Asrama Sosial',
    'Tenaga Medis Balai',
  ]);
  const [pesertaBaru, setPesertaBaru] = useState('');
  const [latarBelakangKasus, setLatarBelakangKasus] = useState('');
  const [dinamikaDanPembahasan, setDinamikaDanPembahasan] = useState('');
  const [keputusanSidang, setKeputusanSidang] = useState('');
  const [rencanaAksiTindakLanjut, setRencanaAksiTindakLanjut] = useState('');
  const [statusPersetujuan, setStatusPersetujuan] = useState<'Disetujui Tim Sidang' | 'Perlu Pendalaman Kasus' | 'Rujukan Eksternal'>('Disetujui Tim Sidang');

  if (!isOpen) return null;

  const conferences = client.caseConferences || [];

  const handleAddPeserta = () => {
    if (pesertaBaru.trim() && !pesertaHadir.includes(pesertaBaru.trim())) {
      setPesertaHadir([...pesertaHadir, pesertaBaru.trim()]);
      setPesertaBaru('');
    }
  };

  const handleRemovePeserta = (name: string) => {
    setPesertaHadir(pesertaHadir.filter(p => p !== name));
  };

  const resetForm = () => {
    setTanggal(new Date().toISOString().split('T')[0]);
    setWaktu('09:00');
    setJenisSidang('Sidang Perkembangan (Progress Review)');
    setJudul('');
    setPimpinanSidang('Kepala UPTD PPS Griya Bina Remaja');
    setNotulis(peksosName);
    setLatarBelakangKasus('');
    setDinamikaDanPembahasan('');
    setKeputusanSidang('');
    setRencanaAksiTindakLanjut('');
    setStatusPersetujuan('Disetujui Tim Sidang');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!judul.trim() || !keputusanSidang.trim()) {
      onShowToast('Judul sidang dan rekomendasi keputusan sidang wajib diisi.', 'error');
      return;
    }

    const newItem: CaseConferenceItem = {
      id: `cc-${Date.now()}`,
      tanggal,
      waktu,
      jenisSidang,
      judul: judul.trim(),
      pimpinanSidang: pimpinanSidang.trim(),
      notulis: notulis.trim(),
      pesertaHadir,
      latarBelakangKasus: latarBelakangKasus.trim() || (client.formData?.asesmenKronologi || 'Asesmen awal kasus anak binaan'),
      dinamikaDanPembahasan: dinamikaDanPembahasan.trim(),
      keputusanSidang: keputusanSidang.trim(),
      rencanaAksiTindakLanjut: rencanaAksiTindakLanjut.trim(),
      statusPersetujuan,
      diverifikasiOleh: pimpinanSidang.trim()
    };

    onSaveCaseConference(newItem);
    onShowToast(`Berita acara sidang kasus "${newItem.judul}" berhasil disimpan!`, 'success');
    resetForm();
    setViewMode('list');
  };

  const handlePrintBeritaAcara = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="bg-linear-to-r from-indigo-800 via-indigo-700 to-sky-700 px-6 py-4 flex items-center justify-between text-white shrink-0 no-print">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base leading-tight">
                  Sidang Pembahasan Kasus (Case Conference)
                </h3>
                <span className="bg-sky-400/30 text-white border border-sky-300/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  Forum Multidisiplin
                </span>
              </div>
              <p className="text-xs text-indigo-100 mt-0.5">
                Klien: <strong>{client.nama}</strong> ({client.id}) — Jurusan: {client.formData?.jurusan || 'Otomotif'} ({client.formData?.angkatan || 'Angkatan I'})
              </p>
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* View Switcher Bar */}
        <div className="bg-slate-100 border-b border-slate-200 px-6 py-2 flex items-center justify-between shrink-0 no-print">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                viewMode === 'list'
                  ? 'bg-white text-indigo-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Daftar Sidang Kasus ({conferences.length})</span>
            </button>

            <button
              type="button"
              onClick={() => {
                resetForm();
                setViewMode('create');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                viewMode === 'create'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Jadwalkan / Notula Sidang Baru</span>
            </button>
          </div>

          {viewMode === 'preview' && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className="text-xs font-bold text-slate-600 hover:text-slate-900 px-3 py-1 bg-white border border-slate-200 rounded-lg shadow-2xs"
              >
                Kembali
              </button>
              <button
                type="button"
                onClick={handlePrintBeritaAcara}
                className="text-xs font-bold bg-indigo-600 text-white hover:bg-indigo-700 px-3 py-1 rounded-lg flex items-center gap-1 shadow-2xs transition"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Cetak Berita Acara</span>
              </button>
            </div>
          )}
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          
          {/* =========================================================
           * VIEW 1: DAFTAR BERITA ACARA SIDANG KASUS
           * ========================================================= */}
          {viewMode === 'list' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-extrabold text-slate-900">
                    Rekam Sidang Pembahasan Kasus Multidisiplin
                  </h4>
                  <p className="text-xs text-slate-500">
                    Notula resmi penentuan arah penanganan, intervensi rujukan, dan kelulusan anak binaan.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    resetForm();
                    setViewMode('create');
                  }}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-2 px-3.5 rounded-xl shadow-xs flex items-center gap-1.5 transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah Sidang Kasus</span>
                </button>
              </div>

              {conferences.length === 0 ? (
                <div className="text-center py-12 px-4 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl space-y-3">
                  <div className="w-12 h-12 mx-auto rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center">
                    <Users className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div className="space-y-1">
                    <h5 className="text-xs font-bold text-slate-800">Belum Ada Sidang Kasus Tercatat</h5>
                    <p className="text-[11px] text-slate-500 max-w-sm mx-auto leading-relaxed">
                      Lakukan pencatatan Case Conference awal, sidang evaluasi perkembangan, atau sidang pra-terminasi bersama tim multidisiplin balai.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      resetForm();
                      setViewMode('create');
                    }}
                    className="bg-indigo-600 text-white text-xs font-bold py-2 px-4 rounded-xl shadow-xs transition hover:bg-indigo-700"
                  >
                    Mulai Catat Notula Sidang
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3.5">
                  {conferences.map((item, index) => (
                    <div 
                      key={item.id}
                      className="bg-white rounded-xl border border-slate-200 p-4 hover:border-indigo-300 shadow-2xs transition space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-md bg-indigo-100 text-indigo-700 font-bold text-xs flex items-center justify-center">
                            {index + 1}
                          </span>
                          <div>
                            <span className="font-extrabold text-sm text-slate-900 block">
                              {item.judul}
                            </span>
                            <span className="text-[11px] text-indigo-700 font-semibold">
                              {item.jenisSidang}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                            item.statusPersetujuan === 'Disetujui Tim Sidang'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : item.statusPersetujuan === 'Perlu Pendalaman Kasus'
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-rose-50 text-rose-800 border-rose-200'
                          }`}>
                            {item.statusPersetujuan}
                          </span>

                          <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                            {item.tanggal}
                          </span>
                        </div>
                      </div>

                      {/* Detail Ringkas */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/80">
                          <span className="text-[10px] font-bold text-slate-500 uppercase block mb-0.5">
                            Keputusan Sidang:
                          </span>
                          <p className="text-slate-800 font-medium line-clamp-2 leading-relaxed">
                            {item.keputusanSidang}
                          </p>
                        </div>

                        <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/80">
                          <span className="text-[10px] font-bold text-slate-500 uppercase block mb-0.5">
                            Peserta Hadir ({item.pesertaHadir.length}):
                          </span>
                          <p className="text-slate-600 line-clamp-2 leading-relaxed">
                            {item.pesertaHadir.join(', ')}
                          </p>
                        </div>
                      </div>

                      {/* Action Bar */}
                      <div className="flex items-center justify-between pt-1 text-xs">
                        <span className="text-[11px] text-slate-400">
                          Pimpinan: <strong>{item.pimpinanSidang}</strong> | Notulis: {item.notulis}
                        </span>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              setPreviewItem(item);
                              setViewMode('preview');
                            }}
                            className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 transition"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Lihat Berita Acara</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`Hapus notula sidang "${item.judul}"?`)) {
                                onDeleteCaseConference(item.id);
                                onShowToast('Notula sidang dihapus.', 'success');
                              }
                            }}
                            className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1.5 rounded-lg transition"
                            title="Hapus notula"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* =========================================================
           * VIEW 2: FORMULIR NOTULA SIDANG KASUS BARU
           * ========================================================= */}
          {viewMode === 'create' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="bg-indigo-50/60 p-3.5 rounded-xl border border-indigo-200 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-extrabold text-indigo-950">
                    Formulir Berita Acara Sidang Kasus (Case Conference)
                  </h4>
                  <p className="text-[11px] text-indigo-700">
                    Lengkapi seluruh pembahasan multidisiplin, pertimbangan klinis, dan keputusan resmi balai.
                  </p>
                </div>
                <span className="bg-indigo-200/80 text-indigo-900 text-[10px] font-bold px-2 py-0.5 rounded">
                  Format Baku UPTD PPS Griya Bina Remaja
                </span>
              </div>

              {/* Baris 1: Meta Tanggal, Waktu & Jenis Sidang */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal Sidang</label>
                  <input
                    type="date"
                    value={tanggal}
                    onChange={(e) => setTanggal(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-xs bg-white text-slate-800"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Waktu Pelaksanaan</label>
                  <input
                    type="time"
                    value={waktu}
                    onChange={(e) => setWaktu(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-xs bg-white text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Jenis Sidang Kasus</label>
                  <select
                    value={jenisSidang}
                    onChange={(e) => setJenisSidang(e.target.value as CaseConferenceType)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-xs font-bold bg-white text-slate-800"
                  >
                    <option value="Sidang Awal (Initial Case Review)">Sidang Awal (Penetapan Rencana Intervensi)</option>
                    <option value="Sidang Perkembangan (Progress Review)">Sidang Perkembangan Triwulan</option>
                    <option value="Sidang Alih Jurusan / Rujukan Khusus">Sidang Alih Jurusan / Rujukan Khusus</option>
                    <option value="Sidang Pra-Terminasi & Reintegrasi">Sidang Pra-Terminasi & Reintegrasi Keluarga</option>
                    <option value="Sidang Penanganan Krisis / Kasus Darurat">Sidang Kasus Krisis / Pelanggaran Berat</option>
                  </select>
                </div>
              </div>

              {/* Baris 2: Judul Sidang */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Judul / Topik Pembahasan Kasus</label>
                <input
                  type="text"
                  value={judul}
                  onChange={(e) => setJudul(e.target.value)}
                  placeholder="Contoh: Pembahasan Kesiapan Reintegrasi Mandiri & Uji Kompetensi Kejuruan Otomotif"
                  className="w-full rounded-lg border border-slate-300 py-2 px-3 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>

              {/* Baris 3: Pimpinan & Notulis */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Pimpinan Sidang</label>
                  <input
                    type="text"
                    value={pimpinanSidang}
                    onChange={(e) => setPimpinanSidang(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-xs bg-white text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Notulis Sidang</label>
                  <input
                    type="text"
                    value={notulis}
                    onChange={(e) => setNotulis(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-xs bg-white text-slate-800"
                  />
                </div>
              </div>

              {/* Baris 4: Peserta Hadir (Multidisiplin) */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                <label className="block text-xs font-bold text-slate-800">
                  Peserta Hadir Sidang Multidisiplin ({pesertaHadir.length}):
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {pesertaHadir.map((p) => (
                    <span 
                      key={p} 
                      className="bg-white border border-slate-300 text-slate-700 text-xs px-2.5 py-1 rounded-full flex items-center gap-1.5 shadow-2xs"
                    >
                      <span>{p}</span>
                      <button
                        type="button"
                        onClick={() => handleRemovePeserta(p)}
                        className="text-slate-400 hover:text-rose-600 rounded-full"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>

                <div className="flex gap-2 pt-1">
                  <input
                    type="text"
                    value={pesertaBaru}
                    onChange={(e) => setPesertaBaru(e.target.value)}
                    placeholder="Tambah nama peserta sidang (misal: Psikolog Klinis, Orang Tua Klien)..."
                    className="flex-1 rounded-lg border border-slate-300 py-1.5 px-3 text-xs bg-white text-slate-800"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddPeserta();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddPeserta}
                    className="bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold px-3 py-1.5 rounded-lg transition"
                  >
                    Tambah
                  </button>
                </div>
              </div>

              {/* Baris 5: Dinamika Pembahasan & Masalah */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  Dinamika Kasus & Pokok Diskusi Sidang:
                </label>
                <textarea
                  rows={3}
                  value={dinamikaDanPembahasan}
                  onChange={(e) => setDinamikaDanPembahasan(e.target.value)}
                  placeholder="Catatan pandangan Pekerja Sosial, Instruktur Kejuruan, Pengasuh Asrama, dan Tenaga Medis terkait perkembangan perilaku, kesehatan, dan keterampilan anak..."
                  className="w-full rounded-lg border border-slate-300 p-2.5 text-xs text-slate-800 leading-relaxed"
                />
              </div>

              {/* Baris 6: Rekomendasi & Keputusan Sidang */}
              <div className="bg-emerald-50/50 p-3.5 rounded-xl border border-emerald-200 space-y-2">
                <label className="block text-xs font-extrabold text-emerald-950">
                  Keputusan & Rekomendasi Hasil Sidang Kasus (Wajib):
                </label>
                <textarea
                  rows={3}
                  value={keputusanSidang}
                  onChange={(e) => setKeputusanSidang(e.target.value)}
                  placeholder="Contoh: Merekomendasikan anak untuk melanjutkan magang industri otomotif selama 1 bulan dan menyetujui reunifikasi keluarga pada bulan ke-3 binaan..."
                  className="w-full rounded-lg border border-emerald-300 p-2.5 text-xs text-slate-800 bg-white leading-relaxed focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              {/* Baris 7: Rencana Aksi & Status Persetujuan */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">Rencana Aksi Tindak Lanjut</label>
                  <input
                    type="text"
                    value={rencanaAksiTindakLanjut}
                    onChange={(e) => setRencanaAksiTindakLanjut(e.target.value)}
                    placeholder="Contoh: Kunjungan rumah peksos pekan depan & surat rekomendasi magang"
                    className="w-full rounded-lg border border-slate-300 py-2 px-3 text-xs bg-white text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">Status Persetujuan Sidang</label>
                  <select
                    value={statusPersetujuan}
                    onChange={(e) => setStatusPersetujuan(e.target.value as any)}
                    className="w-full rounded-lg border border-slate-300 py-2 px-3 text-xs font-bold bg-white text-slate-800"
                  >
                    <option value="Disetujui Tim Sidang">Disetujui Tim Sidang (Final)</option>
                    <option value="Perlu Pendalaman Kasus">Perlu Pendalaman Kasus / Asesmen Ulang</option>
                    <option value="Rujukan Eksternal">Rujukan Eksternal / Alih Kasus</option>
                  </select>
                </div>
              </div>

              {/* Tombol Simpan */}
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setViewMode('list')}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Simpan Berita Acara Sidang</span>
                </button>
              </div>
            </form>
          )}

          {/* =========================================================
           * VIEW 3: PRATINJAU & DOKUMEN CETAK BERITA ACARA RESMI
           * ========================================================= */}
          {viewMode === 'preview' && previewItem && (
            <div className="space-y-4">
              <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-300 shadow-sm space-y-6 text-slate-900">
                
                {/* Kop Surat Dokumen */}
                <div className="border-b-2 border-slate-900 pb-3 text-center space-y-1">
                  <h4 className="text-xs uppercase font-bold tracking-widest text-slate-600">
                    Pemerintah Daerah Provinsi Jawa Barat — Dinas Sosial
                  </h4>
                  <h3 className="text-sm font-extrabold text-slate-900 uppercase">
                    UPTD Pelayanan dan Perlindungan Sosial Griya Bina Remaja
                  </h3>
                  <p className="text-[10px] text-slate-600">
                    Jl. Jend. A. Yani No. 288 Bandung | Telp: (022) 7208882 | Pos: 40271
                  </p>
                </div>

                {/* Judul Berita Acara */}
                <div className="text-center space-y-0.5">
                  <h3 className="text-base font-extrabold uppercase underline">
                    BERITA ACARA & NOTULA SIDANG PEMBAHASAN KASUS
                  </h3>
                  <p className="text-xs font-mono font-semibold text-slate-600">
                    Nomor: BA-CC/{new Date(previewItem.tanggal).getFullYear()}/{previewItem.id.slice(-6).toUpperCase()}
                  </p>
                </div>

                {/* Ringkasan Sidang */}
                <div className="text-xs space-y-2 border border-slate-200 p-4 rounded-lg bg-slate-50/60 leading-relaxed">
                  <p>
                    Pada hari ini <strong>{new Date(previewItem.tanggal).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</strong>, bertempat di Ruang Sidang Kasus UPTD PPS Griya Bina Remaja, telah dilaksanakan <strong>{previewItem.jenisSidang}</strong> dengan agenda:
                  </p>
                  <p className="font-bold text-indigo-950 pl-4 border-l-2 border-indigo-400">
                    "{previewItem.judul}"
                  </p>
                </div>

                {/* Data Klien */}
                <div className="grid grid-cols-2 gap-2 text-xs border border-slate-200 p-3 rounded-lg">
                  <div>
                    <span className="text-slate-500 block text-[11px]">Nama Anak Binaan:</span>
                    <strong className="text-slate-900">{client.nama} ({client.gender}, {client.umur} Thn)</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Nomor Registrasi / Angkatan:</span>
                    <strong className="text-slate-900">{client.id} / {client.formData?.angkatan || 'Angkatan I'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Jurusan Vokasi / Asrama:</span>
                    <strong className="text-slate-900">{client.formData?.jurusan || 'Otomotif'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Kabupaten/Kota Asal:</span>
                    <strong className="text-slate-900">{client.formData?.kabupatenKota || '-'}</strong>
                  </div>
                </div>

                {/* Dinamika Pembahasan */}
                <div className="text-xs space-y-1">
                  <strong className="block text-slate-900 uppercase tracking-wide">
                    I. Pokok Pembahasan & Dinamika Multidisiplin:
                  </strong>
                  <p className="text-slate-800 leading-relaxed text-justify bg-slate-50 p-3 rounded border border-slate-200">
                    {previewItem.dinamikaDanPembahasan || previewItem.latarBelakangKasus || 'Seluruh anggota tim sidang multidisiplin telah memberikan analisis dan evaluasi terkait perkembangan psikososial, fisik, dan kejuruan klien.'}
                  </p>
                </div>

                {/* Keputusan Sidang */}
                <div className="text-xs space-y-1">
                  <strong className="block text-slate-900 uppercase tracking-wide">
                    II. Keputusan & Rekomendasi Resmi Sidang:
                  </strong>
                  <div className="bg-emerald-50 p-3.5 rounded border border-emerald-300 text-emerald-950 leading-relaxed font-semibold">
                    {previewItem.keputusanSidang}
                  </div>
                </div>

                {/* Rencana Aksi */}
                {previewItem.rencanaAksiTindakLanjut && (
                  <div className="text-xs space-y-1">
                    <strong className="block text-slate-900 uppercase tracking-wide">
                      III. Tindak Lanjut & Rencana Aksi:
                    </strong>
                    <p className="text-slate-800 leading-relaxed">
                      {previewItem.rencanaAksiTindakLanjut}
                    </p>
                  </div>
                )}

                {/* Tanda Tangan Tim Sidang */}
                <div className="pt-6 border-t border-slate-200">
                  <p className="text-center text-xs font-bold uppercase text-slate-700 mb-6">
                    TIM SIDANG KASUS MULTIDISIPLIN
                  </p>

                  <div className="grid grid-cols-2 gap-8 text-xs text-center">
                    <div>
                      <p className="text-slate-500">Notulis / Pekerja Sosial Kasus,</p>
                      <div className="h-16 flex items-end justify-center font-bold text-slate-900">
                        {previewItem.notulis}
                      </div>
                      <p className="text-[10px] text-slate-500">Pekerja Sosial Ahli Pertama</p>
                    </div>

                    <div>
                      <p className="text-slate-500">Pimpinan Sidang Kasus,</p>
                      <div className="h-16 flex items-end justify-center font-bold text-slate-900">
                        {previewItem.pimpinanSidang}
                      </div>
                      <p className="text-[10px] text-slate-500">UPTD PPS Griya Bina Remaja</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0 no-print">
          <span className="text-[11px] text-slate-500">
            Kerahasiaan Rekam Medis Sosial Terjamin & Terakreditasi Nasional
          </span>

          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition shadow-2xs"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
