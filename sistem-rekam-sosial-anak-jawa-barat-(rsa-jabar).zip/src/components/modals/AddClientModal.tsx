import React, { useState, useMemo } from 'react';
import { X, UserPlus, FileSpreadsheet, Hash, AlertCircle } from 'lucide-react';
import { JAWA_BARAT_REGIONS } from '../../data/defaultData';
import { Client, ClientStatus } from '../../types';
import {
  generateClientId,
  getRegionCode,
  extractAngkatanRoman,
  extractBudgetYear,
} from '../../utils/clientIdGenerator';

interface AddClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: {
    nama: string;
    kabupatenKota: string;
    angkatan: string;
    tanggalLahir: string;
    gender: 'Laki-laki' | 'Perempuan';
    status: ClientStatus;
  }) => void;
  allAngkatanList: string[];
  existingClients?: Client[];
  onOpenExcelImport?: () => void;
}

export const AddClientModal: React.FC<AddClientModalProps> = ({
  isOpen,
  onClose,
  onSave,
  allAngkatanList,
  existingClients = [],
  onOpenExcelImport,
}) => {
  const [nama, setNama] = useState('');
  const [kabupatenKota, setKabupatenKota] = useState('');
  const [angkatan, setAngkatan] = useState('Angkatan I - 2026');
  const [tanggalLahir, setTanggalLahir] = useState('');
  const [gender, setGender] = useState<'Laki-laki' | 'Perempuan'>('Laki-laki');
  const [status, setStatus] = useState<ClientStatus>('Calon Klien (Proses Seleksi)');
  const [formError, setFormError] = useState<string | null>(null);

  const previewClientId = useMemo(() => {
    if (!kabupatenKota) return null;
    return generateClientId({
      kabupatenKota,
      angkatan: angkatan || 'Angkatan I - 2026',
      existingClients,
    });
  }, [kabupatenKota, angkatan, existingClients]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nama.trim() || !kabupatenKota) {
      setFormError('Nama lengkap dan Kabupaten/Kota asal wajib diisi!');
      return;
    }

    setFormError(null);
    onSave({
      nama: nama.trim(),
      kabupatenKota,
      angkatan: angkatan.trim(),
      tanggalLahir,
      gender,
      status,
    });

    setNama('');
    setKabupatenKota('');
    setTanggalLahir('');
    onClose();
  };

  const regionNum = kabupatenKota ? getRegionCode(kabupatenKota) : null;
  const angkatanRomawi = extractAngkatanRoman(angkatan || 'Angkatan I - 2026');
  const tahunAnggaran = extractBudgetYear(angkatan || 'Angkatan I - 2026');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs no-print">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-sky-600 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <UserPlus className="w-5 h-5" />
            <h3 className="font-bold text-base">Registrasi Anak Binaan Baru</h3>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {formError && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span className="font-semibold">{formError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">Nama Lengkap Anak</label>
              <input
                type="text"
                required
                value={nama}
                onChange={(e) => {
                  setNama(e.target.value);
                  if (formError) setFormError(null);
                }}
                placeholder="Contoh: Muhammad Farhan"
                className="w-full rounded-lg border border-slate-300 py-2 px-3 text-sm focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Kabupaten/Kota Asal (Jawa Barat)</label>
              <select
                required
                value={kabupatenKota}
                onChange={(e) => {
                  setKabupatenKota(e.target.value);
                  if (formError) setFormError(null);
                }}
                className="w-full rounded-lg border border-slate-300 py-2 px-3 text-sm focus:ring-2 focus:ring-sky-500 bg-white"
              >
                <option value="">- Pilih Kabupaten/Kota -</option>
                {JAWA_BARAT_REGIONS.map((reg, idx) => (
                  <option key={reg} value={reg}>
                    {idx + 1}. {reg}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Angkatan / Gelombang</label>
              <input
                type="text"
                list="modal-angkatan-list"
                value={angkatan}
                onChange={(e) => setAngkatan(e.target.value)}
                placeholder="Contoh: Angkatan III - 2026"
                className="w-full rounded-lg border border-slate-300 py-2 px-3 text-sm focus:ring-2 focus:ring-sky-500"
              />
              <datalist id="modal-angkatan-list">
                {allAngkatanList.map((a) => (
                  <option key={a} value={a} />
                ))}
              </datalist>
            </div>

            {/* Pratinjau ID Registrasi Otomatis */}
            <div className="sm:col-span-2 bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs text-slate-700">
                <Hash className="w-4 h-4 text-sky-600 shrink-0" />
                <div>
                  <span className="font-bold text-slate-800">ID Registrasi Otomatis:</span>
                  <p className="text-[11px] text-slate-500">
                    Format: [Urut]-[No. Kab/Kota]-[Angkatan Romawi]-[Tahun Anggaran]
                  </p>
                </div>
              </div>
              {previewClientId ? (
                <div className="text-right shrink-0">
                  <span className="inline-block font-mono text-sm font-extrabold bg-sky-100 text-sky-900 border border-sky-300 px-3 py-1 rounded-lg">
                    {previewClientId}
                  </span>
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    Daerah #{regionNum} • Angkatan {angkatanRomawi} • TA {tahunAnggaran}
                  </p>
                </div>
              ) : (
                <span className="text-[11px] italic text-slate-400">
                  Pilih Kabupaten/Kota untuk pratinjau ID
                </span>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal Lahir</label>
              <input
                type="date"
                value={tanggalLahir}
                onChange={(e) => setTanggalLahir(e.target.value)}
                className="w-full rounded-lg border border-slate-300 py-2 px-3 text-sm focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Jenis Kelamin</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
                className="w-full rounded-lg border border-slate-300 py-2 px-3 text-sm focus:ring-2 focus:ring-sky-500 bg-white"
              >
                <option value="Laki-laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">Status Awal</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as ClientStatus)}
                className="w-full rounded-lg border border-sky-300 bg-sky-50/50 py-2 px-3 text-sm font-bold text-sky-950 focus:ring-2 focus:ring-sky-500"
              >
                <option value="Calon Klien (Proses Seleksi)">Calon Klien (Tahap Skrining / Seleksi)</option>
                <option value="Kasus Aktif">Kasus Aktif (Langsung Diterima)</option>
              </select>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            {onOpenExcelImport ? (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenExcelImport();
                }}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1.5 transition py-1"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>Atau Impor Massal dari Excel (.xlsx)</span>
              </button>
            ) : <div />}

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg transition"
              >
                Batal
              </button>
              <button
                type="submit"
                className="bg-sky-600 hover:bg-sky-700 text-white px-5 py-2 text-xs font-bold rounded-lg shadow-sm transition"
              >
                Simpan Data Anak
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

