import React, { useState } from 'react';
import { X, Settings2, Plus, Trash2 } from 'lucide-react';

interface ManageJurusanModalProps {
  isOpen: boolean;
  onClose: () => void;
  jurusanList: string[];
  onAddJurusan: (name: string) => void;
  onRemoveJurusan: (index: number) => void;
}

export const ManageJurusanModal: React.FC<ManageJurusanModalProps> = ({
  isOpen,
  onClose,
  jurusanList,
  onAddJurusan,
  onRemoveJurusan,
}) => {
  const [newJurusan, setNewJurusan] = useState('');

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (newJurusan.trim()) {
      onAddJurusan(newJurusan.trim());
      setNewJurusan('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs no-print">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-sky-600 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <Settings2 className="w-5 h-5" />
            <h3 className="font-bold text-base">Master Data Jurusan Keterampilan</h3>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <form onSubmit={handleAdd} className="flex gap-2">
            <input
              type="text"
              value={newJurusan}
              onChange={(e) => setNewJurusan(e.target.value)}
              placeholder="Nama kejuruan baru..."
              className="flex-1 rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500"
            />
            <button
              type="submit"
              className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-4 py-1.5 rounded-lg text-xs flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Tambah
            </button>
          </form>

          <div className="border border-slate-200 rounded-xl overflow-hidden max-h-64 overflow-y-auto">
            <ul className="divide-y divide-slate-200">
              {jurusanList.map((j, idx) => (
                <li key={idx} className="p-3 flex items-center justify-between text-sm bg-white hover:bg-slate-50">
                  <span className="font-medium text-slate-800">{j}</span>
                  <button
                    type="button"
                    onClick={() => onRemoveJurusan(idx)}
                    className="text-rose-500 hover:text-rose-700 p-1"
                    title="Hapus"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
