import React, { useEffect, useMemo, useState } from 'react';
import {
  X,
  Shield,
  Users,
  Database,
  Lock,
  Search,
  Trash2,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Download,
  ExternalLink,
  Copy,
  Check,
  UserCheck,
  UserX,
  Plus,
  LogOut,
  Clock,
  FileWarning,
} from 'lucide-react';
import { AppUserProfile, Client, ClientStatus, UserRole } from '../../types';
import {
  fetchAllUsers,
  isBootstrappedAdminEmail,
  updateUserByAdmin,
} from '../../firebase';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  clients: Client[];
  currentUserEmail?: string | null;
  currentUserUid?: string | null;
  isCloudConnected: boolean;
  jurusanList: string[];
  idleTimeoutMinutes: number;
  onChangeIdleTimeout: (minutes: number) => void;
  onAddJurusan: (name: string) => void;
  onRemoveJurusan: (index: number) => void;
  onSelectClient: (clientId: string) => void;
  onUpdateClientStatus: (clientId: string, status: ClientStatus) => Promise<void> | void;
  onDeleteClient: (clientId: string) => Promise<void>;
  onSeedInitialClients: () => Promise<void>;
  onExportAllJSON: () => void;
  onSignOut: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

type AdminTab = 'overview' | 'clients' | 'users' | 'security';

const CLIENT_STATUSES: ClientStatus[] = [
  'Calon Klien (Proses Seleksi)',
  'Kasus Aktif',
  'Terminasi (Selesai)',
  'Referal (Rujukan)',
  'Drop Out',
  'Ditolak (Tidak Memenuhi Syarat)',
];

const RECOMMENDED_RULES_SNIPPET = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} { allow read, write: if false; }
    function isSignedIn() { return request.auth != null; }
    function isBootstrappedAdmin() {
      return isSignedIn() && (
        request.auth.token.email == 'falamsyahy@gmail.com' ||
        request.auth.token.email == '199408162020121011@jabarprov.go.id'
      );
    }
    function isAdmin() {
      return isBootstrappedAdmin() || (
        isSignedIn() &&
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin' &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.disabled != true
      );
    }
    match /clients/{clientId} {
      allow get, list, create, update: if isSignedIn();
      allow delete: if isAdmin();
    }
    match /users/{userId} {
      allow get: if isSignedIn() && (request.auth.uid == userId || isAdmin());
      allow list: if isBootstrappedAdmin();
      allow create: if isSignedIn() && (isAdmin() || (request.auth.uid == userId && request.resource.data.role == 'peksos'));
      allow update: if isSignedIn() && (isAdmin() || (request.auth.uid == userId && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['nama', 'lastLoginAt', 'updatedAt'])));
      allow delete: if isAdmin();
    }
    match /test/connection { allow get: if true; }
  }
}`;

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  clients,
  currentUserEmail,
  currentUserUid,
  isCloudConnected,
  jurusanList,
  idleTimeoutMinutes,
  onChangeIdleTimeout,
  onAddJurusan,
  onRemoveJurusan,
  onSelectClient,
  onUpdateClientStatus,
  onDeleteClient,
  onSeedInitialClients,
  onExportAllJSON,
  onSignOut,
  onShowToast,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [clientSearch, setClientSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [seeding, setSeeding] = useState(false);

  // Users state
  const [users, setUsers] = useState<AppUserProfile[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [usersError, setUsersError] = useState<string | null>(null);
  const [updatingUid, setUpdatingUid] = useState<string | null>(null);

  // Jurusan input
  const [newJurusan, setNewJurusan] = useState('');
  const [copiedRules, setCopiedRules] = useState(false);

  const loadUsers = async () => {
    setLoadingUsers(true);
    setUsersError(null);
    try {
      const list = await fetchAllUsers();
      setUsers(list);
    } catch (err: any) {
      setUsersError(
        err?.message ||
          'Tidak dapat memuat daftar pengguna dari Firestore. Pastikan aturan keamanan /users sudah mengizinkan Admin.'
      );
    } finally {
      setLoadingUsers(false);
    }
  };

  useEffect(() => {
    if (isOpen && activeTab === 'users') {
      loadUsers();
    }
  }, [isOpen, activeTab]);

  // Metrics & Audits
  const stats = useMemo(() => {
    const totalClients = clients.length;
    const activeCount = clients.filter((c) => c.status === 'Kasus Aktif').length;
    const candidateCount = clients.filter(
      (c) => c.status === 'Calon Klien (Proses Seleksi)'
    ).length;

    let totalAttachments = 0;
    let totalAttachmentKb = 0;
    clients.forEach((c) => {
      const files = c.berkasDigital || [];
      totalAttachments += files.length;
      files.forEach((f) => {
        totalAttachmentKb += f.ukuranKb || 0;
      });
    });

    const missingDataAudit = clients
      .map((c) => {
        const missing: string[] = [];
        if (!c.formData?.noIdentitas?.trim()) missing.push('NIK');
        const hasKK = (c.berkasDigital || []).some((b) =>
          b.kategori.includes('Kartu Keluarga')
        );
        if (!hasKK) missing.push('Berkas KK');
        if (!c.kontrakPelayanan) missing.push('Kontrak 3 Bulan');
        return { client: c, missing };
      })
      .filter((item) => item.missing.length > 0);

    return {
      totalClients,
      activeCount,
      candidateCount,
      totalAttachments,
      totalAttachmentKb,
      missingDataAudit,
    };
  }, [clients]);

  const filteredClients = useMemo(() => {
    const q = clientSearch.trim().toLowerCase();
    return clients.filter((c) => {
      const matchStatus = !statusFilter || c.status === statusFilter;
      const matchSearch =
        !q ||
        c.nama.toLowerCase().includes(q) ||
        c.id.toLowerCase().includes(q) ||
        (c.formData?.kabupatenKota || '').toLowerCase().includes(q) ||
        (c.formData?.angkatan || '').toLowerCase().includes(q);
      return matchStatus && matchSearch;
    });
  }, [clients, clientSearch, statusFilter]);

  if (!isOpen) return null;

  const handleConfirmDelete = async (client: Client) => {
    setDeletingId(client.id);
    try {
      await onDeleteClient(client.id);
      setConfirmDeleteId(null);
    } finally {
      setDeletingId(null);
    }
  };

  const handleToggleUserRole = async (target: AppUserProfile) => {
    if (target.uid === currentUserUid) {
      onShowToast('Anda tidak dapat menurunkan peran admin akun sendiri.', 'error');
      return;
    }
    if (isBootstrappedAdminEmail(target.email) && target.role === 'admin') {
      onShowToast('Admin utama bawaan sistem tidak dapat diturunkan perannya.', 'error');
      return;
    }
    const nextRole: UserRole = target.role === 'admin' ? 'peksos' : 'admin';
    setUpdatingUid(target.uid);
    try {
      await updateUserByAdmin(target.uid, { role: nextRole });
      setUsers((prev) =>
        prev.map((u) => (u.uid === target.uid ? { ...u, role: nextRole } : u))
      );
      onShowToast(
        `Peran ${target.nama || target.email} diubah menjadi ${
          nextRole === 'admin' ? 'Administrator' : 'Pekerja Sosial'
        }.`,
        'success'
      );
    } catch (err: any) {
      onShowToast(err?.message || 'Gagal mengubah peran pengguna.', 'error');
    } finally {
      setUpdatingUid(null);
    }
  };

  const handleToggleUserDisabled = async (target: AppUserProfile) => {
    if (target.uid === currentUserUid || isBootstrappedAdminEmail(target.email)) {
      onShowToast('Akun administrator utama tidak dapat dinonaktifkan.', 'error');
      return;
    }
    const nextDisabled = !target.disabled;
    setUpdatingUid(target.uid);
    try {
      await updateUserByAdmin(target.uid, { disabled: nextDisabled });
      setUsers((prev) =>
        prev.map((u) => (u.uid === target.uid ? { ...u, disabled: nextDisabled } : u))
      );
      onShowToast(
        nextDisabled
          ? `Akses ${target.email} dinonaktifkan.`
          : `Akses ${target.email} diaktifkan kembali.`,
        'success'
      );
    } catch (err: any) {
      onShowToast(err?.message || 'Gagal mengubah status akun.', 'error');
    } finally {
      setUpdatingUid(null);
    }
  };

  const handleCopyRules = () => {
    navigator.clipboard.writeText(RECOMMENDED_RULES_SNIPPET);
    setCopiedRules(true);
    setTimeout(() => setCopiedRules(false), 2000);
    onShowToast('Aturan Firestore berhasil disalin ke clipboard.', 'success');
  };

  const handleAddNewJurusan = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newJurusan.trim();
    if (!trimmed) return;
    if (jurusanList.includes(trimmed)) {
      onShowToast('Jurusan tersebut sudah tersedia.', 'error');
      return;
    }
    onAddJurusan(trimmed);
    setNewJurusan('');
    onShowToast(`Jurusan "${trimmed}" ditambahkan.`, 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs no-print">
      <div className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full h-[90vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Top Bar */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-sky-600 flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <h3 className="font-bold text-base truncate">Panel Administrator RSA Jabar</h3>
              <p className="text-xs text-slate-300 truncate">
                {currentUserEmail || 'Administrator'} · {isCloudConnected ? 'Cloud Terhubung' : 'Mode Lokal'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onSignOut}
              className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold flex items-center gap-1.5 transition whitespace-nowrap"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Keluar & Kunci Sesi</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="text-slate-300 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition"
              aria-label="Tutup Panel Admin"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 flex items-center gap-1 overflow-x-auto shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-3 text-xs font-semibold border-b-2 transition whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'overview'
                ? 'border-sky-700 text-sky-800 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Ringkasan & Audit Data</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('clients')}
            className={`px-4 py-3 text-xs font-semibold border-b-2 transition whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'clients'
                ? 'border-sky-700 text-sky-800 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Manajemen Klien ({clients.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('users')}
            className={`px-4 py-3 text-xs font-semibold border-b-2 transition whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'users'
                ? 'border-sky-700 text-sky-800 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Akun & Hak Akses</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('security')}
            className={`px-4 py-3 text-xs font-semibold border-b-2 transition whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'security'
                ? 'border-sky-700 text-sky-800 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Keamanan Sesi & Balai</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-white">
          {/* TAB 1: OVERVIEW & AUDIT */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
                  <p className="text-xs font-medium text-slate-500">Total Anak Binaan</p>
                  <p className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
                    {stats.totalClients}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">Seluruh status terekam</p>
                </div>

                <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
                  <p className="text-xs font-medium text-slate-500">Kasus Aktif / Seleksi</p>
                  <p className="text-2xl font-bold text-sky-700 mt-1 tabular-nums">
                    {stats.activeCount} / {stats.candidateCount}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">Binaan berjalan & calon</p>
                </div>

                <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
                  <p className="text-xs font-medium text-slate-500">Berkas Digital Terlampir</p>
                  <p className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
                    {stats.totalAttachments}
                  </p>
                  <p className="text-xs text-slate-500 mt-1 tabular-nums">
                    Total ukuran: {(stats.totalAttachmentKb / 1024).toFixed(2)} MB
                  </p>
                </div>

                <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
                  <p className="text-xs font-medium text-slate-500">Auto-Logout Idle</p>
                  <p className="text-2xl font-bold text-emerald-700 mt-1 tabular-nums">
                    {idleTimeoutMinutes > 0 ? `${idleTimeoutMinutes} mnt` : 'Nonaktif'}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">Cache dihapus saat keluar</p>
                </div>
              </div>

              {/* Audit Kelengkapan */}
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <FileWarning className="w-4 h-4 text-amber-600" />
                    <h4 className="text-sm font-bold text-slate-900">
                      Audit Kelengkapan Dokumen Wajib ({stats.missingDataAudit.length} Klien)
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={onExportAllJSON}
                    className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Unduh Cadangan JSON</span>
                  </button>
                </div>

                {stats.missingDataAudit.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-500 space-y-1">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                    <p className="font-semibold text-slate-800">Semua Rekam Anak Lengkap</p>
                    <p>Seluruh klien telah memiliki NIK, Berkas KK, dan Kontrak 3 Bulan.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto max-h-80">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0">
                        <tr>
                          <th className="py-2.5 px-4 font-semibold">ID Registrasi</th>
                          <th className="py-2.5 px-4 font-semibold">Nama Anak</th>
                          <th className="py-2.5 px-4 font-semibold">Kab/Kota</th>
                          <th className="py-2.5 px-4 font-semibold">Dokumen Belum Lengkap</th>
                          <th className="py-2.5 px-4 font-semibold text-right">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {stats.missingDataAudit.map(({ client, missing }) => (
                          <tr key={client.id} className="hover:bg-slate-50">
                            <td className="py-2.5 px-4 font-mono text-slate-700 whitespace-nowrap">
                              {client.id}
                            </td>
                            <td className="py-2.5 px-4 font-semibold text-slate-900">
                              {client.nama}
                            </td>
                            <td className="py-2.5 px-4 text-slate-600">
                              {client.formData?.kabupatenKota || '-'}
                            </td>
                            <td className="py-2.5 px-4 text-amber-800 font-medium">
                              {missing.join(' · ')}
                            </td>
                            <td className="py-2.5 px-4 text-right">
                              <button
                                type="button"
                                onClick={() => {
                                  onSelectClient(client.id);
                                  onClose();
                                }}
                                className="inline-flex items-center gap-1 text-sky-700 hover:text-sky-900 font-semibold"
                              >
                                <span>Buka Rekam</span>
                                <ExternalLink className="w-3 h-3" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: CLIENT DATABASE MANAGER */}
          {activeTab === 'clients' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={clientSearch}
                    onChange={(e) => setClientSearch(e.target.value)}
                    placeholder="Cari nama, ID (1-26-III-2026), wilayah, atau angkatan..."
                    className="w-full rounded-lg border border-slate-300 py-2 pl-9 pr-3 text-xs focus:outline-none focus:ring-2 focus:ring-sky-600"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="rounded-lg border border-slate-300 py-2 px-3 text-xs bg-white text-slate-700"
                  >
                    <option value="">Semua Status</option>
                    {CLIENT_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>

                  {clients.length === 0 && (
                    <button
                      type="button"
                      disabled={seeding}
                      onClick={async () => {
                        setSeeding(true);
                        try {
                          await onSeedInitialClients();
                        } finally {
                          setSeeding(false);
                        }
                      }}
                      className="px-3 py-2 rounded-lg bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold whitespace-nowrap disabled:opacity-50"
                    >
                      {seeding ? 'Memuat...' : 'Muat Data Contoh Awal'}
                    </button>
                  )}
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="overflow-x-auto max-h-[54vh]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0">
                      <tr>
                        <th className="py-2.5 px-3 font-semibold">ID</th>
                        <th className="py-2.5 px-3 font-semibold">Nama Anak</th>
                        <th className="py-2.5 px-3 font-semibold">Kab/Kota & Angkatan</th>
                        <th className="py-2.5 px-3 font-semibold">Status Pembinaan</th>
                        <th className="py-2.5 px-3 font-semibold text-right">Berkas</th>
                        <th className="py-2.5 px-3 font-semibold text-right">Aksi Admin</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredClients.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-10 text-center text-slate-500">
                            Tidak ada data klien yang cocok dengan pencarian Anda.
                          </td>
                        </tr>
                      ) : (
                        filteredClients.map((c) => {
                          const isConfirming = confirmDeleteId === c.id;
                          const isBusy = deletingId === c.id;

                          return (
                            <tr key={c.id} className="hover:bg-slate-50">
                              <td className="py-2.5 px-3 font-mono text-slate-700 whitespace-nowrap">
                                {c.id}
                              </td>
                              <td className="py-2.5 px-3">
                                <button
                                  type="button"
                                  onClick={() => {
                                    onSelectClient(c.id);
                                    onClose();
                                  }}
                                  className="font-semibold text-slate-900 hover:text-sky-700 text-left"
                                >
                                  {c.nama}
                                </button>
                              </td>
                              <td className="py-2.5 px-3 text-slate-600">
                                <span>{c.formData?.kabupatenKota || '-'}</span>
                                <span className="mx-1.5 text-slate-300">·</span>
                                <span>{c.formData?.angkatan || '-'}</span>
                              </td>
                              <td className="py-2.5 px-3">
                                <select
                                  value={c.status}
                                  onChange={(e) =>
                                    onUpdateClientStatus(c.id, e.target.value as ClientStatus)
                                  }
                                  className="rounded-md border border-slate-300 py-1 px-2 text-xs bg-white text-slate-800"
                                >
                                  {CLIENT_STATUSES.map((st) => (
                                    <option key={st} value={st}>
                                      {st}
                                    </option>
                                  ))}
                                </select>
                              </td>
                              <td className="py-2.5 px-3 text-right tabular-nums text-slate-700">
                                {c.berkasDigital?.length || 0}
                              </td>
                              <td className="py-2.5 px-3 text-right whitespace-nowrap">
                                {isConfirming ? (
                                  <div className="inline-flex items-center gap-1.5">
                                    <button
                                      type="button"
                                      disabled={isBusy}
                                      onClick={() => handleConfirmDelete(c)}
                                      className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-700 text-white font-semibold disabled:opacity-50"
                                    >
                                      {isBusy ? 'Menghapus...' : 'Ya, Hapus'}
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => setConfirmDeleteId(null)}
                                      className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                                    >
                                      Batal
                                    </button>
                                  </div>
                                ) : (
                                  <button
                                    type="button"
                                    onClick={() => setConfirmDeleteId(c.id)}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-rose-600 hover:bg-rose-50 font-semibold"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                    <span>Hapus</span>
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: USERS & RBAC */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    Daftar Akun Terdaftar (Koleksi Firestore /users)
                  </h4>
                  <p className="text-xs text-slate-500">
                    Kelola peran Administrator dan Pekerja Sosial, atau nonaktifkan akun yang sudah tidak bertugas.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={loadUsers}
                  disabled={loadingUsers}
                  className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingUsers ? 'animate-spin' : ''}`} />
                  <span>Muat Ulang</span>
                </button>
              </div>

              {usersError && (
                <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs space-y-2">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <p className="font-bold">Daftar akun cloud belum dapat dibaca:</p>
                      <p>{usersError}</p>
                      <p className="text-amber-800">
                        Pastikan Rules Firestore di proyek <strong>semarakppsgbr</strong> mengizinkan operasi <code>list</code> &amp; <code>update</code> pada koleksi <code>/users</code> untuk email admin Anda (salin aturan di tab Keamanan Sesi &amp; Balai).
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="overflow-x-auto max-h-[52vh]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0">
                      <tr>
                        <th className="py-2.5 px-4 font-semibold">Nama Petugas</th>
                        <th className="py-2.5 px-4 font-semibold">Email</th>
                        <th className="py-2.5 px-4 font-semibold">Peran</th>
                        <th className="py-2.5 px-4 font-semibold">Status Akses</th>
                        <th className="py-2.5 px-4 font-semibold">Masuk Terakhir</th>
                        <th className="py-2.5 px-4 font-semibold text-right">Pengaturan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {loadingUsers ? (
                        <tr>
                          <td colSpan={6} className="py-10 text-center text-slate-500">
                            Memuat daftar pengguna...
                          </td>
                        </tr>
                      ) : users.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-10 text-center text-slate-500">
                            Belum ada catatan pengguna lain di Firestore. Pengguna baru otomatis tercatat saat masuk.
                          </td>
                        </tr>
                      ) : (
                        users.map((u) => {
                          const isSelf = u.uid === currentUserUid;
                          const isPrimaryAdmin = isBootstrappedAdminEmail(u.email);
                          const isBusy = updatingUid === u.uid;

                          return (
                            <tr key={u.uid} className="hover:bg-slate-50">
                              <td className="py-2.5 px-4 font-semibold text-slate-900">
                                {u.nama || '-'} {isSelf ? '(Anda)' : ''}
                              </td>
                              <td className="py-2.5 px-4 font-mono text-slate-600">{u.email}</td>
                              <td className="py-2.5 px-4 font-semibold">
                                {u.role === 'admin' || isPrimaryAdmin ? (
                                  <span className="text-sky-700">Administrator</span>
                                ) : (
                                  <span className="text-slate-600">Pekerja Sosial</span>
                                )}
                              </td>
                              <td className="py-2.5 px-4">
                                {u.disabled ? (
                                  <span className="text-rose-700 font-semibold">Dinonaktifkan</span>
                                ) : (
                                  <span className="text-emerald-700 font-semibold">Aktif</span>
                                )}
                              </td>
                              <td className="py-2.5 px-4 text-slate-500 tabular-nums">
                                {u.lastLoginAt
                                  ? new Date(u.lastLoginAt).toLocaleString('id-ID')
                                  : '-'}
                              </td>
                              <td className="py-2.5 px-4 text-right whitespace-nowrap space-x-2">
                                <button
                                  type="button"
                                  disabled={isBusy || isSelf || isPrimaryAdmin}
                                  onClick={() => handleToggleUserRole(u)}
                                  className="px-2.5 py-1 rounded border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-semibold disabled:opacity-40"
                                >
                                  {u.role === 'admin' ? 'Jadikan Peksos' : 'Jadikan Admin'}
                                </button>
                                <button
                                  type="button"
                                  disabled={isBusy || isSelf || isPrimaryAdmin}
                                  onClick={() => handleToggleUserDisabled(u)}
                                  className={`px-2.5 py-1 rounded font-semibold inline-flex items-center gap-1 disabled:opacity-40 ${
                                    u.disabled
                                      ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                      : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                                  }`}
                                >
                                  {u.disabled ? (
                                    <>
                                      <UserCheck className="w-3 h-3" />
                                      <span>Aktifkan</span>
                                    </>
                                  ) : (
                                    <>
                                      <UserX className="w-3 h-3" />
                                      <span>Nonaktifkan</span>
                                    </>
                                  )}
                                </button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: SECURITY & BALAI CONFIG */}
          {activeTab === 'security' && (
            <div className="space-y-6">
              {/* Session Idle Timeout */}
              <div className="border border-slate-200 rounded-xl p-5 space-y-3">
                <div className="flex items-start justify-between gap-4 flex-col sm:flex-row">
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-sky-700" />
                      <span>Kunci Sesi Otomatis (Auto-Logout Tidak Aktif)</span>
                    </h4>
                    <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
                      Jika komputer atau tablet balai ditinggal tanpa aktivitas, sistem akan keluar otomatis ke halaman login dan membersihkan data anak dari memori peramban.
                    </p>
                  </div>
                  <select
                    value={idleTimeoutMinutes}
                    onChange={(e) => onChangeIdleTimeout(Number(e.target.value))}
                    className="rounded-lg border border-slate-300 py-2 px-3 text-xs font-semibold bg-white text-slate-800 shrink-0"
                  >
                    <option value={0}>Nonaktif (Manual Logout)</option>
                    <option value={15}>15 Menit Tidak Aktif</option>
                    <option value={30}>30 Menit Tidak Aktif</option>
                    <option value={60}>60 Menit Tidak Aktif</option>
                  </select>
                </div>
              </div>

              {/* Jurusan Management */}
              <div className="border border-slate-200 rounded-xl p-5 space-y-4">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    Daftar Jurusan Vokasi Balai ({jurusanList.length})
                  </h4>
                  <p className="text-xs text-slate-500">
                    Kelola program kejuruan yang tampil pada formulir profil dan registrasi anak.
                  </p>
                </div>

                <form onSubmit={handleAddNewJurusan} className="flex gap-2 max-w-md">
                  <input
                    type="text"
                    value={newJurusan}
                    onChange={(e) => setNewJurusan(e.target.value)}
                    placeholder="Tambah nama jurusan vokasi baru..."
                    className="flex-1 rounded-lg border border-slate-300 py-2 px-3 text-xs focus:outline-none focus:ring-2 focus:ring-sky-600"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-2 rounded-lg bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Tambah</span>
                  </button>
                </form>

                <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg max-h-48 overflow-y-auto">
                  {jurusanList.map((j, idx) => (
                    <div
                      key={`${j}-${idx}`}
                      className="px-3.5 py-2 flex items-center justify-between text-xs hover:bg-slate-50"
                    >
                      <span className="font-medium text-slate-800">{j}</span>
                      <button
                        type="button"
                        onClick={() => onRemoveJurusan(idx)}
                        className="text-rose-600 hover:text-rose-800 font-semibold"
                      >
                        Hapus
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Copyable Firestore Rules for semarakppsgbr */}
              <div className="border border-slate-200 rounded-xl p-5 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">
                      Referensi Aturan Keamanan Firestore (semarakppsgbr)
                    </h4>
                    <p className="text-xs text-slate-500">
                      Pastikan aturan di Firebase Console proyek <code>semarakppsgbr</code> sesuai agar data anak dan manajemen admin terlindungi di sisi server.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyRules}
                    className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-1.5 shrink-0"
                  >
                    {copiedRules ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedRules ? 'Tersalin' : 'Salin Rules'}</span>
                  </button>
                </div>

                <pre className="bg-slate-900 text-slate-100 p-3.5 rounded-lg text-[11px] font-mono overflow-x-auto max-h-48 leading-relaxed">
                  {RECOMMENDED_RULES_SNIPPET}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-3 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span>Akses Administrator Terverifikasi · Data anak terisolasi per sesi login</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-700 font-semibold hover:bg-slate-100"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
