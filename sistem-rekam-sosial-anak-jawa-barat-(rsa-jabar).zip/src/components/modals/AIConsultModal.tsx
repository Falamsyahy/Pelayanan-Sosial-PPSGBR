import React, { useState } from 'react';
import { X, Sparkles, Send, Loader2, Bot, HelpCircle, ShieldCheck } from 'lucide-react';
import { Client } from '../../types';
import { requestGeminiKonsultasi } from '../../services/geminiService';

interface AIConsultModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeClient?: Client;
}

interface Message {
  role: 'user' | 'assistant';
  text: string;
  time: string;
}

export const AIConsultModal: React.FC<AIConsultModalProps> = ({
  isOpen,
  onClose,
  activeClient,
}) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      text: `Halo Rekan Pekerja Sosial! Saya asisten klinis berbasis Gemini AI. ${
        activeClient
          ? `Saya siap mendampingi Anda menganalisis kasus ${activeClient.nama} (${activeClient.id}), merancang strategi penanganan krisis, atau memverifikasi kesesuaian prosedur perlindungan anak.`
          : 'Silakan ajukan pertanyaan seputar asesmen pekerjaan sosial, teori perkembangan anak, atau penanganan kasus berisiko tinggi.'
      }`,
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  if (!isOpen) return null;

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || input;
    if (!textToSend.trim() || loading) return;

    const userMsg: Message = {
      role: 'user',
      text: textToSend.trim(),
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const reply = await requestGeminiKonsultasi(textToSend, activeClient);
      const aiMsg: Message = {
        role: 'assistant',
        text: reply,
        time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      const errMsg: Message = {
        role: 'assistant',
        text: `Maaf, terjadi kesalahan saat menghubungi asisten AI: ${err.message || 'Koneksi bermasalah'}`,
        time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = [
    'Bagaimana langkah de-eskalasi emosi untuk anak yang trauma perpisahan orang tua?',
    'Apa rujukan instansi yang tepat untuk anak tanpa identitas NIK di Jawa Barat?',
    'Berikan rekomendasi terapi psikososial berbasis kekuatan (strengths perspective).',
    'Bagaimana menyusun safety plan jika anak memiliki risiko kedaruratan tinggi?',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs no-print">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full h-[600px] max-h-[90vh] flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-linear-to-r from-purple-700 via-indigo-700 to-sky-700 px-6 py-4 flex items-center justify-between text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <Bot className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-bold text-base flex items-center gap-2">
                Asisten Konsultasi Klinis Peksos
                <span className="text-[10px] bg-purple-500/50 px-2 py-0.5 rounded-full border border-purple-300/30">
                  Gemini 3.8 Flash
                </span>
              </h3>
              <p className="text-xs text-purple-100">
                {activeClient ? `Kasus Terpilih: ${activeClient.nama} (${activeClient.id})` : 'Mode Konsultasi Umum'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-50/50">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed shadow-xs ${
                  msg.role === 'user'
                    ? 'bg-indigo-600 text-white rounded-br-xs'
                    : 'bg-white text-slate-800 border border-slate-200 rounded-bl-xs'
                }`}
              >
                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-1.5 font-bold text-[11px] text-purple-700 mb-1 border-b border-purple-100 pb-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>Arahan Supervisor AI</span>
                  </div>
                )}
                <div className="whitespace-pre-line">{msg.text}</div>
                <div
                  className={`text-[10px] mt-1 text-right ${
                    msg.role === 'user' ? 'text-indigo-200' : 'text-slate-400'
                  }`}
                >
                  {msg.time}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-purple-700 bg-purple-50 border border-purple-200 p-3 rounded-xl w-fit">
              <Loader2 className="w-4 h-4 animate-spin text-purple-600" />
              <span>Supervisor AI sedang menganalisis kasus & merumuskan rekomendasi...</span>
            </div>
          )}
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 bg-slate-100/70 border-t border-slate-200 flex gap-1.5 overflow-x-auto shrink-0">
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              disabled={loading}
              className="text-[11px] bg-white hover:bg-purple-50 hover:text-purple-700 text-slate-700 px-2.5 py-1 rounded-full border border-slate-300 whitespace-nowrap transition shrink-0"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200 shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={loading}
              placeholder="Tanyakan analisis klinis, rekomendasi metode konseling, atau panduan etik..."
              className="flex-1 rounded-xl border border-slate-300 py-2 px-3.5 text-sm focus:ring-2 focus:ring-purple-500 bg-slate-50 focus:bg-white"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Kirim</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
