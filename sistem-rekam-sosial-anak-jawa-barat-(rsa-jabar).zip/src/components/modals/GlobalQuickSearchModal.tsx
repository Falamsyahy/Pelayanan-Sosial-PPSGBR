import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Search, 
  X, 
  User, 
  MapPin, 
  Calendar, 
  AlertTriangle, 
  FileText, 
  Brain, 
  Handshake, 
  Printer, 
  ChevronRight, 
  Sparkles,
  Command,
  ArrowRight
} from 'lucide-react';
import { Client } from '../../types';

interface GlobalQuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  clients: Client[];
  onSelectClient: (clientId: string, targetTab?: string) => void;
}

export const GlobalQuickSearchModal: React.FC<GlobalQuickSearchModalProps> = ({
  isOpen,
  onClose,
  clients,
  onSelectClient,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 50);
    } else {
      setSearchQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  // Global search filtering
  const filteredClients = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return clients.slice(0, 8); // default to first 8 recent clients

    return clients.filter((c) => {
      const fd = c.formData || {};
      const matchNama = (c.nama || '').toLowerCase().includes(q);
      const matchId = (c.id || '').toLowerCase().includes(q);
      const matchNik = (fd.noIdentitas || '').toLowerCase().includes(q);
      const matchKota = (fd.kabupatenKota || '').toLowerCase().includes(q);
      const matchWali = (fd.namaWali || '').toLowerCase().includes(q);
      const matchJurusan = (fd.jurusan || '').toLowerCase().includes(q);
      const matchAngkatan = (fd.angkatan || '').toLowerCase().includes(q);
      const matchStatus = (c.status || '').toLowerCase().includes(q);
      const matchRisiko = (fd.tingkatRisiko || '').toLowerCase().includes(q);
      const matchDesa = (fd.desa || '').toLowerCase().includes(q);

      return (
        matchNama ||
        matchId ||
        matchNik ||
        matchKota ||
        matchWali ||
        matchJurusan ||
        matchAngkatan ||
        matchStatus ||
        matchRisiko ||
        matchDesa
      );
    });
  }, [clients, searchQuery]);

  // Reset selected index when query changes
  useEffect(() => {
    setSelectedIndex(0);
  }, [searchQuery]);

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < filteredClients.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredClients[selectedIndex]) {
        onSelectClient(filteredClients[selectedIndex].id, 'tab-profil');
        onClose();
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    }
  };

  const handleItemClick = (client: Client, tab?: string) => {
    onSelectClient(client.id, tab || 'tab-profil');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-start justify-center pt-12 sm:pt-20 p-3 sm:p-4 animate-in fade-in duration-100"
      onClick={onClose}
    >
      <div 
        className="bg-white border border-slate-200 rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Header Bar */}
        <div className="relative flex items-center px-4 sm:px-5 py-3.5 border-b border-slate-200 bg-slate-50/70">
          <Search className="w-5 h-5 text-sky-600 mr-3 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Cari nama anak, ID kasus, NIK, wali, kota, kejuruan, angkatan..."
            className="w-full bg-transparent text-sm sm:text-base text-slate-900 placeholder-slate-400 focus:outline-hidden font-medium"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="p-1 rounded-md text-slate-400 hover:text-slate-600 mr-2"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-flex items-center gap-0.5 px-2 py-0.5 text-[10px] font-mono text-slate-500 bg-white border border-slate-200 rounded shadow-2xs">
            ESC
          </kbd>
        </div>

        {/* Quick Hint & Stats */}
        <div className="px-5 py-2 bg-slate-100/60 border-b border-slate-200/60 flex items-center justify-between text-[11px] text-slate-500">
          <span>
            {searchQuery 
              ? `Ditemukan ${filteredClients.length} klien yang sesuai` 
              : `Menampilkan klien terbaru (${filteredClients.length} dari ${clients.length})`}
          </span>
          <div className="hidden sm:flex items-center gap-3">
            <span>Gunakan tombol <kbd className="px-1 py-0.2 bg-white rounded border border-slate-300 text-[10px]">↑</kbd> <kbd className="px-1 py-0.2 bg-white rounded border border-slate-300 text-[10px]">↓</kbd> navigasi</span>
            <span><kbd className="px-1 py-0.2 bg-white rounded border border-slate-300 text-[10px]">ENTER</kbd> pilih</span>
          </div>
        </div>

        {/* Search Results List */}
        <div 
          ref={listRef} 
          className="flex-1 overflow-y-auto p-2 divide-y divide-slate-100"
        >
          {filteredClients.length === 0 ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <User className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-sm font-semibold text-slate-700">Tidak ada data anak yang cocok</p>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Coba gunakan kata kunci lain seperti nama panggilan, NIK, nama wali, atau kabupaten/kota asal.
              </p>
            </div>
          ) : (
            filteredClients.map((client, idx) => {
              const fd = client.formData || {};
              const isSelected = idx === selectedIndex;
              const isHighRisk = fd.tingkatRisiko === 'Tinggi' || fd.tingkatRisiko === 'Kritis';

              return (
                <div
                  key={client.id}
                  onClick={() => handleItemClick(client, 'tab-profil')}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`group p-3 rounded-xl transition-colors cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 ${
                    isSelected ? 'bg-sky-50/80 border border-sky-200' : 'hover:bg-slate-50 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 shadow-2xs ${
                      isSelected 
                        ? 'bg-sky-700 text-white' 
                        : 'bg-slate-100 text-slate-700 group-hover:bg-sky-100 group-hover:text-sky-800'
                    }`}>
                      {client.nama ? client.nama.charAt(0).toUpperCase() : 'A'}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-bold text-sm text-slate-900 group-hover:text-sky-700 truncate">
                          {client.nama}
                        </h4>
                        <span className="font-mono text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-semibold">
                          {client.id}
                        </span>
                        {isHighRisk && (
                          <span className="inline-flex items-center gap-0.5 text-[10px] font-extrabold bg-rose-100 text-rose-800 px-1.5 py-0.2 rounded border border-rose-200">
                            <AlertTriangle className="w-2.5 h-2.5" />
                            {fd.tingkatRisiko}
                          </span>
                        )}
                        <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                          client.status?.includes('Aktif') 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : client.status?.includes('Terminasi')
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {client.status}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-slate-500 mt-1">
                        <span>{client.umur} th ({client.gender})</span>
                        <span className="flex items-center gap-1 text-slate-600">
                          <MapPin className="w-3 h-3 text-sky-600" />
                          {fd.kabupatenKota || 'Jawa Barat'}
                        </span>
                        <span>
                          Kejuruan: <strong className="text-slate-700 font-semibold">{fd.jurusan || '-'}</strong>
                        </span>
                        {fd.angkatan && (
                          <span className="text-slate-400">({fd.angkatan})</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Quick Action Shortcuts */}
                  <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleItemClick(client, 'tab-asesmen');
                      }}
                      className="px-2 py-1 text-[11px] font-medium text-slate-600 hover:text-sky-700 hover:bg-sky-100/60 rounded flex items-center gap-1 transition"
                      title="Buka Asesmen BPSS"
                    >
                      <Brain className="w-3 h-3" />
                      <span className="hidden sm:inline">Asesmen</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleItemClick(client, 'tab-intervensi');
                      }}
                      className="px-2 py-1 text-[11px] font-medium text-slate-600 hover:text-purple-700 hover:bg-purple-100/60 rounded flex items-center gap-1 transition"
                      title="Buka Log Intervensi SOAP"
                    >
                      <Handshake className="w-3 h-3" />
                      <span className="hidden sm:inline">Intervensi</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleItemClick(client, 'tab-cetak');
                      }}
                      className="px-2 py-1 text-[11px] font-medium text-slate-600 hover:text-emerald-700 hover:bg-emerald-100/60 rounded flex items-center gap-1 transition"
                      title="Buka Cetak Laporan"
                    >
                      <Printer className="w-3 h-3" />
                      <span className="hidden sm:inline">Cetak</span>
                    </button>

                    <div className="w-7 h-7 rounded-lg bg-sky-600 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity ml-1">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            Pencarian instan menyeluruh database Rekam Sosial Anak Jabar
          </span>
          <button
            onClick={onClose}
            className="px-3 py-1 font-medium border border-slate-300 rounded text-slate-700 hover:bg-slate-100 transition"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
