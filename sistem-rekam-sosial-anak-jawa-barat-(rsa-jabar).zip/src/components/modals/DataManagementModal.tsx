import React, { useRef, useState, useMemo, useEffect } from 'react';
import { 
  X, 
  FileSpreadsheet, 
  Download, 
  Upload, 
  Database, 
  Filter, 
  CheckCircle2, 
  CheckSquare, 
  Square,
  AlertCircle,
  FileText,
  Loader2,
  Users,
  Check,
  RefreshCw,
  Info
} from 'lucide-react';
import { Client } from '../../types';
import { exportClientsToExcel, isClientInAngkatanFilter } from '../../services/exportExcelService';
import { 
  parseExcelClientFile, 
  downloadExcelImportTemplate, 
  ExcelImportResult 
} from '../../services/importExcelService';

interface DataManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  clients: Client[];
  onImportClients: (imported: Record<string, Client>, mode?: 'merge' | 'replace') => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
  initialTab?: 'export' | 'import';
}

export const DataManagementModal: React.FC<DataManagementModalProps> = ({
  isOpen,
  onClose,
  clients,
  onImportClients,
  onShowToast,
  initialTab = 'export',
}) => {
  const [activeTab, setActiveTab] = useState<'export' | 'import'>(initialTab);
  const jsonFileInputRef = useRef<HTMLInputElement>(null);
  const excelFileInputRef = useRef<HTMLInputElement>(null);

  // Sync initial tab when modal opens
  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  /* ====================================================================
   * EKSPOR STATE & LOGIC
   * ==================================================================== */
  const availableAngkatanList = useMemo(() => {
    const set = new Set<string>();
    clients.forEach((c) => {
      const a = c.formData?.angkatan;
      if (a && a.trim()) {
        a.split(/,|\bdan\b|&|\/|;/i).forEach((sub) => {
          const clean = sub.trim();
          if (clean) set.add(clean);
        });
      }
    });
    const list = Array.from(set).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
    return list.length > 0 ? list : ['Angkatan I - 2026', 'Angkatan II - 2026', 'Angkatan III - 2026'];
  }, [clients]);

  const [selectedAngkatans, setSelectedAngkatans] = useState<string[]>(availableAngkatanList);

  useEffect(() => {
    if (availableAngkatanList.length > 0 && selectedAngkatans.length === 0) {
      setSelectedAngkatans(availableAngkatanList);
    }
  }, [availableAngkatanList]);

  const isAllSelected = selectedAngkatans.length === availableAngkatanList.length;

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedAngkatans([]);
    } else {
      setSelectedAngkatans([...availableAngkatanList]);
    }
  };

  const toggleAngkatan = (ang: string) => {
    setSelectedAngkatans((prev) =>
      prev.includes(ang) ? prev.filter((a) => a !== ang) : [...prev, ang]
    );
  };

  const targetClients = useMemo(() => {
    if (selectedAngkatans.length === 0) return [];
    return clients.filter((c) => isClientInAngkatanFilter(c, selectedAngkatans));
  }, [clients, selectedAngkatans]);

  const targetClientsCount = targetClients.length;

  const handleExportExcel = () => {
    if (clients.length === 0) {
      onShowToast('Tidak ada data anak untuk diekspor.', 'error');
      return;
    }

    if (selectedAngkatans.length === 0) {
      onShowToast('Silakan centang minimal satu angkatan untuk diekspor.', 'error');
      return;
    }

    if (targetClients.length === 0) {
      onShowToast('Tidak ditemukan anak yang terdaftar pada angkatan yang dipilih.', 'error');
      return;
    }

    try {
      exportClientsToExcel(clients, {
        angkatanFilter: selectedAngkatans
      });

      const angkatanNames = selectedAngkatans.map(a => a.split('-')[0].trim()).join(' & ');
      const angkatanLabel = isAllSelected 
        ? `Semua Angkatan (${targetClients.length} Anak)` 
        : `${targetClients.length} Anak (${angkatanNames})`;

      onShowToast(`File Excel Rekap Resmi untuk ${angkatanLabel} berhasil diunduh!`, 'success');
      onClose();
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Gagal mengekspor file Excel.', 'error');
    }
  };

  const handleExportJSON = () => {
    if (clients.length === 0) {
      onShowToast('Tidak ada data untuk dibackup.', 'error');
      return;
    }

    const dict: Record<string, Client> = {};
    clients.forEach((c) => {
      dict[c.id] = c;
    });

    const blob = new Blob([JSON.stringify(dict, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Backup_RSA_Jabar_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    onShowToast('File backup JSON berhasil diunduh!', 'success');
    onClose();
  };

  /* ====================================================================
   * IMPOR STATE & LOGIC (EXCEL & JSON)
   * ==================================================================== */
  const [isParsingExcel, setIsParsingExcel] = useState(false);
  const [excelResult, setExcelResult] = useState<ExcelImportResult | null>(null);
  const [selectedFileName, setSelectedFileName] = useState('');
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');

  const handleDownloadTemplate = () => {
    try {
      downloadExcelImportTemplate();
      onShowToast('Template Excel resmi berhasil diunduh. Silakan isi data dan unggah kembali.', 'success');
    } catch (err: any) {
      onShowToast('Gagal mengunduh template: ' + err.message, 'error');
    }
  };

  const handleSelectExcelFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.match(/\.(xlsx|xls)$/i)) {
      onShowToast('Format berkas harus berupa Excel (.xlsx atau .xls).', 'error');
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      onShowToast('Ukuran berkas Excel melebihi batas 15 MB.', 'error');
      return;
    }

    setSelectedFileName(file.name);
    setIsParsingExcel(true);
    try {
      const result = await parseExcelClientFile(file, clients);
      if (result.validCount === 0) {
        onShowToast('Tidak ditemukan baris data anak yang valid pada berkas Excel.', 'error');
        setExcelResult(null);
      } else {
        setExcelResult(result);
        onShowToast(`Berhasil membaca ${result.validCount} data anak dari berkas Excel! Silakan periksa pratinjau.`, 'success');
      }
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Gagal mengurai berkas Excel.', 'error');
      setExcelResult(null);
    } finally {
      setIsParsingExcel(false);
      // Reset input agar file yang sama bisa dipilih ulang jika diperlukan
      if (excelFileInputRef.current) {
        excelFileInputRef.current.value = '';
      }
    }
  };

  const handleCommitExcelImport = () => {
    if (!excelResult || excelResult.clients.length === 0) {
      onShowToast('Tidak ada data yang siap diimpor.', 'error');
      return;
    }

    const dict: Record<string, Client> = {};
    excelResult.clients.forEach((c) => {
      dict[c.id] = c;
    });

    onImportClients(dict, importMode);
    onShowToast(
      `Berhasil mengimpor ${excelResult.validCount} anak binaan dari Excel (${importMode === 'merge' ? 'digabungkan dengan data aktif' : 'mengganti basis data'})!`, 
      'success'
    );
    setExcelResult(null);
    setSelectedFileName('');
    onClose();
  };

  const handleResetExcelImport = () => {
    setExcelResult(null);
    setSelectedFileName('');
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      onShowToast('Ukuran file backup melebihi batas maksimal (10 MB).', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const raw = event.target?.result as string;
        const parsed = JSON.parse(raw);
        if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
          throw new Error('Format file backup harus berupa kamus objek data anak.');
        }

        const sanitizedDict: Record<string, Client> = {};
        const DANGEROUS_KEYS = ['__proto__', 'constructor', 'prototype'];

        for (const [key, val] of Object.entries(parsed)) {
          if (DANGEROUS_KEYS.includes(key)) continue;
          if (!val || typeof val !== 'object' || Array.isArray(val)) continue;

          const record = val as any;
          if (typeof record.id !== 'string' || typeof record.nama !== 'string') continue;

          sanitizedDict[record.id] = {
            id: String(record.id).slice(0, 64),
            nama: String(record.nama).slice(0, 150),
            umur: typeof record.umur === 'number' ? record.umur : Number(record.umur) || 0,
            gender: record.gender === 'Perempuan' ? 'Perempuan' : 'Laki-laki',
            status: record.status || 'Kasus Aktif',
            peksosEmail: typeof record.peksosEmail === 'string' ? record.peksosEmail : 'peksos@jabarprov.go.id',
            riwayatPenyakit: Array.isArray(record.riwayatPenyakit) ? record.riwayatPenyakit.slice(0, 50) : [],
            pelaksanaanIntervensi: Array.isArray(record.pelaksanaanIntervensi) ? record.pelaksanaanIntervensi.slice(0, 100) : [],
            formData: typeof record.formData === 'object' && record.formData !== null ? record.formData : {}
          };
        }

        const validCount = Object.keys(sanitizedDict).length;
        if (validCount === 0) {
          throw new Error('Tidak ditemukan data rekam anak yang valid pada berkas.');
        }

        onImportClients(sanitizedDict, 'merge');
        onShowToast(`Berhasil memulihkan ${validCount} data anak dari backup!`, 'success');
        onClose();
      } catch (err: any) {
        onShowToast(`Gagal mengimpor file backup: ${err.message || 'format rusak.'}`, 'error');
      }
    };
    reader.readAsText(file);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs no-print">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Modal */}
        <div className="bg-linear-to-r from-indigo-700 via-indigo-600 to-sky-700 px-6 py-4 flex items-center justify-between text-white shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center">
              <Database className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">Manajemen Data: Ekspor & Impor Rekam Anak</h3>
              <p className="text-xs text-indigo-100">UPTD PPS Griya Bina Remaja Dinas Sosial Jawa Barat</p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 pt-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('export')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition -mb-px ${
              activeTab === 'export'
                ? 'border-indigo-600 text-indigo-700 bg-white rounded-t-lg shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Download className="w-4 h-4 text-indigo-600" />
            <span>Ekspor Data (Excel & JSON)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('import')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition -mb-px ${
              activeTab === 'import'
                ? 'border-emerald-600 text-emerald-800 bg-white rounded-t-lg shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Upload className="w-4 h-4 text-emerald-600" />
            <span>Impor Data Anak dari Excel</span>
            <span className="bg-emerald-100 text-emerald-800 text-[10px] px-1.5 py-0.2 rounded font-extrabold">
              Baru
            </span>
          </button>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">

          {/* =========================================================
           * TAB 1: EKSPOR DATA EXCEL & JSON
           * ========================================================= */}
          {activeTab === 'export' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                Ekspor rekap data anak binaan ke format Excel resmi Dinas Sosial Jawa Barat. Kolom <strong>Angkatan Masuk</strong> dicantumkan di bagian depan spreadsheet (Kolom C) untuk mempermudah identifikasi gelombang masuk anak.
              </p>

              {/* Checklist Multi-Angkatan Sebelum Ekspor */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Filter className="w-3.5 h-3.5 text-indigo-600" />
                    Pilih Angkatan untuk Diekspor:
                  </span>
                  <button
                    type="button"
                    onClick={toggleSelectAll}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 transition"
                  >
                    {isAllSelected ? (
                      <>
                        <CheckSquare className="w-3.5 h-3.5" />
                        <span>Batal Pilih Semua</span>
                      </>
                    ) : (
                      <>
                        <Square className="w-3.5 h-3.5" />
                        <span>Pilih Semua Angkatan</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Daftar Checkbox Angkatan */}
                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {availableAngkatanList.map((ang) => {
                    const isChecked = selectedAngkatans.includes(ang);
                    const count = clients.filter((c) => isClientInAngkatanFilter(c, ang)).length;

                    return (
                      <button
                        key={ang}
                        type="button"
                        onClick={() => toggleAngkatan(ang)}
                        className={`w-full text-left px-3 py-2 rounded-lg text-xs flex items-center justify-between border transition ${
                          isChecked
                            ? 'bg-indigo-50/90 border-indigo-300 text-indigo-950 font-bold shadow-2xs'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100/70'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          {isChecked ? (
                            <CheckSquare className="w-4 h-4 text-indigo-600 shrink-0" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-400 shrink-0" />
                          )}
                          <span>{ang}</span>
                        </div>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            isChecked
                              ? 'bg-indigo-200/80 text-indigo-900'
                              : 'bg-slate-100 text-slate-500'
                          }`}
                        >
                          {count} Anak Masuk
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Indikator Pilihan & Preview Anak Terpilih */}
                {selectedAngkatans.length === 0 ? (
                  <div className="flex items-center gap-1.5 text-[11px] text-rose-700 bg-rose-50 p-2.5 rounded-lg border border-rose-200">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>Pilih minimal 1 angkatan untuk mengekspor data anak.</span>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5 text-[11px] text-emerald-800 bg-emerald-50/90 p-2.5 rounded-lg border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>
                        <strong>{targetClientsCount} anak binaan</strong> terdaftar pada <strong>{selectedAngkatans.length} angkatan</strong> yang Anda centang.
                      </span>
                    </div>

                    {/* Preview Daftar Nama */}
                    {targetClients.length > 0 && (
                      <div className="bg-white p-2.5 rounded-lg border border-slate-200 space-y-1">
                        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-1">
                          Pratinjau Anak yang Akan Diekspor:
                        </div>
                        <div className="max-h-24 overflow-y-auto space-y-1 pr-1 divide-y divide-slate-100">
                          {targetClients.slice(0, 15).map((c, i) => (
                            <div key={c.id} className="pt-1 flex items-center justify-between text-xs">
                              <span className="font-semibold text-slate-800 truncate mr-2">
                                {i + 1}. {c.nama}
                              </span>
                              <div className="flex items-center gap-1.5 shrink-0">
                                <span className="text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 px-1.5 py-0.2 rounded">
                                  {c.formData?.angkatan || 'Angkatan I - 2026'}
                                </span>
                                <span className="text-[10px] text-slate-500">
                                  {c.formData?.jurusan || '-'}
                                </span>
                              </div>
                            </div>
                          ))}
                          {targetClients.length > 15 && (
                            <div className="pt-1 text-center text-[10px] text-slate-400 italic">
                              ...dan {targetClients.length - 15} anak lainnya
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Tombol Ekspor Excel */}
              <button
                type="button"
                onClick={handleExportExcel}
                disabled={selectedAngkatans.length === 0 || targetClientsCount === 0}
                className="w-full bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold py-3 px-4 rounded-xl shadow-xs transition flex items-center justify-center gap-2.5 text-xs sm:text-sm disabled:opacity-50"
              >
                <FileSpreadsheet className="w-5 h-5 shrink-0" />
                <span>Unduh Rekap Excel ({targetClientsCount} Anak dari {selectedAngkatans.length} Angkatan)</span>
              </button>

              {/* Tombol Backup JSON */}
              <button
                type="button"
                onClick={handleExportJSON}
                className="w-full bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 font-bold py-2.5 px-4 rounded-xl shadow-xs transition flex items-center justify-center gap-2 text-xs"
              >
                <Download className="w-4 h-4" />
                <span>Unduh Cadangan Lengkap Database (JSON)</span>
              </button>
            </div>
          )}

          {/* =========================================================
           * TAB 2: IMPOR DATA DARI EXCEL
           * ========================================================= */}
          {activeTab === 'import' && (
            <div className="space-y-4">
              
              {/* Card 1: Impor Berkas Excel */}
              <div className="bg-linear-to-br from-emerald-50/60 to-teal-50/40 rounded-xl border-2 border-emerald-300 p-5 space-y-4 shadow-xs">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-emerald-200 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shadow-2xs shrink-0">
                      <FileSpreadsheet className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-extrabold text-emerald-950">
                        Impor Data Anak dari Berkas Excel (.xlsx / .xls)
                      </h4>
                      <p className="text-[11px] text-slate-600">
                        Tambahkan daftar anak binaan secara massal langsung dari spreadsheet.
                      </p>
                    </div>
                  </div>

                  {/* Tombol Unduh Template */}
                  <button
                    type="button"
                    onClick={handleDownloadTemplate}
                    className="w-full sm:w-auto bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-300 font-bold px-3 py-1.5 rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-2xs transition"
                    title="Unduh format spreadsheet contoh pengisian data anak binaan"
                  >
                    <Download className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Unduh Template Excel</span>
                  </button>
                </div>

                {/* State Belum Pilih File atau Sedang Mengurai */}
                {!excelResult ? (
                  <div className="space-y-3">
                    <div className="bg-white/90 p-4 rounded-xl border border-dashed border-emerald-300 text-center space-y-3">
                      <div className="w-12 h-12 mx-auto rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                        <Upload className="w-6 h-6" />
                      </div>
                      
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-slate-800">
                          Pilih berkas Excel (.xlsx / .xls) yang berisi daftar anak binaan
                        </p>
                        <p className="text-[11px] text-slate-500 max-w-md mx-auto leading-relaxed">
                          Sistem otomatis mengenali kolom Nama, Angkatan, NIK, Usia, Jurusan, Status, Kab/Kota Asal, dan Orang Tua/Wali.
                        </p>
                      </div>

                      <input
                        type="file"
                        ref={excelFileInputRef}
                        accept=".xlsx, .xls"
                        onChange={handleSelectExcelFile}
                        className="hidden"
                      />

                      <div className="pt-1 flex flex-col sm:flex-row items-center justify-center gap-2">
                        <button
                          type="button"
                          onClick={() => excelFileInputRef.current?.click()}
                          disabled={isParsingExcel}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-6 rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition disabled:opacity-50"
                        >
                          {isParsingExcel ? (
                            <>
                              <Loader2 className="w-4 h-4 animate-spin" />
                              <span>Membaca Berkas Excel...</span>
                            </>
                          ) : (
                            <>
                              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
                              <span>Pilih Berkas Excel</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 bg-emerald-100/60 p-3 rounded-lg border border-emerald-200 text-[11px] text-emerald-900 leading-relaxed">
                      <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                      <div>
                        <strong>Petunjuk Pengisian Excel:</strong> Anda dapat menggunakan berkas Excel hasil ekspor sebelumnya atau template standar di atas. Kolom ID dapat dikosongkan jika ingin ID registrasi (misal: <code>1-26-III-2026</code>) dibuat otomatis.
                      </div>
                    </div>
                  </div>
                ) : (
                  /* State Pratinjau Setelah File Dipilih & Berhasil Diparsing */
                  <div className="space-y-4">
                    {/* Ringkasan Parsing */}
                    <div className="bg-white p-3.5 rounded-xl border border-emerald-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span className="text-xs font-extrabold text-slate-900">
                            Berkas: <span className="text-emerald-700 font-mono">{selectedFileName}</span>
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Terdeteksi <strong>{excelResult.validCount} data anak</strong> valid siap diimpor ke rekam medis sosial.
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={handleResetExcelImport}
                        className="text-[11px] font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition shrink-0"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Pilih Berkas Lain</span>
                      </button>
                    </div>

                    {/* Mode Impor: Gabungkan vs Ganti */}
                    <div className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-2">
                      <label className="block text-xs font-bold text-slate-800">
                        Opsi Penggabungan Data:
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <label className={`p-2.5 rounded-lg border flex items-start gap-2 cursor-pointer transition ${
                          importMode === 'merge' 
                            ? 'bg-emerald-50 border-emerald-300 font-bold text-emerald-950' 
                            : 'bg-white border-slate-200 text-slate-600'
                        }`}>
                          <input
                            type="radio"
                            name="importMode"
                            checked={importMode === 'merge'}
                            onChange={() => setImportMode('merge')}
                            className="mt-0.5 text-emerald-600 focus:ring-emerald-500"
                          />
                          <div>
                            <div>Gabungkan (Rekomendasi)</div>
                            <span className="text-[10px] font-normal text-slate-500 block">
                              Tambahkan anak baru ke basis data saat ini tanpa menghapus yang sudah ada.
                            </span>
                          </div>
                        </label>

                        <label className={`p-2.5 rounded-lg border flex items-start gap-2 cursor-pointer transition ${
                          importMode === 'replace' 
                            ? 'bg-amber-50 border-amber-300 font-bold text-amber-950' 
                            : 'bg-white border-slate-200 text-slate-600'
                        }`}>
                          <input
                            type="radio"
                            name="importMode"
                            checked={importMode === 'replace'}
                            onChange={() => setImportMode('replace')}
                            className="mt-0.5 text-amber-600 focus:ring-amber-500"
                          />
                          <div>
                            <div>Ganti Seluruh Data</div>
                            <span className="text-[10px] font-normal text-slate-500 block">
                              Hapus data yang ada dan gantikan seluruhnya dengan isi berkas Excel ini.
                            </span>
                          </div>
                        </label>
                      </div>
                    </div>

                    {/* Tabel Pratinjau Baris Excel */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 px-1">
                        <span>Pratinjau Data Anak ({excelResult.previews.length} baris):</span>
                        <span className="text-emerald-700 font-mono text-[10px]">
                          100% Valid
                        </span>
                      </div>

                      <div className="border border-slate-200 rounded-xl overflow-hidden bg-white max-h-52 overflow-y-auto shadow-2xs">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-50 border-b border-slate-200 text-[10px] text-slate-600 uppercase font-bold sticky top-0">
                            <tr>
                              <th className="py-2 px-2.5 w-8">No</th>
                              <th className="py-2 px-2.5">Nama Anak</th>
                              <th className="py-2 px-2.5 w-20">Gender/Usia</th>
                              <th className="py-2 px-2.5">Angkatan</th>
                              <th className="py-2 px-2.5">Jurusan</th>
                              <th className="py-2 px-2.5">Kab/Kota Asal</th>
                              <th className="py-2 px-2.5 w-24">Status</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 text-[11px]">
                            {excelResult.previews.map((item, idx) => (
                              <tr key={item.id} className="hover:bg-slate-50/80 transition">
                                <td className="py-2 px-2.5 font-bold text-slate-500">{idx + 1}</td>
                                <td className="py-2 px-2.5 font-bold text-slate-900">
                                  <div>{item.nama}</div>
                                  <div className="text-[10px] text-slate-400 font-mono font-normal">ID: {item.id}</div>
                                </td>
                                <td className="py-2 px-2.5 text-slate-700 whitespace-nowrap">
                                  {item.gender === 'Laki-laki' ? 'L' : 'P'}, {item.umur} thn
                                </td>
                                <td className="py-2 px-2.5">
                                  <span className="bg-indigo-50 text-indigo-700 font-semibold px-1.5 py-0.5 rounded text-[10px] border border-indigo-200 whitespace-nowrap">
                                    {item.angkatan}
                                  </span>
                                </td>
                                <td className="py-2 px-2.5 text-slate-600">{item.jurusan}</td>
                                <td className="py-2 px-2.5 text-slate-600">{item.kabupatenKota}</td>
                                <td className="py-2 px-2.5 whitespace-nowrap">
                                  <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                                    {item.status.split(' ')[0]}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Tombol Eksekusi Impor */}
                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={handleCommitExcelImport}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold py-3 px-4 rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition"
                      >
                        <Check className="w-4 h-4 text-white" />
                        <span>Konfirmasi & Simpan {excelResult.validCount} Data Anak ke Aplikasi</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Card 2: Pulihkan Cadangan JSON */}
              <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h5 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-slate-600" />
                      <span>Atau Pulihkan Cadangan Basis Data (JSON)</span>
                    </h5>
                    <p className="text-[11px] text-slate-500">
                      Gunakan berkas backup JSON yang diunduh dari menu ekspor sebelumnya.
                    </p>
                  </div>

                  <input
                    type="file"
                    ref={jsonFileInputRef}
                    accept=".json"
                    onChange={handleImportJSON}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => jsonFileInputRef.current?.click()}
                    className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-semibold py-1.5 px-3 rounded-lg transition flex items-center gap-1.5 text-xs shrink-0"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Pilih Berkas JSON</span>
                  </button>
                </div>
              </div>

            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-slate-400" />
            <span>Total Klien Tersimpan Saat Ini: <strong>{clients.length} Anak</strong></span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition shadow-2xs"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
