import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Mail,
  User,
  LogIn,
  UserPlus,
  AlertCircle,
  Copy,
  Check,
  Loader2,
  Eye,
  EyeOff,
  CheckCircle2,
  FileLock2,
} from 'lucide-react';
import {
  loginWithEmail,
  registerWithEmail,
  signInWithGoogle,
} from '../firebase';

interface AuthLandingPageProps {
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
  onSuccess: (name: string) => void;
  sessionNotice?: { type: 'info' | 'error'; text: string } | null;
  onClearNotice?: () => void;
}

export const AuthLandingPage: React.FC<AuthLandingPageProps> = ({
  onShowToast,
  onSuccess,
  sessionNotice,
  onClearNotice,
}) => {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [domainError, setDomainError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const currentHost = typeof window !== 'undefined' ? window.location.hostname : '';

  const handleCopyHost = () => {
    if (!currentHost) return;
    navigator.clipboard.writeText(currentHost);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    onShowToast('Domain berhasil disalin.', 'success');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setErrorMsg('Alamat email dan kata sandi wajib diisi.');
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    setDomainError(null);
    onClearNotice?.();

    try {
      if (isRegister) {
        const user = await registerWithEmail(email.trim(), password, displayName.trim());
        const finalName = displayName.trim() || user.email || 'Pekerja Sosial';
        onSuccess(finalName);
        onShowToast(`Pendaftaran berhasil. Selamat datang, ${finalName}.`, 'success');
      } else {
        const user = await loginWithEmail(email.trim(), password);
        const finalName = user.displayName || user.email || 'Pekerja Sosial';
        onSuccess(finalName);
        onShowToast(`Berhasil masuk sebagai ${finalName}.`, 'success');
      }
    } catch (err: any) {
      let msg = err?.message || 'Gagal melakukan autentikasi.';
      if (
        err?.code === 'auth/wrong-password' ||
        err?.code === 'auth/user-not-found' ||
        err?.code === 'auth/invalid-credential'
      ) {
        msg = 'Email atau kata sandi tidak sesuai.';
      } else if (err?.code === 'auth/email-already-in-use') {
        msg = 'Email ini sudah terdaftar. Silakan masuk menggunakan akun tersebut.';
      } else if (err?.code === 'auth/weak-password') {
        msg = 'Kata sandi minimal 6 karakter.';
      } else if (err?.code === 'auth/too-many-requests') {
        msg = 'Terlalu banyak percobaan masuk. Silakan tunggu beberapa saat.';
      }
      setErrorMsg(msg);
      onShowToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    setLoading(true);
    setErrorMsg(null);
    setDomainError(null);
    onClearNotice?.();

    try {
      const user = await signInWithGoogle();
      const finalName = user.displayName || user.email || 'Pekerja Sosial';
      onSuccess(finalName);
      onShowToast(`Berhasil masuk dengan Google: ${finalName}.`, 'success');
    } catch (err: any) {
      if (err?.message && err.message.includes('belum diizinkan')) {
        setDomainError(currentHost);
      } else {
        const msg = err?.message || 'Gagal masuk menggunakan akun Google.';
        setErrorMsg(msg);
        onShowToast(msg, 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col justify-between">
      {/* Minimal Institutional Top Bar */}
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-sky-700 text-white flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <span className="font-bold text-base tracking-tight text-slate-900 whitespace-nowrap">
              Rekam Sosial Anak Jawa Barat
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500">
            <span>UPTD PPS Griya Bina Remaja</span>
            <span aria-hidden="true">·</span>
            <span>Dinas Sosial Provinsi Jawa Barat</span>
          </div>
        </div>
      </header>

      {/* Main Split Auth Workspace */}
      <main className="flex-1 flex items-center justify-center px-4 sm:px-6 py-10">
        <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Security & System Summary */}
          <div className="lg:col-span-6 space-y-6">
            <div className="space-y-3">
              <p className="text-xs font-semibold text-sky-700 tracking-wide">
                Akses Terbatas Petugas & Administrator
              </p>
              <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight leading-tight text-balance">
                Portal Manajemen Kasus & Rekam Sosial Anak Terpadu
              </h1>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-xl">
                Seluruh biodata anak binaan, asesmen biopsikososial-spiritual, berkas kependudukan (KK/KIA), dan kontrak pelayanan sosial dikunci di balik autentikasi akun resmi.
              </p>
            </div>

            <div className="border-t border-slate-200 pt-5 space-y-3 text-sm text-slate-700">
              <div className="flex items-start gap-3">
                <FileLock2 className="w-4 h-4 text-sky-700 shrink-0 mt-1" />
                <div>
                  <span className="font-semibold text-slate-900">Isolasi Sesi & Perlindungan Data Anak</span>
                  <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                    Saat Anda keluar dari akun, seluruh data anak di memori aplikasi dan cache peramban dibersihkan otomatis sehingga tidak terbaca pengguna berikutnya.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <ShieldCheck className="w-4 h-4 text-sky-700 shrink-0 mt-1" />
                <div>
                  <span className="font-semibold text-slate-900">Kontrol Akses Berbasis Peran (Admin & Peksos)</span>
                  <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                    Akun Administrator memiliki akses penuh ke Panel Admin untuk audit kelengkapan berkas, manajemen akun pekerja sosial, dan kontrol penghapusan data.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Auth Card */}
          <div className="lg:col-span-6">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-5 max-w-md mx-auto w-full">
              <div className="space-y-1">
                <h2 className="text-xl font-bold text-slate-900">
                  {isRegister ? 'Pendaftaran Akun Pekerja Sosial' : 'Masuk ke Sistem RSA Jabar'}
                </h2>
                <p className="text-xs text-slate-500">
                  {isRegister
                    ? 'Daftarkan email instansi untuk mulai mengelola rekam binaan.'
                    : 'Gunakan akun Admin atau Pekerja Sosial yang terdaftar di semarakppsgbr.'}
                </p>
              </div>

              {sessionNotice && (
                <div
                  className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                    sessionNotice.type === 'error'
                      ? 'bg-rose-50 border-rose-200 text-rose-900'
                      : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  }`}
                >
                  {sessionNotice.type === 'error' ? (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  )}
                  <span className="font-medium leading-relaxed">{sessionNotice.text}</span>
                </div>
              )}

              {errorMsg && (
                <div className="p-3 rounded-xl border bg-rose-50 border-rose-200 text-rose-900 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span className="font-medium leading-relaxed">{errorMsg}</span>
                </div>
              )}

              {domainError && (
                <div className="bg-amber-50 border border-amber-200 p-3.5 rounded-xl text-xs text-amber-900 space-y-2">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                    <div className="leading-relaxed">
                      <strong>Domain belum ada di Authorized Domains Firebase:</strong> Tambahkan domain berikut di Firebase Console atau gunakan login Email & Kata Sandi di bawah.
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 bg-white p-2 rounded-lg border border-amber-200 font-mono text-[11px] text-slate-800">
                    <span className="flex-1 truncate select-all">{domainError}</span>
                    <button
                      type="button"
                      onClick={handleCopyHost}
                      className="bg-amber-100 hover:bg-amber-200 text-amber-900 px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 shrink-0"
                    >
                      {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      {copied ? 'Tersalin' : 'Salin'}
                    </button>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                {isRegister && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Nama Lengkap & Gelar
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        required
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        placeholder="Contoh: Budi Santoso, S.Tr.Sos"
                        className="w-full rounded-xl border border-slate-300 py-2 pl-9 pr-3 text-sm focus:outline-none focus:ring-2 focus:ring-sky-600 focus:border-sky-600"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Alamat Email
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="nama@jabarprov.go.id"
                      className="w-full rounded-xl border border-slate-300 py-2 pl-9 pr-3 text-sm focus:outline-none focus:ring-2 focus:ring-sky-600 focus:border-sky-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Kata Sandi
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Minimal 6 karakter"
                      className="w-full rounded-xl border border-slate-300 py-2 pl-9 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-sky-600 focus:border-sky-600"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 p-0.5"
                      title={showPassword ? 'Sembunyikan sandi' : 'Lihat sandi'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-sky-700 hover:bg-sky-800 text-white font-semibold py-2.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 transition disabled:opacity-50"
                >
                  {loading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : isRegister ? (
                    <>
                      <UserPlus className="w-4 h-4" />
                      <span>Daftar Akun</span>
                    </>
                  ) : (
                    <>
                      <LogIn className="w-4 h-4" />
                      <span>Masuk</span>
                    </>
                  )}
                </button>
              </form>

              <div className="relative flex py-1 items-center">
                <div className="grow border-t border-slate-200"></div>
                <span className="shrink mx-3 text-slate-400 text-xs">atau</span>
                <div className="grow border-t border-slate-200"></div>
              </div>

              <button
                type="button"
                onClick={handleGoogleAuth}
                disabled={loading}
                className="w-full bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-semibold py-2.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 transition disabled:opacity-50"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Masuk dengan Akun Google</span>
              </button>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setIsRegister(!isRegister);
                    setErrorMsg(null);
                    setDomainError(null);
                  }}
                  className="text-xs text-sky-700 hover:text-sky-900 font-semibold hover:underline"
                >
                  {isRegister
                    ? 'Sudah punya akun? Masuk di sini'
                    : 'Belum punya akun petugas? Daftar di sini'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Clean Institutional Footer */}
      <footer className="border-t border-slate-200 bg-white px-6 py-4 text-xs text-slate-500">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>UPTD Pusat Pelayanan Sosial Griya Bina Remaja · Provinsi Jawa Barat</span>
          <span>Akses Data Terenkripsi · UU No. 35 Tahun 2014 tentang Perlindungan Anak</span>
        </div>
      </footer>
    </div>
  );
};
