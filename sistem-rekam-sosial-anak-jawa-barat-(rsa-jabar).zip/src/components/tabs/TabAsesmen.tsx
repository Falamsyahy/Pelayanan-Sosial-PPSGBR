import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Brain, 
  Dna, 
  Users2, 
  HeartHandshake, 
  Lightbulb, 
  Sparkles, 
  Loader2, 
  Printer,
  ClipboardCheck,
  Network,
  Users,
  FileSearch,
  CheckCircle2,
  FolderCheck,
  CheckSquare,
  Square,
  Info,
  BookOpen,
  HelpCircle,
  X,
  TrendingUp,
  Image as ImageIcon,
  Layers,
  Compass,
  FileText,
  Activity,
  Stethoscope,
  Scale,
  Pill
} from 'lucide-react';
import { Client, RiskLevel } from '../../types';
import { requestGeminiPemaknaan } from '../../services/geminiService';
import { ExportToolbar } from '../ExportToolbar';
import { GenogramBuilder } from '../tools/GenogramBuilder';
import { EcomapBuilder } from '../tools/EcomapBuilder';

interface TabAsesmenProps {
  client: Client;
  onChangeField: (key: string, value: any) => void;
  onGoToPrint: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
  peksosName?: string;
}

export interface KnowledgeItem {
  id: string;
  category: 'Metode Penggalian' | 'Sumber Informan' | 'Instrumen Diagnostik';
  badgeColor: string;
  title: string;
  definisi: string;
  tujuan: string;
  tips: string;
}

const KNOWLEDGE_DICTIONARY: Record<string, KnowledgeItem> = {
  // METODE PENGGALIAN
  'Wawancara Mendalam Anak (Child-Friendly)': {
    id: 'Wawancara Mendalam Anak (Child-Friendly)',
    category: 'Metode Penggalian',
    badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-400/40',
    title: 'Wawancara Ramah Anak (Child-Friendly In-Depth Interview)',
    definisi: 'Teknik wawancara dialogis tatap muka dengan pendekatan empatik, bebas intimidasi, dan menggunakan bahasa sederhana yang sesuai dengan tingkat usia serta kognisi anak.',
    tujuan: 'Menggali persepsi langsung, riwayat pengalaman hidup, perasaan, dan kehendak anak dari perspektif anak itu sendiri (child voice) tanpa intervensi pihak lain.',
    tips: 'Gunakan pertanyaan terbuka (open-ended), sediakan media gambar/spidol jika anak pemalu, hindari pertanyaan menghakimi, dan segera istirahat jika anak menunjukkan tanda kelelahan emosional.'
  },
  'Wawancara Orang Tua / Wali / Pengasuh': {
    id: 'Wawancara Orang Tua / Wali / Pengasuh',
    category: 'Metode Penggalian',
    badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-400/40',
    title: 'Wawancara Orang Tua / Wali / Pengasuh Utama',
    definisi: 'Penggalian informasi mendalam terhadap figur pengasuh primer terkait riwayat kelahiran, kesehatan balita, pola asuh, kondisi ekonomi keluarga, dan dinamika rumah tangga.',
    tujuan: 'Mengidentifikasi akar penyebab kerentanan pengasuhan (stressor keluarga), kesiapan orang tua mendampingi, dan komitmen reintegrasi anak kembali ke rumah.',
    tips: 'Terapkan sikap non-judgmental (tidak menghakimi kemiskinan atau kekhilafan orang tua), dengarkan keluh kesah mereka, dan jangan membuat janji bantuan di luar kewenangan dinas.'
  },
  'Kunjungan Rumah & Lingkungan (Home Visit)': {
    id: 'Kunjungan Rumah & Lingkungan (Home Visit)',
    category: 'Metode Penggalian',
    badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-400/40',
    title: 'Kunjungan Rumah & Pemindaian Lingkungan (Home Visit)',
    definisi: 'Kunjungan langsung pekerja sosial ke kediaman tempat tinggal keluarga dan lingkungan fisik-sosial tempat anak dibesarkan.',
    tujuan: 'Memvalidasi kelayakan hunian, keamanan lingkungan sekitar, interaksi alamiah antarsesama anggota keluarga, serta memverifikasi data administrasi kependudukan di lapangan.',
    tips: 'Amati kebersihan sanitasi, ketersediaan ruang tidur layak bagi anak, interaksi anak dengan tetangga, serta hubungan sosial keluarga dengan pengurus RT/RW setempat.'
  },
  'Observasi Partisipatif (Asrama & Pelatihan)': {
    id: 'Observasi Partisipatif (Asrama & Pelatihan)',
    category: 'Metode Penggalian',
    badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-400/40',
    title: 'Observasi Partisipatif Rutinitas Binaan',
    definisi: 'Pengamatan sistematis yang dilakukan oleh pekerja sosial dan pengasuh terhadap rutinitas harian anak di asrama dan saat praktik di bengkel/kelas vokasional.',
    tujuan: 'Menangkap perilaku autentik anak dalam situasi sosial nyata: kedisiplinan bangun pagi, toleransi konflik dengan teman sekamar, etos belajar, dan respon terhadap aturan.',
    tips: 'Catat pemicu stres (stress triggers), siapa teman sebaya yang sering didekati, bagaimana reaksi anak saat menerima teguran instruktur, dan adaptasi di 2 pekan awal.'
  },
  'Studi Dokumen & Berkas Rujukan Dinsos': {
    id: 'Studi Dokumen & Berkas Rujukan Dinsos',
    category: 'Metode Penggalian',
    badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-400/40',
    title: 'Studi Dokumen Legal & Berkas Rujukan',
    definisi: 'Penelaahan dokumen kependudukan resmi (KK, Akta Kelahiran, KIA, Rapor sekolah, Surat Keterangan DTKS) dan lembar rujukan penjangkauan dari Dinas Sosial pengirim.',
    tujuan: 'Memastikan legalitas identitas hukum anak (keaktifan NIK) dan memverifikasi riwayat bantuan sosial atau intervensi penanganan yang pernah diterima sebelumnya.',
    tips: 'Pastikan NIK anak valid di Disdukcapil karena menjadi syarat mutlak dalam aktivasi jaminan BPJS PBI dan pendaftaran Kartu Indonesia Pintar (KIP) kejar paket PKBM.'
  },
  'Konferensi Kasus (Case Conference) Tim Sentra': {
    id: 'Konferensi Kasus (Case Conference) Tim Sentra',
    category: 'Metode Penggalian',
    badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-400/40',
    title: 'Konferensi Kasus Multidisiplin (Case Conference)',
    definisi: 'Pertemuan formal antar-profesi di lingkungan Sentra (Pekerja Sosial, Psikolog, Instruktur Vokasi, Perawat, dan Pengasuh Asrama) untuk membahas kasus spesifik anak.',
    tujuan: 'Melakukan triangulasi data dari berbagai sudut pandang keahlian, menyepakati diagnosis kebutuhan prioritas anak, dan menyusun intervensi berbasis kepentingan terbaik anak.',
    tips: 'Paparkan fakta terukur dan hindari interpretasi asumtif yang belum diverifikasi. Catat hasil kesepakatan secara tertulis dan tandatangani berita acara konferensi kasus.'
  },

  // SUMBER INFORMAN
  'Anak Binaan (Informan Primer)': {
    id: 'Anak Binaan (Informan Primer)',
    category: 'Sumber Informan',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-400/40',
    title: 'Anak Binaan sebagai Informan Utama (Primer)',
    definisi: 'Anak itu sendiri sebagai pemegang hak asasi dan subjek utama yang paling mengetahui apa yang dialami, dirasakan, dan dicita-citakannya.',
    tujuan: 'Menghormati prinsip Konvensi Hak Anak PBB Pasal 12 (Hak Anak untuk Didengar Pendapatnya) dan memastikan intervensi dirancang sesuai kebutuhan nyata anak.',
    tips: 'Jamin kerahasiaan identitas anak. Dapatkan persetujuan sukarela (informed assent) dan jangan memaksa anak mengungkit trauma yang belum siap diceritakan.'
  },
  'Orang Tua / Wali Utama': {
    id: 'Orang Tua / Wali Utama',
    category: 'Sumber Informan',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-400/40',
    title: 'Orang Tua Kandung / Wali Utama',
    definisi: 'Ayah, ibu, atau wali yang sah secara hukum dan bertanggung jawab langsung atas pemeliharaan dan pengasuhan anak.',
    tujuan: 'Memperoleh data riwayat prenatal, tumbuh kembang masa balita, alasan putus sekolah/turun ke jalan, serta komitmen penerimaan anak saat masa terminasi asrama.',
    tips: 'Kenali siapa figur pengambil keputusan utama di keluarga (ayah, ibu, atau kakek) untuk mempermudah advokasi rencana masa depan anak.'
  },
  'Kerabat / Keluarga Besar': {
    id: 'Kerabat / Keluarga Besar',
    category: 'Sumber Informan',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-400/40',
    title: 'Kerabat / Keluarga Besar (Kinship System)',
    definisi: 'Paman, bibi, kakek, nenek, atau kakak kandung dewasa yang memiliki kedekatan emosional dan mengenal dinamika keluarga anak.',
    tujuan: 'Mendapatkan sistem pengasuhan kerabat pengganti (kinship care) apabila kedua orang tua kandung tidak mampu lagi mengasuh anak secara layak.',
    tips: 'Telusuri figur kerabat yang paling dipercaya oleh anak dan sering menjadi tempat berlindung saat terjadi konflik di rumah orang tua.'
  },
  'Guru Sekolah Asal / Tutor PKBM': {
    id: 'Guru Sekolah Asal / Tutor PKBM',
    category: 'Sumber Informan',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-400/40',
    title: 'Pendidik Sekolah Asal / Tutor Belajar PKBM',
    definisi: 'Wali kelas, guru BK, atau tutor kesetaraan di PKBM yang pernah berinteraksi langsung dalam proses belajar mengajar anak.',
    tujuan: 'Mengetahui daya serap belajar anak, kebiasaan presensi absensi, alasan berhenti sekolah, potensi bakat, serta relasi pergaulan dengan rekan sebaya di sekolah.',
    tips: 'Tanyakan secara spesifik apakah ada tunggakan administrasi, riwayat perundungan (bullying), atau kesulitan belajar membaca/menghitung yang belum tertangani.'
  },
  'Tokoh Lingkungan / RT-RW / Tetangga': {
    id: 'Tokoh Lingkungan / RT-RW / Tetangga',
    category: 'Sumber Informan',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-400/40',
    title: 'Tokoh Lingkungan / Pengurus RT-RW / Tetangga',
    definisi: 'Ketua RT/RW, tokoh masyarakat, pemuka agama, atau tetangga di sekitar tempat tinggal anak.',
    tujuan: 'Melakukan triangulasi silang mengenai perilaku keluarga di mata masyarakat, situasi kerentanan ekonomi lingkungan, dan keamanan wilayah setempat.',
    tips: 'Jaga kerahasiaan kasus saat mewawancarai tetangga agar tidak menimbulkan stigma negatif atau gosip yang merugikan nama baik anak dan keluarganya.'
  },
  'Satgas Sosial / Pekerja Sosial Wilayah': {
    id: 'Satgas Sosial / Pekerja Sosial Wilayah',
    category: 'Sumber Informan',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-400/40',
    title: 'Satgas Sosial / Pekerja Sosial Dinsos Wilayah',
    definisi: 'Petugas lapangan Dinas Sosial Kabupaten/Kota, pendamping PKH, atau TKSK yang menjangkau anak pertama kali di jalanan/komunitas.',
    tujuan: 'Mengetahui kronologi penjangkauan lapangan awal, data kepesertaan DTKS, riwayat bantuan sosial, dan konteks kerentanan sosiologis di daerah asal.',
    tips: 'Bangun koordinasi erat dengan peksos wilayah karena mereka yang akan menjadi mitra pemantauan bimbingan lanjut (aftercare) saat anak dipulangkan.'
  },

  // INSTRUMEN ASESMEN
  'Genogram (Pohon Keluarga 3 Generasi & Pola Asuh)': {
    id: 'Genogram (Pohon Keluarga 3 Generasi & Pola Asuh)',
    category: 'Instrumen Diagnostik',
    badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40',
    title: 'Genogram Keluarga 3 Generasi',
    definisi: 'Diagram pohon silsilah visual minimal tiga generasi (kakek-nenek, orang tua, anak) yang memetakan hubungan biologis, penyakit turunan, perceraian, dan kualitas relasi emosional.',
    tujuan: 'Mengidentifikasi siklus masalah yang berulang antar-generasi (transgenerational patterns) seperti pola penelantaran berulang, putus sekolah turun-temurun, atau kekerasan pengasuhan.',
    tips: 'Gunakan simbol baku: Kotak (laki-laki), Lingkaran (perempuan), Garis zig-zag (konflik), Garis putus-putus (renggang), dan Garis ganda (sangat lekat/ko-dependen).'
  },
  'Ecomap (Peta Jejaring Sistem Sosial & Komunitas)': {
    id: 'Ecomap (Peta Jejaring Sistem Sosial & Komunitas)',
    category: 'Instrumen Diagnostik',
    badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40',
    title: 'Ecomap (Peta Ekologi Sosial Anak)',
    definisi: 'Diagram grafis yang menggambarkan hubungan timbal balik antara sistem keluarga anak dengan sistem-sistem sosial di lingkungannya (sekolah, teman sebaya, tempat kerja, poskesdes, dsb).',
    tujuan: 'Menganalisis keseimbangan energi ekologis anak: melihat sistem mana yang memberi dukungan positif (nourishing) dan sistem mana yang menyerap energi / menimbulkan stres (stressful).',
    tips: 'Ajak anak menggambar bersama. Beri tanda panah aliran energi dan ketebalan garis untuk menunjukkan seberapa kuat relasi anak dengan sistem luar tersebut.'
  },
  'Life History Grid (Garis Waktu Perjalanan Hidup)': {
    id: 'Life History Grid (Garis Waktu Perjalanan Hidup)',
    category: 'Instrumen Diagnostik',
    badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40',
    title: 'Life History Grid (Garis Riwayat Hidup Anak)',
    definisi: 'Matriks kronologis yang memadukan usia anak dari lahir hingga sekarang dengan peristiwa-peristiwa kritis keluarga (turning points) dan perubahan tempat tinggal.',
    tujuan: 'Melihat korelasi sebab-akibat antara krisis keluarga (misal: perceraian saat usia 9 thn) dengan perubahan perilaku anak (mulai putus sekolah dan mengamen di jalanan usia 10 thn).',
    tips: 'Membantu anak memahami bahwa respon perilakunya di masa lalu adalah mekanisme bertahan hidup (survival coping) dari situasi sulit yang tidak mampu ia kendalikan.'
  },
  'Matriks Kekuatan & Resiliensi (Strengths Matrix)': {
    id: 'Matriks Kekuatan & Resiliensi (Strengths Matrix)',
    category: 'Instrumen Diagnostik',
    badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40',
    title: 'Matriks Kekuatan & Resiliensi (Strengths Perspective)',
    definisi: 'Tabel inventarisasi aset internal anak (bakat, ketekunan, optimisme, empati, hobi) dan aset eksternal (teman suportif, mentor asrama, peluang magang vokasional).',
    tujuan: 'Mengubah paradigma pekerja sosial dari sekadar mencatat "daftar defisit/cacat anak" menjadi fokus memobilisasi potensi ketahanan hidup anak untuk mandiri.',
    tips: 'Tanyakan: "Apa hal tersulit yang pernah berhasil kamu lalui?", "Apa keahlian yang paling kamu senangi?", dan jadikan jawaban tersebut pondasi rencana intervensi.'
  },
  'Skala Minat & Bakat Pelatihan Vokasional': {
    id: 'Skala Minat & Bakat Pelatihan Vokasional',
    category: 'Instrumen Diagnostik',
    badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40',
    title: 'Skala Minat & Bakat Vokasional',
    definisi: 'Alat ukur preferensi kecenderungan kejuruan praktis (Otomotif Motor, Menjahit & Tata Busana, Tata Boga/Kuliner, Teknik Las, atau Desain Komputer).',
    tujuan: 'Memastikan penempatan jurusan pelatihan vokasi di asrama selaras dengan modalitas minat anak, sehingga motivasi belajarnya tinggi dan tidak rentan mogok/drop out.',
    tips: 'Lakukan uji coba praktis (workshop orientation) selama 3 hari pertama agar anak merasakan langsung pengalaman kerja sebelum menetapkan pilihan jurusan akhir.'
  },
  'Social Roadmap (Peta Perjalanan Sosial & Kemandirian)': {
    id: 'Social Roadmap (Peta Perjalanan Sosial & Kemandirian)',
    category: 'Instrumen Diagnostik',
    badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40',
    title: 'Social Roadmap (Peta Perjalanan Sosial & Kemandirian Anak)',
    definisi: 'Instrumen pemetaan navigasi 3 fase kehidupan anak: Fase 1 (Akar Kerentanan & Masa Lalu), Fase 2 (Pembinaan Terpadu di Balai/Sentra PPS Griya Bina Remaja), dan Fase 3 (Transisi Kemandirian, Keberlanjutan Sekolah & Aftercare).',
    tujuan: 'Menghubungkan hasil asesmen awal dengan peta jalan intervensi dan target evaluasi akhir, sehingga anak memiliki arah capaian hidup yang terukur dan bermakna.',
    tips: 'Ajak anak menyepakati target kecil (milestones) per bulan selama di asrama, dan cantumkan rencana kepulangan atau rujukan kerja yang realistis bersama keluarga.'
  }
};

const METODE_PENGGALIAN_OPTIONS = [
  'Wawancara Mendalam Anak (Child-Friendly)',
  'Wawancara Orang Tua / Wali / Pengasuh',
  'Kunjungan Rumah & Lingkungan (Home Visit)',
  'Observasi Partisipatif (Asrama & Pelatihan)',
  'Studi Dokumen & Berkas Rujukan Dinsos',
  'Konferensi Kasus (Case Conference) Tim Sentra'
];

const SUMBER_INFORMAN_OPTIONS = [
  'Anak Binaan (Informan Primer)',
  'Orang Tua / Wali Utama',
  'Kerabat / Keluarga Besar',
  'Guru Sekolah Asal / Tutor PKBM',
  'Tokoh Lingkungan / RT-RW / Tetangga',
  'Satgas Sosial / Pekerja Sosial Wilayah'
];

const INSTRUMEN_ASESMEN_OPTIONS = [
  'Genogram (Pohon Keluarga 3 Generasi & Pola Asuh)',
  'Ecomap (Peta Jejaring Sistem Sosial & Komunitas)',
  'Social Roadmap (Peta Perjalanan Sosial & Kemandirian)',
  'Life History Grid (Garis Waktu Perjalanan Hidup)',
  'Matriks Kekuatan & Resiliensi (Strengths Matrix)',
  'Skala Minat & Bakat Pelatihan Vokasional'
];

export const TabAsesmen: React.FC<TabAsesmenProps> = ({
  client,
  onChangeField,
  onGoToPrint,
  onShowToast,
  peksosName,
}) => {
  const fd = client.formData;
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedKnowledgeModal, setSelectedKnowledgeModal] = useState<KnowledgeItem | null>(null);
  const [activeInstrumentTab, setActiveInstrumentTab] = useState<'ringkasan' | 'genogram' | 'ecomap'>('ringkasan');

  const handleSaveGenogram = (data: any, imagePng?: string) => {
    onChangeField('genogramData', data);
    if (imagePng) {
      onChangeField('genogramImage', imagePng);
    }
  };

  const handleSaveEcomap = (data: any, imagePng?: string) => {
    onChangeField('ecomapData', data);
    if (imagePng) {
      onChangeField('ecomapImage', imagePng);
    }
  };

  const toggleArrayItem = (
    field: 'asesmenMetodePenggalian' | 'asesmenSumberInforman' | 'asesmenInstrumenDigunakan',
    item: string
  ) => {
    const currentList: string[] = fd[field] || [];
    const exists = currentList.includes(item);
    const updated = exists ? currentList.filter((x) => x !== item) : [...currentList, item];
    onChangeField(field, updated);
  };

  const tbNum = Number(fd.kesehatanTinggiBadan) || 0;
  const bbNum = Number(fd.kesehatanBeratBadan) || 0;
  const calcImt = tbNum > 0 && bbNum > 0 ? parseFloat((bbNum / ((tbNum / 100) * (tbNum / 100))).toFixed(1)) : null;

  const getImtBadge = (val: number | null) => {
    if (!val) return { label: 'Belum Terhitung (Isi TB & BB)', color: 'bg-slate-100 text-slate-600 border-slate-300' };
    if (val < 17.0) return { label: `${val} - Sangat Kurus (Gizi Kurang Akut)`, color: 'bg-rose-100 text-rose-800 border-rose-300' };
    if (val < 18.5) return { label: `${val} - Kurus (Gizi Kurang Ringan)`, color: 'bg-amber-100 text-amber-800 border-amber-300' };
    if (val <= 25.0) return { label: `${val} - Normal / Ideal (Gizi Baik)`, color: 'bg-emerald-100 text-emerald-800 border-emerald-300' };
    if (val <= 27.0) return { label: `${val} - Overweight (Kelebihan BB)`, color: 'bg-amber-100 text-amber-800 border-amber-300' };
    return { label: `${val} - Obesitas (Perlu Diet & Olahraga)`, color: 'bg-rose-100 text-rose-800 border-rose-300' };
  };

  const imtBadge = getImtBadge(calcImt);

  const handleGenerateAIPemaknaan = async () => {
    if (!fd.asesmenKronologi && !fd.asesmenPsikologis && !fd.asesmenSosial) {
      onShowToast('Harap isi Kronologi Masalah atau minimal salah satu dimensi BPSS terlebih dahulu.', 'error');
      return;
    }

    setIsGenerating(true);
    try {
      const result = await requestGeminiPemaknaan(client);
      if (result) {
        onChangeField('asesmenPemaknaan', result);
        onShowToast('Pemaknaan teoretis berhasil dirumuskan oleh Gemini AI!', 'success');
      }
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Gagal merumuskan pemaknaan dengan AI.', 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  // Helper render checklist item with hover informed box & mobile detail trigger
  const renderChecklistItem = (
    field: 'asesmenMetodePenggalian' | 'asesmenSumberInforman' | 'asesmenInstrumenDigunakan',
    optionName: string,
    themeColor: 'sky' | 'blue' | 'indigo'
  ) => {
    const checked = (fd[field] || []).includes(optionName);
    const knowledge = KNOWLEDGE_DICTIONARY[optionName];

    const activeStyles = {
      sky: 'bg-sky-100/90 text-sky-950 font-bold border-sky-300 shadow-2xs',
      blue: 'bg-blue-100/90 text-blue-950 font-bold border-blue-300 shadow-2xs',
      indigo: 'bg-indigo-100/90 text-indigo-950 font-bold border-indigo-300 shadow-2xs',
    }[themeColor];

    const checkIconColor = {
      sky: 'text-sky-700',
      blue: 'text-blue-700',
      indigo: 'text-indigo-700',
    }[themeColor];

    return (
      <div key={optionName} className="relative group">
        <div
          className={`w-full text-left px-2.5 py-2 rounded-xl text-xs flex items-center justify-between gap-2 transition border ${
            checked
              ? activeStyles
              : 'text-slate-700 hover:bg-slate-50 border-slate-200/80 bg-white'
          }`}
        >
          {/* Checkbox trigger button */}
          <button
            type="button"
            onClick={() => toggleArrayItem(field, optionName)}
            className="flex items-center gap-2 grow text-left cursor-pointer focus:outline-none"
          >
            {checked ? (
              <CheckSquare className={`w-4 h-4 ${checkIconColor} shrink-0`} />
            ) : (
              <Square className="w-4 h-4 text-slate-400 shrink-0" />
            )}
            <span className="leading-snug select-none">{optionName}</span>
          </button>

          {/* Info Button: click to open modal, hover to trigger informed box */}
          {knowledge && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setSelectedKnowledgeModal(knowledge);
              }}
              title="Arahkan kursor atau klik untuk membaca penjelasan metodologi ini"
              className="p-1 text-slate-400 hover:text-sky-600 rounded-lg hover:bg-sky-50 transition shrink-0"
            >
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* POPUP INFORMED BOX ON HOVER (Tooltip floating card) */}
        {knowledge && (
          <div className="hidden group-hover:block absolute z-50 left-2 sm:left-6 -top-3 sm:top-auto sm:bottom-full sm:mb-2 w-80 sm:w-96 max-w-[90vw] p-4 bg-slate-900/95 text-white rounded-2xl shadow-2xl border border-sky-400/50 backdrop-blur-md pointer-events-none transition-all duration-200 animate-in fade-in zoom-in-95">
            {/* Header: Category Badge & Title */}
            <div className="flex items-center justify-between gap-2 border-b border-slate-700/80 pb-2 mb-2.5">
              <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase border ${knowledge.badgeColor}`}>
                {knowledge.category}
              </span>
              <span className="text-[10px] text-slate-400 flex items-center gap-1 font-mono">
                <BookOpen className="w-3 h-3 text-sky-400" /> Pengetahuan Peksos
              </span>
            </div>

            <h5 className="text-xs font-bold text-sky-200 mb-2 leading-snug">
              {knowledge.title}
            </h5>

            {/* Definitions & Explanations */}
            <div className="space-y-2 text-[11px] leading-relaxed text-slate-200">
              <div>
                <strong className="text-sky-300 block font-semibold mb-0.5">📌 Definisi & Konsep:</strong>
                <p className="text-slate-300">{knowledge.definisi}</p>
              </div>

              <div>
                <strong className="text-emerald-300 block font-semibold mb-0.5">🎯 Tujuan Asesmen:</strong>
                <p className="text-slate-300">{knowledge.tujuan}</p>
              </div>

              <div className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                <strong className="text-amber-300 block font-semibold mb-0.5">💡 Tips Praktik Pekerja Sosial:</strong>
                <p className="text-slate-300 italic">{knowledge.tips}</p>
              </div>
            </div>

            <div className="mt-2.5 pt-1.5 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
              <span>Klik pada kotak untuk mencentang</span>
              <span className="text-sky-400">Klik ikon (?) untuk layar penuh</span>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Export Toolbar: Unduh PDF & Word untuk Asesmen */}
      <ExportToolbar
        tabType="asesmen"
        title="Lembar Asesmen BPSS"
        client={client}
        peksosName={peksosName}
        onGoToFullReport={onGoToPrint}
        onShowToast={onShowToast}
      />

      {/* Banner Panduan Asesmen */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-indigo-50 p-4 rounded-xl border border-indigo-200 no-print gap-3 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-indigo-100 rounded-lg text-indigo-700 mt-0.5">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-indigo-950">Panduan Asesmen Komprehensif BPSS (Non-ABH)</h3>
            <p className="text-xs text-indigo-700 mt-0.5 leading-relaxed">
              Lakukan asesmen berpusat pada anak <i>(child-centered)</i>, berbasis kekuatan <i>(strengths perspective)</i>, dan lindungi hak perlindungan anak non-diskriminatif.
            </p>
          </div>
        </div>
      </div>

      {/* 1. Kronologi & Tingkat Risiko */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-2">
          <span>1. Kronologi Masalah & Tingkat Risiko (Red Flag)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <label className="block text-xs font-bold text-slate-800 mb-1">
              A. Deskripsi Masalah / Kronologi Klien
            </label>
            <textarea
              rows={4}
              value={fd.asesmenKronologi || ''}
              onChange={(e) => onChangeField('asesmenKronologi', e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-3 text-sm focus:ring-2 focus:ring-sky-500 text-slate-800"
              placeholder="Ceritakan latar belakang peristiwa, riwayat penelantaran, pekerja anak/jalanan, putus sekolah, konflik pengasuhan, atau kerentanan ekonomi keluarga..."
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-rose-800 mb-1 flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
              B. Tingkat Risiko / Kedaruratan
            </label>
            <select
              value={fd.tingkatRisiko || 'Rendah'}
              onChange={(e) => onChangeField('tingkatRisiko', e.target.value as RiskLevel)}
              className={`w-full rounded-lg border-2 p-2.5 text-sm font-bold focus:ring-2 ${
                fd.tingkatRisiko === 'Kritis'
                  ? 'border-rose-500 bg-rose-50 text-rose-900 ring-rose-500'
                  : fd.tingkatRisiko === 'Tinggi'
                  ? 'border-amber-500 bg-amber-50 text-amber-900 ring-amber-500'
                  : 'border-slate-300 bg-white text-slate-800 focus:ring-sky-500'
              }`}
            >
              <option value="Rendah">Rendah (Aman & Stabil)</option>
              <option value="Sedang">Sedang (Perlu Perhatian Khusus)</option>
              <option value="Tinggi">Tinggi (Ada Ancaman / Trauma Berat)</option>
              <option value="Kritis">Kritis (Kedaruratan Fisik/Psikis / Eksploitasi Akut)</option>
            </select>
            <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
              Kasus <strong>Tinggi</strong> atau <strong>Kritis</strong> memerlukan penanganan cepat dan koordinasi lintas instansi (Dinas Sosial/LPA/Puskesmas/RSUD).
            </p>
          </div>
        </div>
      </div>

      {/* 2. Metodologi, Sumber Informan & Instrumen Penggalian Data Asesmen DENGAN POPUP INFORMED BOX */}
      <div className="bg-linear-to-br from-sky-50/70 via-blue-50/50 to-indigo-50/60 rounded-2xl border-2 border-sky-300 p-6 space-y-5 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-sky-200 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-xs">
              <ClipboardCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-sky-950 flex items-center gap-2">
                <span>2. Metodologi, Sumber Informan & Instrumen Penggalian Data</span>
                <span className="bg-sky-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-1 shadow-2xs">
                  <Info className="w-3 h-3" /> Arahkan Cursor untuk Panduan
                </span>
              </h3>
              <p className="text-xs text-sky-800 mt-0.5">
                Arahkan kursor pada setiap opsi untuk menampilkan kotak informasi pengetahuan praktis pekerja sosial.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-sky-800 bg-white/80 px-3 py-1.5 rounded-xl border border-sky-200 shadow-2xs">
            <HelpCircle className="w-3.5 h-3.5 text-sky-600" />
            <span>Klik ikon <strong>(?)</strong> untuk membaca modul lengkap</span>
          </div>
        </div>

        {/* Grid 3 Kolom: Metode, Informan, Instrumen */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          
          {/* A. Metode / Teknik Penggalian Data */}
          <div className="bg-white p-4 rounded-xl border border-sky-200 shadow-2xs space-y-2.5">
            <div className="border-b border-slate-100 pb-1.5 flex items-center justify-between">
              <h4 className="text-xs font-bold text-sky-950 flex items-center gap-1.5">
                <FileSearch className="w-3.5 h-3.5 text-sky-600" />
                A. Metode & Teknik Penggalian
              </h4>
              <span className="text-[10px] font-semibold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-md">
                {(fd.asesmenMetodePenggalian || []).length} Dipilih
              </span>
            </div>
            <div className="space-y-1.5">
              {METODE_PENGGALIAN_OPTIONS.map((opt) => renderChecklistItem('asesmenMetodePenggalian', opt, 'sky'))}
            </div>
          </div>

          {/* B. Sumber Informasi / Informan */}
          <div className="bg-white p-4 rounded-xl border border-blue-200 shadow-2xs space-y-2.5">
            <div className="border-b border-slate-100 pb-1.5 flex items-center justify-between">
              <h4 className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-blue-600" />
                B. Sumber Informasi (Informan)
              </h4>
              <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
                {(fd.asesmenSumberInforman || []).length} Dipilih
              </span>
            </div>
            <div className="space-y-1.5">
              {SUMBER_INFORMAN_OPTIONS.map((opt) => renderChecklistItem('asesmenSumberInforman', opt, 'blue'))}
            </div>
          </div>

          {/* C. Instrumen Asesmen */}
          <div className="bg-white p-4 rounded-xl border border-indigo-200 shadow-2xs space-y-2.5">
            <div className="border-b border-slate-100 pb-1.5 flex items-center justify-between">
              <h4 className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                <Network className="w-3.5 h-3.5 text-indigo-600" />
                C. Instrumen & Alat Asesmen
              </h4>
              <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md">
                {(fd.asesmenInstrumenDigunakan || []).length} Dipilih
              </span>
            </div>
            <div className="space-y-1.5">
              {INSTRUMEN_ASESMEN_OPTIONS.map((opt) => renderChecklistItem('asesmenInstrumenDigunakan', opt, 'indigo'))}
            </div>
          </div>

        </div>

        {/* Row Bawah: Status Kecukupan Data & Catatan Lapangan */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div>
            <label className="block text-xs font-bold text-sky-950 mb-1.5 flex items-center gap-1">
              <FolderCheck className="w-3.5 h-3.5 text-sky-700" />
              D. Status Kecukupan Data Asesmen
            </label>
            <select
              value={fd.asesmenKecukupanData || 'Data Lengkap & Memadai (Data Saturated)'}
              onChange={(e) => onChangeField('asesmenKecukupanData', e.target.value)}
              className="w-full rounded-xl border border-sky-300 p-2.5 text-xs font-bold text-sky-950 bg-white focus:ring-2 focus:ring-sky-500 shadow-2xs"
            >
              <option value="Data Lengkap & Memadai (Data Saturated)">Data Lengkap & Memadai (Data Saturated)</option>
              <option value="Memerlukan Home Visit Lanjutan ke Keluarga">Memerlukan Home Visit Lanjutan ke Keluarga</option>
              <option value="Memerlukan Rujukan Konsultasi Psikolog Klinis">Memerlukan Rujukan Konsultasi Psikolog Klinis</option>
              <option value="Memerlukan Pemeriksaan Medis Lengkap">Memerlukan Pemeriksaan Medis Lengkap</option>
              <option value="Dalam Proses Penelusuran Keluarga (Family Tracing)">Dalam Proses Penelusuran Keluarga (Family Tracing)</option>
            </select>
            <p className="text-[11px] text-sky-800 mt-1">
              Menentukan apakah intervensi langsung dapat dieksekusi atau membutuhkan penggalian tambahan.
            </p>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-bold text-sky-950 mb-1.5">
              E. Catatan Lapangan & Triangulasi Data (*Peksos Field Notes*)
            </label>
            <textarea
              rows={2}
              value={fd.asesmenCatatanPenggalian || ''}
              onChange={(e) => onChangeField('asesmenCatatanPenggalian', e.target.value)}
              placeholder="Catatan hasil triangulasi informasi anak dengan wali, situasi lingkungan saat home visit, konsistensi cerita, atau temuan spesifik di lapangan..."
              className="w-full rounded-xl border border-sky-300 p-2.5 text-xs text-slate-800 bg-white focus:ring-2 focus:ring-sky-500 shadow-2xs"
            />
          </div>
        </div>

      </div>

      {/* 3. Triangulasi Instrumen Diagnostik: Genogram, Ecomap & Social Roadmap */}
      <div className="bg-white rounded-2xl border-2 border-indigo-200/90 p-5 sm:p-6 space-y-5 shadow-xs">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 border-b border-indigo-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Network className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 flex-wrap">
                <span>3. Triangulasi Instrumen Sosial Terpadu</span>
                <span className="bg-indigo-100 text-indigo-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-indigo-300">
                  Genogram • Ecomap • Social Roadmap
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Integrasi pembacaan silsilah keluarga, jejaring ekologis luar, dan peta navigasi tahapan kemandirian anak binaan.
              </p>
            </div>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200 self-stretch sm:self-auto flex-wrap">
            <button
              type="button"
              onClick={() => setActiveInstrumentTab('ringkasan')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeInstrumentTab === 'ringkasan'
                  ? 'bg-white text-indigo-950 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Ringkasan Form</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveInstrumentTab('genogram')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeInstrumentTab === 'genogram'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-indigo-700'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Visualizer Genogram</span>
              {fd.genogramImage && (
                <span className="w-2 h-2 rounded-full bg-emerald-400" title="Diagram tersimpan" />
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveInstrumentTab('ecomap')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeInstrumentTab === 'ecomap'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-sky-700'
              }`}
            >
              <Network className="w-3.5 h-3.5" />
              <span>Visualizer Ecomap</span>
              {fd.ecomapImage && (
                <span className="w-2 h-2 rounded-full bg-emerald-400" title="Diagram tersimpan" />
              )}
            </button>
          </div>
        </div>

        {/* View 1: Genogram Visualizer Mode */}
        {activeInstrumentTab === 'genogram' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs bg-indigo-50 border border-indigo-200 p-2.5 rounded-xl text-indigo-900">
              <span className="font-semibold flex items-center gap-1.5">
                <Users className="w-4 h-4 text-indigo-600" />
                Mode Visualizer: Susun struktur pohon keluarga 3 generasi secara grafis dengan drag-and-drop.
              </span>
              <button
                type="button"
                onClick={() => setActiveInstrumentTab('ringkasan')}
                className="font-bold text-indigo-700 hover:text-indigo-900 underline"
              >
                &larr; Kembali ke Ringkasan Form
              </button>
            </div>

            <GenogramBuilder
              client={client}
              onSaveDiagram={handleSaveGenogram}
              onSyncCatatan={(text) => onChangeField('genogramCatatan', text)}
              onShowToast={onShowToast}
            />
          </div>
        )}

        {/* View 2: Ecomap Visualizer Mode */}
        {activeInstrumentTab === 'ecomap' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs bg-sky-50 border border-sky-200 p-2.5 rounded-xl text-sky-900">
              <span className="font-semibold flex items-center gap-1.5">
                <Network className="w-4 h-4 text-sky-600" />
                Mode Visualizer: Pemetaan hubungan sosial, komunitas, dan sumber daya pendukung klien dengan opsi simpan gambar.
              </span>
              <button
                type="button"
                onClick={() => setActiveInstrumentTab('ringkasan')}
                className="font-bold text-sky-700 hover:text-sky-900 underline"
              >
                &larr; Kembali ke Ringkasan Form
              </button>
            </div>

            <EcomapBuilder
              client={client}
              onSaveDiagram={handleSaveEcomap}
              onSyncCatatan={(text) => onChangeField('ecomapCatatan', text)}
              onShowToast={onShowToast}
            />
          </div>
        )}

        {/* View 3: Ringkasan Form & Quick Launcher Cards */}
        {activeInstrumentTab === 'ringkasan' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* A. Genogram Card */}
            <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-2">
                  <span className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-indigo-600" />
                    A. Genogram (3 Generasi)
                  </span>
                  <span className="text-[10px] font-bold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md border border-indigo-200">
                    Sistem Asuhan
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed mb-2.5">
                  <strong>Keterkaitan:</strong> Menautkan silsilah keluarga 3 generasi untuk mendeteksi siklus penelantaran, riwayat pola asuh, perceraian, dan figur asuh pengganti (*kinship care*).
                </p>

                {/* Quick Launcher Button */}
                <button
                  type="button"
                  onClick={() => setActiveInstrumentTab('genogram')}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition shadow-2xs mb-2"
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Buka Canvas Genogram (Drag & Drop)</span>
                </button>

                {/* Diagram Status Banner if Saved */}
                {fd.genogramImage && (
                  <div className="flex items-center gap-1.5 text-[10px] bg-emerald-50 text-emerald-800 border border-emerald-200 p-1.5 rounded-lg mb-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Diagram grafis tersimpan ({fd.genogramData?.nodes?.length || 0} anggota keluarga)</span>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Catatan Temuan Genogram:
                </label>
                <textarea
                  rows={3}
                  value={fd.genogramCatatan || ''}
                  onChange={(e) => onChangeField('genogramCatatan', e.target.value)}
                  placeholder="Contoh: Orang tua bercerai sejak anak usia 7 thn, anak sempat diasuh nenek maternal, kakek memiliki riwayat sakit kronis..."
                  className="w-full rounded-xl border border-slate-300 p-2.5 text-xs text-slate-800 bg-white focus:ring-2 focus:ring-indigo-500 shadow-2xs"
                />
              </div>
            </div>

            {/* B. Ecomap Card */}
            <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-2">
                  <span className="text-xs font-bold text-sky-950 flex items-center gap-1.5">
                    <Network className="w-4 h-4 text-sky-600" />
                    B. Ecomap (Ekologi Sosial)
                  </span>
                  <span className="text-[10px] font-bold bg-sky-50 text-sky-700 px-2 py-0.5 rounded-md border border-sky-200">
                    Jejaring Eksternal
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed mb-2.5">
                  <strong>Keterkaitan:</strong> Menautkan sistem luar: sekolah asal / PKBM, teman sebaya asrama, tempat kerja anak di jalan/pasar, faskes, dan satgas sosial wilayah.
                </p>

                {/* Quick Launcher Button */}
                <button
                  type="button"
                  onClick={() => setActiveInstrumentTab('ecomap')}
                  className="w-full bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white font-bold text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition shadow-2xs mb-2"
                >
                  <Network className="w-3.5 h-3.5" />
                  <span>Buka Canvas Ecomap (Drag & Drop)</span>
                </button>

                {/* Diagram Status Banner if Saved */}
                {fd.ecomapImage && (
                  <div className="flex items-center gap-1.5 text-[10px] bg-emerald-50 text-emerald-800 border border-emerald-200 p-1.5 rounded-lg mb-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Diagram grafis tersimpan ({fd.ecomapData?.domains?.length || 0} jejaring sistem)</span>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Catatan Temuan Ecomap:
                </label>
                <textarea
                  rows={3}
                  value={fd.ecomapCatatan || ''}
                  onChange={(e) => onChangeField('ecomapCatatan', e.target.value)}
                  placeholder="Contoh: Relasi dengan sekolah asal putus (stres tinggi), relasi asrama suportif, terhubung dengan tutor PKBM..."
                  className="w-full rounded-xl border border-slate-300 p-2.5 text-xs text-slate-800 bg-white focus:ring-2 focus:ring-sky-500 shadow-2xs"
                />
              </div>
            </div>

            {/* C. Social Roadmap Card */}
            <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-2">
                  <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-emerald-600" />
                    C. Social Roadmap (Peta Jalan)
                  </span>
                  <span className="text-[10px] font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-md border border-emerald-200">
                    Navigasi 3 Fase
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed mb-2">
                  <strong>Keterkaitan:</strong> Menautkan alur 3 fase: <strong>Fase 1: Masa Lalu</strong> &rarr; <strong>Fase 2: Asrama & Vokasi Sentra</strong> &rarr; <strong>Fase 3: Kemandirian Aftercare</strong>.
                </p>

                <div className="bg-emerald-50/80 border border-emerald-200 p-2 rounded-lg text-[10px] text-emerald-900 space-y-1 mb-2">
                  <div><strong>&bull; Fase 1 (Masa Lalu):</strong> Riwayat jalanan / anak terlantar</div>
                  <div><strong>&bull; Fase 2 (Kini):</strong> Asrama & Jurusan {fd.jurusan || 'Vokasi'}</div>
                  <div><strong>&bull; Fase 3 (Nanti):</strong> Kemandirian sosial & Aftercare</div>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Catatan Target Social Roadmap:
                </label>
                <textarea
                  rows={3}
                  value={fd.socialRoadmapCatatan || ''}
                  onChange={(e) => onChangeField('socialRoadmapCatatan', e.target.value)}
                  placeholder="Contoh: Target Fase 2: sertifikasi montir motor & regulasi emosi; Target Fase 3: magang bengkel mitra & ijazah Paket B..."
                  className="w-full rounded-xl border border-slate-300 p-2.5 text-xs text-slate-800 bg-white focus:ring-2 focus:ring-emerald-500 shadow-2xs"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 4. Dimensi BPSS */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-2">
          4. Asesmen BPSS Terpadu (Biopsikososiospiritual)
        </h3>

        <div className="space-y-4">
          {/* Modul Kesehatan Fisik Dasar & Antropometri Balai (Balai Health Record) */}
          <div className="bg-linear-to-br from-emerald-50/70 via-teal-50/40 to-slate-50 border-2 border-emerald-300 rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-200/80 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-extrabold text-emerald-950 flex items-center gap-2">
                    <span>Modul Kesehatan Fisik Dasar & Antropometri Balai</span>
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-300">
                      Balai Health Record
                    </span>
                  </h4>
                  <p className="text-xs text-emerald-800 mt-0.5">
                    Pemeriksaan antropometri, status gizi, skrining infeksi kulit asrama, dan riwayat adiksi zat remaja binaan.
                  </p>
                </div>
              </div>

              {/* IMT Status Preview Pill */}
              {calcImt && (
                <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-emerald-300 shadow-2xs self-start sm:self-auto">
                  <Scale className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-bold text-slate-700">IMT: <strong>{calcImt}</strong></span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${imtBadge.color}`}>
                    {imtBadge.label.split('-')[1] || imtBadge.label}
                  </span>
                </div>
              )}
            </div>

            {/* Antropometri Grid: Gol. Darah, TB, BB, IMT */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-3.5 rounded-xl border border-emerald-200 shadow-2xs">
              {/* Golongan Darah */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Golongan Darah
                </label>
                <select
                  value={fd.kesehatanGolonganDarah || ''}
                  onChange={(e) => onChangeField('kesehatanGolonganDarah', e.target.value)}
                  className="w-full rounded-lg border border-slate-300 p-2 text-xs font-bold bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">-- Pilih --</option>
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="AB">AB</option>
                  <option value="O">O</option>
                  <option value="Belum Tahu">Belum Tahu / Belum Uji</option>
                </select>
              </div>

              {/* Tinggi Badan */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Tinggi Badan (TB)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="50"
                    max="220"
                    value={fd.kesehatanTinggiBadan || ''}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 0;
                      onChangeField('kesehatanTinggiBadan', val);
                      const currentBB = Number(fd.kesehatanBeratBadan) || 0;
                      if (val > 0 && currentBB > 0) {
                        const newImt = parseFloat((currentBB / ((val / 100) * (val / 100))).toFixed(1));
                        onChangeField('kesehatanIMT', newImt);
                      }
                    }}
                    placeholder="160"
                    className="w-full rounded-lg border border-slate-300 p-2 pr-8 text-xs font-bold bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
                  />
                  <span className="absolute right-2.5 top-2 text-[10px] text-slate-400 font-bold">cm</span>
                </div>
              </div>

              {/* Berat Badan */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Berat Badan (BB)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="20"
                    max="180"
                    step="0.5"
                    value={fd.kesehatanBeratBadan || ''}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 0;
                      onChangeField('kesehatanBeratBadan', val);
                      const currentTB = Number(fd.kesehatanTinggiBadan) || 0;
                      if (currentTB > 0 && val > 0) {
                        const newImt = parseFloat((val / ((currentTB / 100) * (currentTB / 100))).toFixed(1));
                        onChangeField('kesehatanIMT', newImt);
                      }
                    }}
                    placeholder="50"
                    className="w-full rounded-lg border border-slate-300 p-2 pr-8 text-xs font-bold bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
                  />
                  <span className="absolute right-2.5 top-2 text-[10px] text-slate-400 font-bold">kg</span>
                </div>
              </div>

              {/* IMT & Status Gizi */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Kalkulasi IMT & Status Gizi
                </label>
                <div className={`p-2 rounded-lg border text-center text-xs font-extrabold ${imtBadge.color}`}>
                  {calcImt ? `${calcImt} kg/m²` : '-'}
                </div>
              </div>
            </div>

            {/* Skrining Spesifik Asrama & Remaja Balai */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {/* Status Imunisasi */}
              <div>
                <label className="block text-[11px] font-bold text-emerald-950 mb-1">
                  Status Imunisasi Dasar
                </label>
                <select
                  value={fd.kesehatanStatusImunisasi || ''}
                  onChange={(e) => onChangeField('kesehatanStatusImunisasi', e.target.value)}
                  className="w-full rounded-lg border border-emerald-300 p-2 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">-- Pilih Status --</option>
                  <option value="Lengkap (Sesuai Usia)">Lengkap (Sesuai Usia)</option>
                  <option value="Tidak Lengkap">Tidak Lengkap</option>
                  <option value="Belum Pernah / Tidak Tahu">Belum Pernah / Tidak Tahu</option>
                </select>
              </div>

              {/* Skrining Zat / Adiksi */}
              <div>
                <label className="block text-[11px] font-bold text-emerald-950 mb-1">
                  Skrining Riwayat Zat / Adiksi
                </label>
                <select
                  value={fd.kesehatanSkriningZat || ''}
                  onChange={(e) => onChangeField('kesehatanSkriningZat', e.target.value)}
                  className="w-full rounded-lg border border-emerald-300 p-2 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">-- Hasil Skrining --</option>
                  <option value="Bebas Zat (Bersih / Tidak Ada Riwayat)">Bebas Zat (Bersih / Tidak Ada Riwayat)</option>
                  <option value="Perokok Aktif">Perokok Aktif</option>
                  <option value="Riwayat Menghirup Lem (Inhalan)">Riwayat Menghirup Lem (Inhalan)</option>
                  <option value="Riwayat Alkohol / Minuman Keras">Riwayat Alkohol / Minuman Keras</option>
                  <option value="Riwayat Zat Adiktif / Obat Terlarang">Riwayat Zat Adiktif / Obat Terlarang</option>
                  <option value="Dalam Masa Pemulihan / Adiksi Terkendali">Dalam Masa Pemulihan / Adiksi Terkendali</option>
                </select>
              </div>

              {/* Skrining Penyakit Kulit Asrama */}
              <div>
                <label className="block text-[11px] font-bold text-emerald-950 mb-1">
                  Skrining Penyakit Kulit Asrama
                </label>
                <select
                  value={fd.kesehatanPenyakitKulit || ''}
                  onChange={(e) => onChangeField('kesehatanPenyakitKulit', e.target.value)}
                  className="w-full rounded-lg border border-emerald-300 p-2 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">-- Skrining Kulit --</option>
                  <option value="Bebas Keluhan Kulit (Sehat)">Bebas Keluhan Kulit (Sehat)</option>
                  <option value="Scabies / Gudik Aktif (Perlu Salep/Isolasi)">Scabies / Gudik Aktif (Perlu Salep/Isolasi)</option>
                  <option value="Jamur Kulit (Tinea / Panu / Kadas)">Jamur Kulit (Tinea / Panu / Kadas)</option>
                  <option value="Alergi Gatal / Dermatitis">Alergi Gatal / Dermatitis</option>
                  <option value="Dalam Terapi Pengobatan Balai">Dalam Terapi Pengobatan Balai</option>
                </select>
              </div>

              {/* Riwayat Alergi */}
              <div>
                <label className="block text-[11px] font-bold text-emerald-950 mb-1">
                  Riwayat Alergi (Makanan/Obat)
                </label>
                <input
                  type="text"
                  value={fd.kesehatanRiwayatAlergi || ''}
                  onChange={(e) => onChangeField('kesehatanRiwayatAlergi', e.target.value)}
                  placeholder="Contoh: Alergi udang, telur, penisilin, atau tidak ada"
                  className="w-full rounded-lg border border-emerald-300 p-2 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Catatan Klinik Balai & Narasi Biologis */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-bold text-emerald-950 mb-1 flex items-center gap-1.5">
                  <Pill className="w-3.5 h-3.5 text-emerald-700" />
                  Catatan Klinik Balai & Tindakan Medis
                </label>
                <textarea
                  rows={2}
                  value={fd.kesehatanCatatanKlinik || ''}
                  onChange={(e) => onChangeField('kesehatanCatatanKlinik', e.target.value)}
                  placeholder="Catatan perawat/dokter balai: riwayat pengobatan, vitamin berkala, rujukan puskesmas..."
                  className="w-full rounded-lg border border-emerald-300 p-2.5 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-emerald-950 mb-1 flex items-center gap-1.5">
                  <Dna className="w-3.5 h-3.5 text-emerald-700" />
                  Deskripsi Naratif Dimensi Biologis BPSS
                </label>
                <textarea
                  rows={2}
                  value={fd.asesmenBiologis || ''}
                  onChange={(e) => onChangeField('asesmenBiologis', e.target.value)}
                  placeholder="Ringkasan narasi kesehatan fisik, stamina harian, disabilitas, dan kebugaran anak..."
                  className="w-full rounded-lg border border-emerald-300 p-2.5 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* 3 Dimensi BPSS: Psikologis, Sosial, Spiritual */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Psikologis */}
            <div className="bg-purple-50/50 p-4 rounded-xl border border-purple-200">
              <label className="block text-xs font-bold text-purple-950 mb-1.5 flex items-center gap-1.5">
                <Brain className="w-4 h-4 text-purple-600" />
                Dimensi Psikologis / Emosi & Kognisi
              </label>
              <textarea
                rows={4}
                value={fd.asesmenPsikologis || ''}
                onChange={(e) => onChangeField('asesmenPsikologis', e.target.value)}
                className="w-full rounded-lg border border-purple-300 p-2.5 text-xs focus:ring-2 focus:ring-purple-500 bg-white text-slate-800"
                placeholder="Regulasi emosi, trauma masa lalu, konsep diri, kecemasan, atau minat belajar..."
              />
            </div>

            {/* Sosial */}
            <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-200">
              <label className="block text-xs font-bold text-blue-950 mb-1.5 flex items-center gap-1.5">
                <Users2 className="w-4 h-4 text-blue-600" />
                Dimensi Sosial / Relasi & Lingkungan
              </label>
              <textarea
                rows={4}
                value={fd.asesmenSosial || ''}
                onChange={(e) => onChangeField('asesmenSosial', e.target.value)}
                className="w-full rounded-lg border border-blue-300 p-2.5 text-xs focus:ring-2 focus:ring-blue-500 bg-white text-slate-800"
                placeholder="Interaksi dengan orang tua/wali, pertemanan sebaya di asrama, hubungan dengan lingkungan asal..."
              />
            </div>

            {/* Spiritual */}
            <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-200">
              <label className="block text-xs font-bold text-amber-950 mb-1.5 flex items-center gap-1.5">
                <HeartHandshake className="w-4 h-4 text-amber-600" />
                Dimensi Spiritual / Nilai & Moral
              </label>
              <textarea
                rows={4}
                value={fd.asesmenSpiritual || ''}
                onChange={(e) => onChangeField('asesmenSpiritual', e.target.value)}
                className="w-full rounded-lg border border-amber-300 p-2.5 text-xs focus:ring-2 focus:ring-amber-500 bg-white text-slate-800"
                placeholder="Praktik keagamaan, nilai moral, kejujuran, dan makna hidup yang dianut anak..."
              />
            </div>
          </div>
        </div>
      </div>

      {/* 5. Kapasitas Coping */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-2">
          5. Kapasitas Coping & Keberfungsian Sosial
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              1. Pemenuhan Kebutuhan Dasar
            </label>
            <textarea
              rows={3}
              value={fd.asesmenKebutuhanDasar || ''}
              onChange={(e) => onChangeField('asesmenKebutuhanDasar', e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2.5 text-xs focus:ring-2 focus:ring-sky-500"
              placeholder="Pangan, sandang, tempat tinggal aman, perlindungan..."
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              2. Strategi Pemecahan Masalah
            </label>
            <textarea
              rows={3}
              value={fd.asesmenPemecahanMasalah || ''}
              onChange={(e) => onChangeField('asesmenPemecahanMasalah', e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2.5 text-xs focus:ring-2 focus:ring-sky-500"
              placeholder="Cara klien merespons tekanan / stres / masalah dalam pengasuhan..."
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              3. Pelaksanaan Peran Sosial
            </label>
            <textarea
              rows={3}
              value={fd.asesmenPeranSosial || ''}
              onChange={(e) => onChangeField('asesmenPeranSosial', e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2.5 text-xs focus:ring-2 focus:ring-sky-500"
              placeholder="Peran sebagai anak, pelajar (formal/PKBM), warga asrama..."
            />
          </div>
        </div>
      </div>

      {/* 6. Analisis & Pemaknaan dengan Gemini AI */}
      <div className="bg-linear-to-br from-indigo-50/80 to-purple-50/80 rounded-xl border-2 border-indigo-200 p-6 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h3 className="text-base font-bold text-indigo-950 flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-amber-500" />
              6. Analisis & Pemaknaan Teoretis (Theoretical Meaning-Making)
            </h3>
            <p className="text-xs text-indigo-700 mt-0.5">
              Rumusan akar masalah dan potensi kekuatan (strengths perspective) berlandaskan teori pekerjaan sosial anak (Non-ABH).
            </p>
          </div>

          {/* Gemini AI Trigger Button */}
          <button
            type="button"
            onClick={handleGenerateAIPemaknaan}
            disabled={isGenerating}
            className="w-full sm:w-auto bg-linear-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-4 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Menyusun Analisis AI...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Bantu Maknai dengan Gemini AI</span>
              </>
            )}
          </button>
        </div>

        <textarea
          rows={5}
          value={fd.asesmenPemaknaan || ''}
          onChange={(e) => onChangeField('asesmenPemaknaan', e.target.value)}
          className="w-full rounded-xl border border-indigo-300 p-3.5 text-sm text-slate-800 bg-white font-normal leading-relaxed focus:ring-2 focus:ring-indigo-500 shadow-xs"
          placeholder="Klik 'Bantu Maknai dengan Gemini AI' atau ketik manual analisis pemaknaan kasus berdasarkan teori pekerjaan sosial (Teori Ekologi Bronfenbrenner, Attachment Bowlby, Psikososial Erikson, Teori Resiliensi)..."
        />

        <div className="flex items-center gap-2 text-[11px] text-indigo-700 bg-indigo-100/60 p-2.5 rounded-lg">
          <Sparkles className="w-3.5 h-3.5 shrink-0 text-indigo-600" />
          <span>
            Fitur ini menggunakan <strong>Gemini AI (gemini-3.8-flash)</strong> di server untuk merangkum korelasi teoretis antara pemicu lingkungan mikrosistem, dampak psikologis, dan potensi ketahanan anak binaan.
          </span>
        </div>
      </div>

      {/* FULL DETAIL MODAL (Saat Peksos Mengklik Ikon ? atau Tombol Detail) */}
      {selectedKnowledgeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold border ${selectedKnowledgeModal.badgeColor.replace('text-sky-300', 'text-sky-800 bg-sky-100').replace('text-blue-300', 'text-blue-800 bg-blue-100').replace('text-indigo-300', 'text-indigo-800 bg-indigo-100')}`}>
                  {selectedKnowledgeModal.category}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedKnowledgeModal(null)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <h4 className="text-base font-bold text-slate-900 leading-snug">
                {selectedKnowledgeModal.title}
              </h4>
            </div>

            <div className="space-y-3.5 text-xs text-slate-700 leading-relaxed">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <strong className="text-sky-900 block font-bold mb-1 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-sky-600" /> Definisi & Landasan Metodologi:
                </strong>
                <p>{selectedKnowledgeModal.definisi}</p>
              </div>

              <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-200">
                <strong className="text-emerald-950 block font-bold mb-1 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Tujuan & Manfaat Asesmen:
                </strong>
                <p className="text-emerald-900">{selectedKnowledgeModal.tujuan}</p>
              </div>

              <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200">
                <strong className="text-amber-950 block font-bold mb-1 flex items-center gap-1.5">
                  <Lightbulb className="w-4 h-4 text-amber-600" /> Panduan & Tips Praktik Pekerja Sosial:
                </strong>
                <p className="text-amber-900 italic">{selectedKnowledgeModal.tips}</p>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedKnowledgeModal(null)}
                className="bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs px-5 py-2 rounded-xl transition shadow-xs"
              >
                Tutup Panduan
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
