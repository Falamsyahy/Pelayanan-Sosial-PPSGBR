import React from 'react';
import { Filter, CheckCircle2 } from 'lucide-react';
import { Client, ClientStatus } from '../../types';

interface TabSeleksiProps {
  client: Client;
  onChangeField: (key: string, value: any) => void;
}

export const TabSeleksi: React.FC<TabSeleksiProps> = ({ client, onChangeField }) => {
  const fd = client.formData;

  return (
    <div className="space-y-6">
      <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-r-md shadow-xs no-print">
        <div className="flex items-start">
          <Filter className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
          <div className="ml-3">
            <h3 className="text-sm font-bold text-amber-900">Tahap Skrining & Seleksi Calon Penerima Manfaat</h3>
            <p className="text-xs text-amber-800 mt-1 leading-relaxed">
              Lakukan asesmen awal kelayakan. Jika anak telah diverifikasi dan memenuhi persyaratan program rehabilitasi/pemberdayaan, ubah Keputusan Seleksi menjadi <strong>"Kasus Aktif"</strong>.
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
        <div>
          <label className="block text-sm font-bold text-slate-800 mb-1">
            Catatan Penjangkauan / Asesmen Seleksi Awal
          </label>
          <textarea
            rows={4}
            value={fd.seleksiCatatan || ''}
            onChange={(e) => onChangeField('seleksiCatatan', e.target.value)}
            className="w-full rounded-lg border border-slate-300 p-3 text-sm focus:ring-2 focus:ring-sky-500 text-slate-800"
            placeholder="Tuliskan latar belakang penjangkauan, asal usul rujukan (Satgas Sosial/Dinsos/Kepolisian/Masyarakat), dan kelayakan awal..."
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="block text-sm font-bold text-sky-900 mb-1">
              Keputusan Seleksi
            </label>
            <select
              value={fd.seleksiKeputusan || client.status}
              onChange={(e) => {
                const val = e.target.value as ClientStatus;
                onChangeField('seleksiKeputusan', val);
                onChangeField('status', val);
              }}
              className="w-full rounded-lg border-2 border-sky-300 p-2.5 text-sm font-bold text-sky-950 bg-sky-50/40 focus:ring-2 focus:ring-sky-500"
            >
              <option value="Calon Klien (Proses Seleksi)">Masih Tahap Seleksi (Calon Klien)</option>
              <option value="Kasus Aktif">Terima - Jadikan Kasus Aktif</option>
              <option value="Ditolak (Tidak Memenuhi Syarat)">Tolak / Tidak Memenuhi Syarat</option>
            </select>
          </div>

          <div className="flex items-center text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 mr-2 shrink-0" />
            <span>
              Ketika status diubah menjadi <strong>"Kasus Aktif"</strong>, anak resmi terdaftar dalam pembinaan dan tab ini dapat diminimalkan sesuai kebutuhan.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
