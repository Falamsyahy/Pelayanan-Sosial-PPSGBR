import React, { useState } from 'react';
import { 
  Handshake, 
  Sparkles, 
  Loader2, 
  ClipboardList, 
  Plus, 
  Trash2, 
  Target, 
  CheckCircle,
  FileText,
  UserCheck,
  ChevronDown,
  ChevronUp,
  Stethoscope,
  Brain,
  Wrench,
  Home,
  Shield,
  Layers,
  ArrowLeft,
  CheckCheck,
  Check,
  FileEdit,
  Lightbulb,
  Save
} from 'lucide-react';
import { Client, InterventionLogItem, MultidisciplinaryRole } from '../../types';
import { requestGeminiIntervensi } from '../../services/geminiService';
import { saveClient as saveClientToFirestore } from '../../firebase';
import { ExportToolbar } from '../ExportToolbar';

interface TabIntervensiProps {
  client: Client;
  onChangeField: (key: string, value: any) => void;
  onAddIntervensiLog: (item: Omit<InterventionLogItem, 'id'>) => void;
  onRemoveIntervensiLog: (id: string) => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
  peksosName?: string;
  onSaveClient?: () => Promise<void> | void;
}

export const TabIntervensi: React.FC<TabIntervensiProps> = ({
  client,
  onChangeField,
  onAddIntervensiLog,
  onRemoveIntervensiLog,
  onShowToast,
  peksosName,
  onSaveClient,
}) => {
  const fd = client.formData;
  const [isDrafting, setIsDrafting] = useState(false);
  const [isSavingDraft, setIsSavingDraft] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Mode input: 'standard' | 'soap'
  const [logMode, setLogMode] = useState<'standard' | 'soap'>('soap');

  // Expanded log IDs for viewing SOAP details
  const [expandedLogIds, setExpandedLogIds] = useState<Record<string, boolean>>({});

  // Log Form State
  const [logTanggal, setLogTanggal] = useState(new Date().toISOString().split('T')[0]);
  const [logDeskripsi, setLogDeskripsi] = useState('');
  const [logIndikator, setLogIndikator] = useState('');

  // Multidisciplinary & SOAP fields
  const [peranPelaksana, setPeranPelaksana] = useState<MultidisciplinaryRole>('Pekerja Sosial');
  const [soapSubjective, setSoapSubjective] = useState('');
  const [soapObjective, setSoapObjective] = useState('');
  const [soapAssessment, setSoapAssessment] = useState('');
  const [soapPlan, setSoapPlan] = useState('');

  const toggleExpand = (id: string) => {
    setExpandedLogIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleGenerateAIIntervensi = async () => {
    if (!fd.asesmenKronologi) {
      onShowToast('Harap isi data Kronologi / Masalah di tab Asesmen terlebih dahulu.', 'error');
      return;
    }

    setIsDrafting(true);
    try {
      const result = await requestGeminiIntervensi(client);
      const timestamp = new Date().toLocaleString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }) + ' WIB';

      if (result.tujuan) onChangeField('aiIntervensiTujuan', result.tujuan);
      if (result.strategi) onChangeField('aiIntervensiStrategi', result.strategi);
      if (result.indikator && result.indikator.length > 0) {
        onChangeField('aiIntervensiIndikator', result.indikator);
      }
      onChangeField('aiIntervensiGeneratedAt', timestamp);

      // Auto persist to local storage as well
      try {
        const raw = localStorage.getItem('rsa_jabar_clients_v2');
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed[client.id]) {
            parsed[client.id].formData.aiIntervensiTujuan = result.tujuan || parsed[client.id].formData.aiIntervensiTujuan;
            parsed[client.id].formData.aiIntervensiStrategi = result.strategi || parsed[client.id].formData.aiIntervensiStrategi;
            parsed[client.id].formData.aiIntervensiIndikator = result.indikator || parsed[client.id].formData.aiIntervensiIndikator;
            parsed[client.id].formData.aiIntervensiGeneratedAt = timestamp;
            localStorage.setItem('rsa_jabar_clients_v2', JSON.stringify(parsed));
          }
        }
      } catch (_) {}

      onShowToast('Draft rekomendasi intervensi AI berhasil dirumuskan! Tekan "Simpan Draft AI" untuk menyimpan permanen.', 'success');
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Gagal merumuskan intervensi dengan AI.', 'error');
    } finally {
      setIsDrafting(false);
    }
  };

  const handleSaveAIDraft = async () => {
    if (!fd.aiIntervensiTujuan && !fd.aiIntervensiStrategi) {
      onShowToast('Belum ada draft rekomendasi AI yang dapat disimpan.', 'error');
      return;
    }

    setIsSavingDraft(true);
    try {
      const timestamp = fd.aiIntervensiGeneratedAt || (new Date().toLocaleString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }) + ' WIB');

      if (!fd.aiIntervensiGeneratedAt) {
        onChangeField('aiIntervensiGeneratedAt', timestamp);
      }

      // Build updated client representation
      const updatedClient: Client = {
        ...client,
        formData: {
          ...client.formData,
          aiIntervensiTujuan: fd.aiIntervensiTujuan,
          aiIntervensiStrategi: fd.aiIntervensiStrategi,
          aiIntervensiIndikator: fd.aiIntervensiIndikator,
          aiIntervensiGeneratedAt: timestamp,
        },
      };

      // 1. Save to Firestore
      try {
        await saveClientToFirestore(updatedClient);
      } catch (firestoreErr) {
        console.warn('Sync to Cloud Firestore pending/offline:', firestoreErr);
      }

      // 2. Save directly to localStorage
      try {
        const raw = localStorage.getItem('rsa_jabar_clients_v2');
        const parsed = raw ? JSON.parse(raw) : {};
        parsed[client.id] = updatedClient;
        localStorage.setItem('rsa_jabar_clients_v2', JSON.stringify(parsed));
      } catch (localErr) {
        console.warn('Failed to save to localStorage:', localErr);
      }

      // 3. Trigger parent onSaveClient if provided
      if (onSaveClient) {
        await onSaveClient();
      }

      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 4000);
      onShowToast('Draft rekomendasi AI berhasil disimpan permanen! Tidak akan hilang saat membuka kembali.', 'success');
    } catch (err: any) {
      console.error('Error saving AI draft:', err);
      onShowToast('Draft AI disimpan ke memori lokal.', 'success');
      setSavedSuccess(true);
    } finally {
      setIsSavingDraft(false);
    }
  };

  const handleApplyAllAIDraft = () => {
    if (!fd.aiIntervensiTujuan && !fd.aiIntervensiStrategi) {
      onShowToast('Belum ada draft rekomendasi AI yang tersedia untuk diterapkan.', 'error');
      return;
    }
    if (fd.aiIntervensiTujuan) onChangeField('intervensiTujuan', fd.aiIntervensiTujuan);
    if (fd.aiIntervensiStrategi) onChangeField('intervensiStrategi', fd.aiIntervensiStrategi);
    onShowToast('Rekomendasi Tujuan & Strategi AI berhasil disalin ke Rencana Resmi Pekerja Sosial!', 'success');
  };

  const handleApplyTujuanOnly = () => {
    if (!fd.aiIntervensiTujuan) return;
    onChangeField('intervensiTujuan', fd.aiIntervensiTujuan);
    onShowToast('Rekomendasi Tujuan AI disalin ke Rencana Peksos.', 'success');
  };

  const handleApplyStrategiOnly = () => {
    if (!fd.aiIntervensiStrategi) return;
    onChangeField('intervensiStrategi', fd.aiIntervensiStrategi);
    onShowToast('Rekomendasi Strategi AI disalin ke Rencana Peksos.', 'success');
  };

  const handleAddLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (logMode === 'soap') {
      if (!soapSubjective.trim() && !soapObjective.trim() && !soapAssessment.trim() && !soapPlan.trim()) {
        onShowToast('Mohon lengkapi minimal salah satu komponen catatan SOAP.', 'error');
        return;
      }

      const generatedDeskripsi = logDeskripsi.trim() || `[SOAP] Sesi ${peranPelaksana}: ${soapAssessment.slice(0, 70) || soapObjective.slice(0, 70) || 'Bimbingan terpadu'}`;
      const generatedIndikator = logIndikator.trim() || (soapPlan ? `Rencana: ${soapPlan.slice(0, 80)}` : 'Terlaksana sesuai SOP pelayanan multidisiplin.');

      onAddIntervensiLog({
        tanggal: logTanggal,
        deskripsi: generatedDeskripsi,
        indikator: generatedIndikator,
        isSOAP: true,
        peranPelaksana,
        subjective: soapSubjective.trim(),
        objective: soapObjective.trim(),
        assessment: soapAssessment.trim(),
        plan: soapPlan.trim(),
      });

      // Reset SOAP form
      setSoapSubjective('');
      setSoapObjective('');
      setSoapAssessment('');
      setSoapPlan('');
      setLogDeskripsi('');
      setLogIndikator('');
      onShowToast(`Catatan SOAP intervensi (${peranPelaksana}) berhasil ditambahkan.`, 'success');
    } else {
      if (!logDeskripsi.trim() || !logTanggal) {
        onShowToast('Tanggal dan deskripsi tindakan wajib diisi.', 'error');
        return;
      }

      onAddIntervensiLog({
        tanggal: logTanggal,
        deskripsi: logDeskripsi.trim(),
        indikator: logIndikator.trim() || 'Terlaksana sesuai rencana pembinaan.',
        isSOAP: false,
        peranPelaksana,
      });

      setLogDeskripsi('');
      setLogIndikator('');
      onShowToast('Log intervensi ditambahkan.', 'success');
    }
  };

  const getRoleBadge = (role?: MultidisciplinaryRole) => {
    switch (role) {
      case 'Instruktur Vokasi':
        return { label: 'Instruktur Vokasi', color: 'bg-amber-100 text-amber-800 border-amber-300', icon: Wrench };
      case 'Pengasuh Asrama':
        return { label: 'Pengasuh Asrama', color: 'bg-emerald-100 text-emerald-800 border-emerald-300', icon: Home };
      case 'Tenaga Medis':
        return { label: 'Tenaga Medis Balai', color: 'bg-rose-100 text-rose-800 border-rose-300', icon: Stethoscope };
      case 'Psikolog Klinis':
        return { label: 'Psikolog Klinis', color: 'bg-purple-100 text-purple-800 border-purple-300', icon: Brain };
      case 'Pekerja Sosial':
      default:
        return { label: 'Pekerja Sosial', color: 'bg-sky-100 text-sky-800 border-sky-300', icon: UserCheck };
    }
  };

  return (
    <div className="space-y-6">
      {/* Export Toolbar: Unduh PDF & Word untuk Intervensi */}
      <ExportToolbar
        tabType="intervensi"
        title="Rencana & Log Intervensi"
        client={client}
        peksosName={peksosName}
        onShowToast={onShowToast}
      />

      {/* Panduan Etik */}
      <div className="bg-sky-50 border-l-4 border-sky-500 p-4 rounded-r-md shadow-xs no-print">
        <div className="flex items-start">
          <Handshake className="w-5 h-5 text-sky-600 mt-0.5 shrink-0" />
          <div className="ml-3">
            <h3 className="text-sm font-bold text-sky-900">Panduan Etik: Perencanaan & Pelaksanaan Intervensi Terpadu</h3>
            <p className="text-xs text-sky-700 mt-1 leading-relaxed">
              <strong>Prinsip Multidisiplin & Akuntabilitas Rekam Medis Sosial:</strong> Gunakan catatan SOAP (Subjective, Objective, Assessment, Plan) untuk menjamin kesinambungan layanan antara Pekerja Sosial, Instruktur Kejuruan, Pengasuh Asrama, Tenaga Medis, dan Psikolog tanpa tumpang tindih kewenangan.
            </p>
          </div>
        </div>
      </div>

      {/* 1. Perencanaan Intervensi Terpadu: 2 Frame (Rencana Resmi Peksos & Draft AI) */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white p-4 sm:p-5 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-100 flex items-center justify-center text-sky-700 shrink-0">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">
                  Perencanaan Intervensi Terpadu (Dual-Frame Planning)
                </h3>
                <span className="hidden sm:inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  Human-in-the-Loop
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Rencana Resmi Pekerja Sosial berdampingan dengan Draft Usulan Asisten AI Gemini secara transparan.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleGenerateAIIntervensi}
              disabled={isDrafting}
              className="w-full sm:w-auto bg-linear-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition disabled:opacity-50"
            >
              {isDrafting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Merumuskan Draft AI...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>{fd.aiIntervensiTujuan ? 'Perbarui Draft AI' : 'Rumuskan Draft AI'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* 2 Frames Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 items-stretch">
          
          {/* FRAME 1: Rencana Pekerja Sosial (Resmi & Terverifikasi) */}
          <div className="bg-white rounded-xl border-2 border-sky-300 p-5 space-y-4 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              {/* Header Frame 1 */}
              <div className="flex items-start justify-between gap-3 border-b border-sky-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-sky-600 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-extrabold text-slate-900">Frame 1: Rencana Pekerja Sosial</h4>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
                        Dokumen Resmi
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Rencana casework resmi yang ditandatangani dan dicetak ke laporan rekam medis sosial.
                    </p>
                  </div>
                </div>

                {fd.intervensiTujuan && fd.intervensiStrategi ? (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-200 shrink-0">
                    <CheckCircle className="w-3 h-3 text-emerald-600" />
                    Terisi
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-1 rounded-md border border-amber-200 shrink-0">
                    <FileEdit className="w-3 h-3 text-amber-600" />
                    Draft Peksos
                  </span>
                )}
              </div>

              {/* Form Input Peksos */}
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Target className="w-3.5 h-3.5 text-sky-600" />
                      <span>Tujuan Intervensi (Jangka Pendek & SMART)</span>
                    </label>
                    <span className="text-[10px] text-slate-400 font-medium">Resmi</span>
                  </div>
                  <textarea
                    rows={4}
                    value={fd.intervensiTujuan || ''}
                    onChange={(e) => onChangeField('intervensiTujuan', e.target.value)}
                    className="w-full rounded-lg border border-slate-300 p-3 text-xs leading-relaxed focus:ring-2 focus:ring-sky-500 text-slate-800 bg-white"
                    placeholder="Tuliskan tujuan spesifik terukur bagi klien (misal: penguatan regulasi emosi, capaian vokasional bengkel otomotif, pemulihan komunikasi dengan keluarga)..."
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Shield className="w-3.5 h-3.5 text-sky-600" />
                      <span>Strategi, Metode & Pendekatan Pelayanan Sosial</span>
                    </label>
                    <span className="text-[10px] text-slate-400 font-medium">Resmi</span>
                  </div>
                  <textarea
                    rows={5}
                    value={fd.intervensiStrategi || ''}
                    onChange={(e) => onChangeField('intervensiStrategi', e.target.value)}
                    className="w-full rounded-lg border border-slate-300 p-3 text-xs leading-relaxed focus:ring-2 focus:ring-sky-500 text-slate-800 bg-white"
                    placeholder="Tuliskan metode pelayanan (misal: Cognitive Behavioral Casework, Group Work asrama, konseling keluarga berkala, bimbingan kedisiplinan dan spiritual)..."
                  />
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
              <span className="flex items-center gap-1.5 font-medium text-sky-800">
                <Check className="w-3.5 h-3.5 text-sky-600" />
                Dicetak pada Laporan Kasus Resmi (PDF/Word)
              </span>
              <span className="text-[10px] font-mono text-slate-400">Peksos: {peksosName || 'Penanggung Jawab'}</span>
            </div>
          </div>

          {/* FRAME 2: Draft Rekomendasi Intervensi AI (Gemini Assistant) */}
          <div className="bg-linear-to-b from-purple-50/50 via-white to-indigo-50/30 rounded-xl border-2 border-purple-300 p-5 space-y-4 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              {/* Header Frame 2 */}
              <div className="flex items-start justify-between gap-3 border-b border-purple-200 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-linear-to-br from-purple-600 to-indigo-600 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                    <Sparkles className="w-4 h-4 text-amber-300" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-extrabold text-purple-950">Frame 2: Draft Rekomendasi AI</h4>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
                        Gemini Co-Pilot
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Usulan otomatis berbasis asesmen bio-psiko-sosio-spiritual & kekuatan klien.
                    </p>
                  </div>
                </div>

                {fd.aiIntervensiGeneratedAt && (
                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-purple-700 bg-purple-100/80 px-2 py-0.5 rounded border border-purple-200 font-mono block">
                      {fd.aiIntervensiGeneratedAt}
                    </span>
                  </div>
                )}
              </div>

              {/* Content Frame 2 */}
              {fd.aiIntervensiTujuan || fd.aiIntervensiStrategi ? (
                <div className="space-y-4">
                  
                  {/* Draft Tujuan AI */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-purple-950 flex items-center gap-1.5">
                        <Target className="w-3.5 h-3.5 text-purple-600" />
                        <span>Rekomendasi Tujuan SMART (AI)</span>
                      </label>
                      <button
                        type="button"
                        onClick={handleApplyTujuanOnly}
                        className="text-[11px] font-bold text-purple-700 hover:text-purple-900 bg-purple-100 hover:bg-purple-200 px-2.5 py-1 rounded-md flex items-center gap-1 transition"
                        title="Salin tujuan ini ke Frame Pekerja Sosial"
                      >
                        <ArrowLeft className="w-3 h-3 hidden lg:inline" />
                        <span>Salin ke Peksos</span>
                      </button>
                    </div>
                    <textarea
                      rows={4}
                      value={fd.aiIntervensiTujuan || ''}
                      onChange={(e) => onChangeField('aiIntervensiTujuan', e.target.value)}
                      className="w-full rounded-lg border border-purple-200 bg-purple-50/40 p-3 text-xs leading-relaxed focus:ring-2 focus:ring-purple-500 text-slate-800"
                      placeholder="Draft rekomendasi tujuan intervensi AI..."
                    />
                  </div>

                  {/* Draft Strategi AI */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-purple-950 flex items-center gap-1.5">
                        <Lightbulb className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Rekomendasi Strategi & Pendekatan (AI)</span>
                      </label>
                      <button
                        type="button"
                        onClick={handleApplyStrategiOnly}
                        className="text-[11px] font-bold text-indigo-700 hover:text-indigo-900 bg-indigo-100 hover:bg-indigo-200 px-2.5 py-1 rounded-md flex items-center gap-1 transition"
                        title="Salin strategi ini ke Frame Pekerja Sosial"
                      >
                        <ArrowLeft className="w-3 h-3 hidden lg:inline" />
                        <span>Salin ke Peksos</span>
                      </button>
                    </div>
                    <textarea
                      rows={5}
                      value={fd.aiIntervensiStrategi || ''}
                      onChange={(e) => onChangeField('aiIntervensiStrategi', e.target.value)}
                      className="w-full rounded-lg border border-purple-200 bg-purple-50/40 p-3 text-xs leading-relaxed focus:ring-2 focus:ring-purple-500 text-slate-800"
                      placeholder="Draft rekomendasi strategi & metode intervensi AI..."
                    />
                  </div>

                  {/* Usulan Indikator AI */}
                  {fd.aiIntervensiIndikator && fd.aiIntervensiIndikator.length > 0 && (
                    <div className="bg-white/90 p-3 rounded-lg border border-purple-200/80 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-extrabold text-purple-950 flex items-center gap-1.5">
                          <CheckCircle className="w-3.5 h-3.5 text-purple-600" />
                          Usulan Indikator Capaian Terukur:
                        </span>
                        <span className="text-[10px] text-purple-700 font-mono">
                          {fd.aiIntervensiIndikator.length} Indikator
                        </span>
                      </div>
                      <ul className="space-y-1.5">
                        {fd.aiIntervensiIndikator.map((ind, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-[11px] text-slate-700 leading-snug">
                            <span className="w-4 h-4 rounded-full bg-purple-100 text-purple-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                            <span>{ind}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Action Buttons: Simpan Draft AI & Terapkan Seluruh Draft */}
                  <div className="pt-2 flex flex-col sm:flex-row items-center gap-2.5">
                    <button
                      type="button"
                      onClick={handleSaveAIDraft}
                      disabled={isSavingDraft}
                      className={`w-full sm:w-1/2 py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition shadow-2xs ${
                        savedSuccess
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                          : 'bg-white hover:bg-purple-50 text-purple-800 border-purple-300 hover:border-purple-400'
                      } disabled:opacity-50`}
                      title="Simpan permanen draft rekomendasi AI ini ke data klien agar tidak hilang saat membuka kembali aplikasi"
                    >
                      {isSavingDraft ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin text-purple-600" />
                          <span>Menyimpan Draft AI...</span>
                        </>
                      ) : savedSuccess ? (
                        <>
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                          <span>Draft AI Tersimpan!</span>
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4 text-purple-600" />
                          <span>Simpan Draft AI</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={handleApplyAllAIDraft}
                      className="w-full sm:w-1/2 bg-linear-to-r from-purple-700 to-indigo-700 hover:from-purple-800 hover:to-indigo-800 text-white font-bold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition"
                      title="Salin seluruh usulan tujuan dan strategi rekomendasi AI ke Rencana Resmi Pekerja Sosial"
                    >
                      <CheckCheck className="w-4 h-4 text-emerald-300" />
                      <span>Terapkan ke Rencana Peksos</span>
                    </button>
                  </div>
                </div>
              ) : (
                /* Empty State Frame 2 */
                <div className="p-8 text-center space-y-3 bg-white/70 rounded-xl border border-dashed border-purple-200 my-2">
                  <div className="w-12 h-12 mx-auto rounded-full bg-purple-100 text-purple-600 flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-purple-600" />
                  </div>
                  <div className="space-y-1">
                    <h5 className="text-xs font-bold text-purple-950">Draft Rekomendasi AI Belum Dirumuskan</h5>
                    <p className="text-[11px] text-slate-600 max-w-sm mx-auto leading-relaxed">
                      Klik tombol di bawah agar Gemini AI menganalisis data kronologi, risiko, dan psikologis klien guna merumuskan rekomendasi tujuan SMART dan strategi intervensi berbasis kekuatan klien.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleGenerateAIIntervensi}
                    disabled={isDrafting}
                    className="bg-purple-600 hover:bg-purple-700 text-white font-bold px-4 py-2 rounded-lg text-xs inline-flex items-center gap-2 shadow-xs transition disabled:opacity-50"
                  >
                    {isDrafting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Menganalisis & Merumuskan...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-amber-300" />
                        <span>Rumuskan Rekomendasi AI Sekarang</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-purple-100 flex items-center justify-between text-[11px] text-purple-800">
              <span className="flex items-center gap-1.5 font-medium">
                <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                Asisten AI Gemini — Co-Pilot Pendukung Peksos
              </span>
              <span className="text-[10px] text-purple-600 italic">Human-in-the-loop</span>
            </div>
          </div>

        </div>
      </div>

      {/* 2. Log Pelaksanaan & SOAP Multidisiplin */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-5 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-sky-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Log Pelaksanaan & Catatan Layanan Terintegrasi
              </h3>
              <p className="text-xs text-slate-500">
                Format SOAP (Subjective, Objective, Assessment, Plan) & Kolaborasi Multidisiplin Balai.
              </p>
            </div>
          </div>

          {/* Mode Toggle Switch */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold shrink-0">
            <button
              type="button"
              onClick={() => setLogMode('soap')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                logMode === 'soap'
                  ? 'bg-white text-indigo-700 shadow-2xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-indigo-600" />
              <span>Format SOAP Multidisiplin</span>
            </button>
            <button
              type="button"
              onClick={() => setLogMode('standard')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                logMode === 'standard'
                  ? 'bg-white text-sky-700 shadow-2xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-sky-600" />
              <span>Format Ringkas</span>
            </button>
          </div>
        </div>

        {/* Form Tambah Log */}
        <form onSubmit={handleAddLogSubmit} className="bg-linear-to-br from-slate-50 to-indigo-50/30 p-4 sm:p-5 rounded-xl border border-indigo-200/80 space-y-4">
          
          {/* Baris Meta: Tanggal & Peran Pelaksana */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal Sesi Layanan</label>
              <input
                type="date"
                value={logTanggal}
                onChange={(e) => setLogTanggal(e.target.value)}
                className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-xs bg-white focus:ring-2 focus:ring-indigo-500 text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Peran Multidisiplin Pelaksana
              </label>
              <select
                value={peranPelaksana}
                onChange={(e) => setPeranPelaksana(e.target.value as MultidisciplinaryRole)}
                className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-xs font-bold bg-white focus:ring-2 focus:ring-indigo-500 text-slate-800"
              >
                <option value="Pekerja Sosial">Pekerja Sosial (Peksos)</option>
                <option value="Instruktur Vokasi">Instruktur Vokasi (Bengkel / Kriya)</option>
                <option value="Pengasuh Asrama">Pengasuh Asrama (Bimbingan Fisik/Disiplin)</option>
                <option value="Tenaga Medis">Tenaga Medis Balai (Perawat / Dokter)</option>
                <option value="Psikolog Klinis">Psikolog Klinis</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Judul / Sesi Layanan (Opsional)</label>
              <input
                type="text"
                list="layanan-suggestions"
                value={logDeskripsi}
                onChange={(e) => setLogDeskripsi(e.target.value)}
                placeholder="Contoh: Bimbingan Karir / Evaluasi Emosi / Praktik Mesin"
                className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-xs bg-white focus:ring-2 focus:ring-indigo-500 text-slate-800"
              />
              <datalist id="layanan-suggestions">
                <option value="Konseling Individu (Casework)" />
                <option value="Konseling Keluarga / Home Visit" />
                <option value="Bimbingan Sosial Kelompok (Group Work)" />
                <option value="Terapi Psikososial / Regulasi Emosi" />
                <option value="Praktik Keterampilan Kerja / Vokasional" />
                <option value="Pemeriksaan Kesehatan Berkala & Antropometri" />
                <option value="Evaluasi Perkembangan Triwulan" />
                <option value="Rujukan Medis / Psikolog" />
              </datalist>
            </div>
          </div>

          {/* Conditional Content based on logMode */}
          {logMode === 'soap' ? (
            <div className="space-y-3 pt-1">
              <div className="flex items-center gap-2 text-xs font-bold text-indigo-900 border-b border-indigo-100 pb-1.5">
                <Layers className="w-3.5 h-3.5 text-indigo-600" />
                <span>Instrumen Catatan Perkembangan SOAP (Standar Rekam Klinis Sosial)</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* S: Subjective */}
                <div className="bg-white p-3 rounded-xl border border-sky-200 space-y-1">
                  <label className="block text-[11px] font-extrabold text-sky-900 flex items-center justify-between">
                    <span>S (Subjective) - Keluhan / Ungkapan Klien & Wali</span>
                    <span className="text-[10px] text-sky-600 font-normal">Apa yang dikatakan anak/wali</span>
                  </label>
                  <textarea
                    rows={2}
                    value={soapSubjective}
                    onChange={(e) => setSoapSubjective(e.target.value)}
                    placeholder="Contoh: Anak menyampaikan merasa lebih nyaman di asrama namun rindu ibu; mengeluh pusing ringan kemarin malam..."
                    className="w-full rounded-lg border border-slate-200 p-2 text-xs text-slate-800 focus:ring-2 focus:ring-sky-500"
                  />
                </div>

                {/* O: Objective */}
                <div className="bg-white p-3 rounded-xl border border-indigo-200 space-y-1">
                  <label className="block text-[11px] font-extrabold text-indigo-900 flex items-center justify-between">
                    <span>O (Objective) - Observasi Terukur & Perilaku Konkret</span>
                    <span className="text-[10px] text-indigo-600 font-normal">Fakta teramati, presensi, data fisik</span>
                  </label>
                  <textarea
                    rows={2}
                    value={soapObjective}
                    onChange={(e) => setSoapObjective(e.target.value)}
                    placeholder="Contoh: Kontak mata stabil, kehadiran bengkel 100%, mampu membongkar 2 unit dinamo dengan presisi, tidak ada tanda luka baru..."
                    className="w-full rounded-lg border border-slate-200 p-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                {/* A: Assessment */}
                <div className="bg-white p-3 rounded-xl border border-emerald-200 space-y-1">
                  <label className="block text-[11px] font-extrabold text-emerald-900 flex items-center justify-between">
                    <span>A (Assessment) - Analisis Klinis & Dinamika Sosial</span>
                    <span className="text-[10px] text-emerald-600 font-normal">Evaluasi perkembangan & kapasitas</span>
                  </label>
                  <textarea
                    rows={2}
                    value={soapAssessment}
                    onChange={(e) => setSoapAssessment(e.target.value)}
                    placeholder="Contoh: Resiliensi dan regulasi emosi meningkat (karakter Waringkas berkembang baik); motivasi kemandirian kejuruan tinggi..."
                    className="w-full rounded-lg border border-slate-200 p-2 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* P: Plan */}
                <div className="bg-white p-3 rounded-xl border border-purple-200 space-y-1">
                  <label className="block text-[11px] font-extrabold text-purple-900 flex items-center justify-between">
                    <span>P (Plan) - Rencana Tindak Lanjut & Tugas Mandiri</span>
                    <span className="text-[10px] text-purple-600 font-normal">Langkah intervensi berikutnya</span>
                  </label>
                  <textarea
                    rows={2}
                    value={soapPlan}
                    onChange={(e) => setSoapPlan(e.target.value)}
                    placeholder="Contoh: Libatkan anak sebagai asisten instruktur bengkel; jadwalkan mediasi telepon dengan ibu pekan depan..."
                    className="w-full rounded-lg border border-slate-200 p-2 text-xs text-slate-800 focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Tindakan / Layanan Sosial Diberikan
                </label>
                <input
                  type="text"
                  value={logDeskripsi}
                  onChange={(e) => setLogDeskripsi(e.target.value)}
                  placeholder="Contoh: Konseling Individu penguatan motivasi sekolah dan adaptasi teman sebaya..."
                  className="w-full rounded-lg border border-slate-300 py-2 px-3 text-xs bg-white focus:ring-2 focus:ring-sky-500 text-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Indikator Respon / Capaian Klien
                </label>
                <input
                  type="text"
                  value={logIndikator}
                  onChange={(e) => setLogIndikator(e.target.value)}
                  placeholder="Contoh: Anak kooperatif, mampu mengidentifikasi pemicu cemas, komitmen hadir tepat waktu..."
                  className="w-full rounded-lg border border-slate-300 py-2 px-3 text-xs bg-white focus:ring-2 focus:ring-sky-500 text-slate-800"
                />
              </div>
            </div>
          )}

          {/* Submit Button */}
          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md transition"
            >
              <Plus className="w-4 h-4" /> 
              <span>Simpan Catatan Layanan ({peranPelaksana})</span>
            </button>
          </div>
        </form>

        {/* Tabel / Daftar Log Intervensi Terintegrasi */}
        <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
          {client.pelaksanaanIntervensi && client.pelaksanaanIntervensi.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-[11px] text-slate-700 uppercase font-bold">
                  <tr>
                    <th className="py-2.5 px-3 w-28">Tanggal</th>
                    <th className="py-2.5 px-3 w-40">Pelaksana</th>
                    <th className="py-2.5 px-3">Tindakan / Catatan SOAP</th>
                    <th className="py-2.5 px-3 w-48">Indikator Capaian</th>
                    <th className="py-2.5 px-3 w-20 text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {client.pelaksanaanIntervensi.map((item) => {
                    const badge = getRoleBadge(item.peranPelaksana);
                    const RoleIcon = badge.icon;
                    const isExpanded = !!expandedLogIds[item.id];
                    const hasSoapData = item.isSOAP || item.subjective || item.objective || item.assessment || item.plan;

                    return (
                      <React.Fragment key={item.id}>
                        <tr className="hover:bg-slate-50/60 transition">
                          <td className="py-3 px-3 font-semibold text-xs text-sky-800 whitespace-nowrap align-top">
                            <span className="bg-sky-50 px-2 py-0.5 rounded border border-sky-200 font-mono text-[11px]">
                              {item.tanggal}
                            </span>
                          </td>
                          <td className="py-3 px-3 align-top whitespace-nowrap">
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${badge.color}`}>
                              <RoleIcon className="w-3 h-3" />
                              <span>{badge.label}</span>
                            </span>
                          </td>
                          <td className="py-3 px-3 align-top">
                            <div className="font-bold text-slate-900 leading-snug">
                              {item.deskripsi}
                            </div>
                            {hasSoapData && (
                              <button
                                type="button"
                                onClick={() => toggleExpand(item.id)}
                                className="mt-1.5 text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                              >
                                {isExpanded ? (
                                  <>
                                    <ChevronUp className="w-3.5 h-3.5" /> Sembunyikan Rincian SOAP
                                  </>
                                ) : (
                                  <>
                                    <ChevronDown className="w-3.5 h-3.5" /> Lihat Rincian SOAP (S-O-A-P)
                                  </>
                                )}
                              </button>
                            )}
                          </td>
                          <td className="py-3 px-3 text-slate-600 align-top leading-relaxed text-[11px]">
                            {item.indikator}
                          </td>
                          <td className="py-3 px-3 text-center align-top">
                            <button
                              type="button"
                              onClick={() => onRemoveIntervensiLog(item.id)}
                              className="text-rose-500 hover:text-rose-700 p-1 rounded hover:bg-rose-50 transition"
                              title="Hapus Log"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>

                        {/* Expanded SOAP Drawer */}
                        {isExpanded && hasSoapData && (
                          <tr className="bg-indigo-50/40">
                            <td colSpan={5} className="p-4 border-t border-indigo-100">
                              <div className="bg-white rounded-xl border border-indigo-200 p-3.5 space-y-3 shadow-2xs">
                                <div className="flex items-center justify-between border-b border-indigo-100 pb-2">
                                  <span className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                                    <Layers className="w-4 h-4 text-indigo-600" />
                                    Rekam Medis SOAP Terpadu — {item.tanggal} ({badge.label})
                                  </span>
                                  <span className="text-[10px] text-slate-400 font-mono">ID: {item.id}</span>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                                  {/* S */}
                                  <div className="bg-sky-50/60 p-2.5 rounded-lg border border-sky-200">
                                    <strong className="text-[11px] text-sky-900 block mb-1">
                                      S (Subjective) - Pernyataan Klien/Wali:
                                    </strong>
                                    <p className="text-slate-700 leading-relaxed italic">
                                      {item.subjective || '-'}
                                    </p>
                                  </div>

                                  {/* O */}
                                  <div className="bg-indigo-50/60 p-2.5 rounded-lg border border-indigo-200">
                                    <strong className="text-[11px] text-indigo-900 block mb-1">
                                      O (Objective) - Observasi / Data Terukur:
                                    </strong>
                                    <p className="text-slate-700 leading-relaxed">
                                      {item.objective || '-'}
                                    </p>
                                  </div>

                                  {/* A */}
                                  <div className="bg-emerald-50/60 p-2.5 rounded-lg border border-emerald-200">
                                    <strong className="text-[11px] text-emerald-900 block mb-1">
                                      A (Assessment) - Analisis Klinis Sosial:
                                    </strong>
                                    <p className="text-slate-700 leading-relaxed">
                                      {item.assessment || '-'}
                                    </p>
                                  </div>

                                  {/* P */}
                                  <div className="bg-purple-50/60 p-2.5 rounded-lg border border-purple-200">
                                    <strong className="text-[11px] text-purple-900 block mb-1">
                                      P (Plan) - Tindak Lanjut & Rujukan:
                                    </strong>
                                    <p className="text-slate-700 leading-relaxed">
                                      {item.plan || '-'}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-8 text-center text-xs text-slate-500 italic bg-white">
              Belum ada log layanan intervensi yang dicatat. Tambahkan log atau catatan SOAP di formulir atas.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

