import React, { useState } from 'react';
import { 
  User, 
  GraduationCap, 
  Home, 
  HeartPulse, 
  Plus, 
  Trash2, 
  Scale, 
  Settings2,
  Calendar,
  Phone,
  PhoneOff,
  CheckCircle2,
  AlertCircle,
  Info,
  CreditCard,
  Users,
  UserCheck
} from 'lucide-react';
import { Client } from '../../types';
import { JAWA_BARAT_REGIONS, MOCK_KECAMATAN, MOCK_DESA } from '../../data/defaultData';

interface TabProfilProps {
  client: Client;
  jurusanList: string[];
  allAngkatanList: string[];
  onChangeField: (key: string, value: any) => void;
  onAddPenyakit: (namaPenyakit: string) => void;
  onRemovePenyakit: (index: number) => void;
  onOpenManageJurusan: () => void;
}

export const TabProfil: React.FC<TabProfilProps> = ({
  client,
  jurusanList,
  allAngkatanList,
  onChangeField,
  onAddPenyakit,
  onRemovePenyakit,
  onOpenManageJurusan,
}) => {
  const fd = client.formData;
  const [penyakitInput, setPenyakitInput] = useState('');

  const calculateAge = (dateString: string) => {
    if (!dateString) return 0;
    const today = new Date();
    const birthDate = new Date(dateString);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age >= 0 ? age : 0;
  };

  const handleBirthDateChange = (val: string) => {
    onChangeField('tanggalLahir', val);
    const age = calculateAge(val);
    onChangeField('umur', age);
  };

  const handleAddPenyakitSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (penyakitInput.trim()) {
      onAddPenyakit(penyakitInput.trim());
      setPenyakitInput('');
    }
  };

  const currentKecamatanOptions = fd.kabupatenKota ? (MOCK_KECAMATAN[fd.kabupatenKota] || []) : [];
  const currentDesaOptions = fd.kecamatan ? (MOCK_DESA[fd.kecamatan] || []) : [];

  return (
    <div className="space-y-6">
      {/* Panduan Etik Banner */}
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-md shadow-xs no-print">
        <div className="flex items-start">
          <Scale className="w-5 h-5 text-indigo-600 mt-0.5 shrink-0" />
          <div className="ml-3">
            <h3 className="text-sm font-bold text-indigo-900">Panduan Etik: Engagement & Pengumpulan Data Klien</h3>
            <p className="text-xs text-indigo-700 mt-1 leading-relaxed">
              <strong>Kerahasiaan (Confidentiality) & Penerimaan (Acceptance):</strong> Jaga kerahasiaan identitas dan data sensitif klien. Sambut klien dengan sikap non-judgmental untuk membangun hubungan saling percaya <i>(rapport building)</i>.
            </p>
          </div>
        </div>
      </div>

      {/* 1. Biodata Dasar */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="bg-slate-50 px-5 py-3 border-b border-slate-200 flex items-center gap-2">
          <User className="w-4 h-4 text-sky-600" />
          <h3 className="text-sm font-bold text-slate-900">1. Biodata Dasar Klien</h3>
        </div>
        <div className="p-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Lengkap</label>
            <input
              type="text"
              value={client.nama}
              onChange={(e) => onChangeField('nama', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500"
              placeholder="Nama lengkap anak"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Tempat Lahir</label>
            <input
              type="text"
              value={fd.tempatLahir || ''}
              onChange={(e) => onChangeField('tempatLahir', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500"
              placeholder="Kota/Kabupaten lahir"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Tanggal Lahir</label>
            <input
              type="date"
              value={fd.tanggalLahir || ''}
              onChange={(e) => handleBirthDateChange(e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Umur (Tahun)</label>
            <input
              type="number"
              readOnly
              value={client.umur || ''}
              className="w-full rounded-lg border border-slate-200 bg-slate-100 py-1.5 px-3 text-sm text-slate-600 cursor-not-allowed font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Jenis Kelamin</label>
            <select
              value={client.gender}
              onChange={(e) => onChangeField('gender', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500 bg-white"
            >
              <option value="Laki-laki">Laki-laki</option>
              <option value="Perempuan">Perempuan</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Agama</label>
            <select
              value={fd.agama || ''}
              onChange={(e) => onChangeField('agama', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500 bg-white"
            >
              <option value="">- Pilih Agama -</option>
              <option value="Islam">Islam</option>
              <option value="Kristen Protestan">Kristen Protestan</option>
              <option value="Katolik">Katolik</option>
              <option value="Hindu">Hindu</option>
              <option value="Buddha">Buddha</option>
              <option value="Konghucu">Konghucu</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-sky-800 mb-1">Kabupaten/Kota (Jawa Barat)</label>
            <select
              value={fd.kabupatenKota || ''}
              onChange={(e) => {
                onChangeField('kabupatenKota', e.target.value);
                onChangeField('kecamatan', '');
                onChangeField('desa', '');
              }}
              className="w-full rounded-lg border border-sky-300 py-1.5 px-3 text-sm font-semibold text-sky-950 bg-sky-50/50 focus:ring-2 focus:ring-sky-500"
            >
              <option value="">- Pilih Kabupaten/Kota -</option>
              {JAWA_BARAT_REGIONS.map((reg) => (
                <option key={reg} value={reg}>{reg}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-sky-800 mb-1">Kecamatan</label>
            <input
              type="text"
              list="kecamatan-datalist"
              value={fd.kecamatan || ''}
              onChange={(e) => onChangeField('kecamatan', e.target.value)}
              className="w-full rounded-lg border border-sky-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500"
              placeholder="Ketik/Pilih Kecamatan"
            />
            <datalist id="kecamatan-datalist">
              {currentKecamatanOptions.map((kec) => (
                <option key={kec} value={kec} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-bold text-sky-800 mb-1">Desa/Kelurahan</label>
            <input
              type="text"
              list="desa-datalist"
              value={fd.desa || ''}
              onChange={(e) => onChangeField('desa', e.target.value)}
              className="w-full rounded-lg border border-sky-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500"
              placeholder="Ketik/Pilih Desa/Kelurahan"
            />
            <datalist id="desa-datalist">
              {currentDesaOptions.map((des) => (
                <option key={des} value={des} />
              ))}
            </datalist>
          </div>

          <div className="md:col-span-2 lg:col-span-3">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Alamat Lengkap / Jalan & RT/RW</label>
            <textarea
              rows={2}
              value={fd.alamat || ''}
              onChange={(e) => onChangeField('alamat', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500"
              placeholder="Kampung / Jalan, No. Rumah, RT/RW..."
            />
          </div>
        </div>

        {/* 2. Identitas & Pendidikan */}
        <div className="bg-slate-50 px-5 py-3 border-y border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-sky-600" />
            <h3 className="text-sm font-bold text-slate-900">2. Identitas Kependudukan & Pendidikan</h3>
          </div>
          <button
            type="button"
            onClick={onOpenManageJurusan}
            className="text-xs font-semibold text-sky-700 hover:text-sky-900 flex items-center gap-1"
          >
            <Settings2 className="w-3.5 h-3.5" /> Kelola Jurusan
          </button>
        </div>
        <div className="p-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Angkatan Masuk</label>
            <input
              type="text"
              list="angkatan-list-options"
              value={fd.angkatan || ''}
              onChange={(e) => onChangeField('angkatan', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm font-bold text-sky-800 focus:ring-2 focus:ring-sky-500"
              placeholder="Contoh: Angkatan I - 2026"
            />
            <datalist id="angkatan-list-options">
              {allAngkatanList.map((a) => (
                <option key={a} value={a} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Status Dokumen Identitas</label>
            <select
              value={fd.statusIdentitas || ''}
              onChange={(e) => onChangeField('statusIdentitas', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500 bg-white"
            >
              <option value="">- Pilih Status -</option>
              <option value="Memiliki KTP/KIA">Ada KTP / KIA Fisik</option>
              <option value="Memiliki NIK (Tanpa Kartu)">Ada NIK, Tanpa Kartu Fisik</option>
              <option value="Tanpa Identitas">Belum Ada NIK / Tanpa Identitas</option>
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-slate-700">
                Nomor Induk Kependudukan (NIK)
              </label>
              {(() => {
                const nik = (fd.noIdentitas || '').trim();
                if (/^[0-9]{16}$/.test(nik)) {
                  return (
                    <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" /> 16 Digit Valid
                    </span>
                  );
                }
                if (nik.toLowerCase().includes('proses') || nik.toLowerCase().includes('belum')) {
                  return (
                    <span className="text-[10px] text-sky-800 font-bold bg-sky-50 px-1.5 py-0.2 rounded border border-sky-200">
                      Advokasi Dukcapil
                    </span>
                  );
                }
                if (nik.length > 0) {
                  return (
                    <span className="text-[10px] text-amber-600 font-medium">
                      {nik.length}/16 digit
                    </span>
                  );
                }
                return null;
              })()}
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
                <CreditCard className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={fd.noIdentitas || ''}
                onChange={(e) => onChangeField('noIdentitas', e.target.value)}
                className="w-full rounded-lg border border-slate-300 py-1.5 pl-8 pr-3 text-xs sm:text-sm font-mono focus:ring-2 focus:ring-sky-500 bg-white"
                placeholder="16 digit NIK resmi"
                maxLength={30}
              />
            </div>
            <div className="mt-1 flex items-center justify-between text-[10px] text-slate-500">
              <span>Wajib 16 digit angka kependudukan</span>
              <button
                type="button"
                onClick={() => onChangeField('noIdentitas', 'Dalam Proses Pencatatan Dukcapil')}
                className="text-sky-700 hover:underline font-medium"
              >
                + Belum ada NIK
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Pendidikan Terakhir</label>
            <select
              value={fd.pendidikan || ''}
              onChange={(e) => onChangeField('pendidikan', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500 bg-white"
            >
              <option value="">- Pilih Pendidikan -</option>
              <option value="Tidak/Belum Pernah Sekolah">Tidak/Belum Pernah Sekolah</option>
              <option value="PAUD / TK">PAUD / TK</option>
              <option value="SD / Sederajat">SD / Sederajat</option>
              <option value="SMP / Sederajat">SMP / Sederajat</option>
              <option value="SMA / SMK / Sederajat">SMA / SMK / Sederajat</option>
              <option value="Tamat SMA / Lulus">Tamat SMA / Lulus</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-sky-800 mb-1">Jurusan Keterampilan Asrama</label>
            <select
              value={fd.jurusan || ''}
              onChange={(e) => onChangeField('jurusan', e.target.value)}
              className="w-full rounded-lg border border-sky-300 py-1.5 px-3 text-sm font-bold text-sky-950 bg-sky-50/50 focus:ring-2 focus:ring-sky-500"
            >
              <option value="">- Pilih Jurusan Keterampilan -</option>
              {jurusanList.map((j) => (
                <option key={j} value={j}>{j}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Riwayat Putus Sekolah?</label>
            <select
              value={fd.putusSekolah || ''}
              onChange={(e) => onChangeField('putusSekolah', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500 bg-white"
            >
              <option value="">- Pilih -</option>
              <option value="Tidak (Lancar)">Tidak (Lancar)</option>
              <option value="Ya, Pernah Tertinggal">Ya, Pernah Tertinggal</option>
              <option value="Ya, Sedang Putus Sekolah">Ya, Saat ini Putus Sekolah</option>
            </select>
          </div>

          <div className="md:col-span-2 lg:col-span-3">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Catatan Kondisi Pendidikan</label>
            <input
              type="text"
              value={fd.kondisiPendidikan || ''}
              onChange={(e) => onChangeField('kondisiPendidikan', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-sky-500"
              placeholder="Contoh: Berhenti kelas 2 SMP karena membantu orang tua, ingin kejar Paket B..."
            />
          </div>
        </div>

        {/* 3. Pengasuhan & Sosial Ekonomi Orang Tua / Wali */}
        <div className="bg-emerald-50/70 px-5 py-3 border-y border-emerald-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Home className="w-4 h-4 text-emerald-700" />
            <h3 className="text-sm font-bold text-emerald-950">3. Kondisi Pengasuhan, Orang Tua / Wali & Sosioekonomi</h3>
          </div>
          <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-100/90 px-2.5 py-0.5 rounded-full border border-emerald-300">
            {fd.tipePengasuh === 'Wali' ? 'Pengasuhan: Wali / Kerabat' : 'Pengasuhan: Orang Tua Kandung'}
          </span>
        </div>

        <div className="p-5 bg-emerald-50/10 space-y-5">
          {/* Toggle Segmented Control: Orang Tua Kandung vs Wali */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-2xs">
            <div>
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-600" />
                Status Pengasuh / Penanggung Jawab Anak
              </h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Pilih apakah saat ini anak tinggal bersama orang tua kandung atau di bawah pengasuhan wali / kerabat.
              </p>
            </div>

            <div className="inline-flex rounded-xl p-1 bg-slate-100 border border-slate-300 self-start sm:self-auto shrink-0">
              <button
                type="button"
                onClick={() => {
                  onChangeField('tipePengasuh', 'Orang Tua');
                  if (!fd.statusAyah) onChangeField('statusAyah', 'Masih Hidup');
                  if (!fd.statusIbu) onChangeField('statusIbu', 'Masih Hidup');
                }}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                  fd.tipePengasuh !== 'Wali'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Orang Tua Kandung</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onChangeField('tipePengasuh', 'Wali');
                  if (!fd.statusAyah) onChangeField('statusAyah', 'Tidak Diketahui');
                  if (!fd.statusIbu) onChangeField('statusIbu', 'Tidak Diketahui');
                }}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                  fd.tipePengasuh === 'Wali'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Wali / Kerabat</span>
              </button>
            </div>
          </div>

          {/* OPSI 1: JIKA TOGEL = ORANG TUA KANDUNG */}
          {fd.tipePengasuh !== 'Wali' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Kolom Ayah Kandung */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-sky-600" />
                    Data Ayah Kandung
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    fd.statusAyah === 'Meninggal Dunia'
                      ? 'bg-slate-100 text-slate-700 border-slate-300'
                      : fd.statusAyah?.includes('Tidak Diketahui')
                      ? 'bg-amber-50 text-amber-800 border-amber-300'
                      : 'bg-emerald-50 text-emerald-800 border-emerald-300'
                  }`}>
                    {fd.statusAyah || 'Masih Hidup'}
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nama Lengkap Ayah
                  </label>
                  <input
                    type="text"
                    value={fd.namaAyah || (fd.namaWali && !fd.namaIbu ? fd.namaWali : '')}
                    onChange={(e) => {
                      onChangeField('namaAyah', e.target.value);
                      if (!fd.namaWali || fd.namaWali === fd.namaAyah) {
                        onChangeField('namaWali', e.target.value);
                      }
                    }}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
                    placeholder="Nama Ayah Kandung (misal: Bpk. Ridwan)"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Status Keberadaan Ayah
                    </label>
                    <select
                      value={fd.statusAyah || 'Masih Hidup'}
                      onChange={(e) => onChangeField('statusAyah', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 py-1.5 px-2.5 text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 bg-white font-medium"
                    >
                      <option value="Masih Hidup">Masih Hidup</option>
                      <option value="Meninggal Dunia">Meninggal Dunia (Alm.)</option>
                      <option value="Tidak Diketahui / Terputus Kontak">Tidak Diketahui / Terputus</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Pekerjaan Ayah
                    </label>
                    <select
                      value={fd.pekerjaanAyah || fd.pekerjaanOrangTua || ''}
                      onChange={(e) => {
                        onChangeField('pekerjaanAyah', e.target.value);
                        onChangeField('pekerjaanOrangTua', e.target.value);
                      }}
                      className="w-full rounded-lg border border-slate-300 py-1.5 px-2.5 text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
                    >
                      <option value="">- Pilih Pekerjaan -</option>
                      <option value="Tidak Bekerja">Tidak Bekerja</option>
                      <option value="Buruh Harian / Kuli">Buruh Harian / Kuli</option>
                      <option value="Petani / Buruh Tani">Petani / Buruh Tani</option>
                      <option value="Wiraswasta / Pedagang">Wiraswasta / Pedagang</option>
                      <option value="Karyawan Swasta">Karyawan Swasta</option>
                      <option value="PNS / TNI / Polri">PNS / TNI / Polri</option>
                      <option value="Pekerja Informal">Pekerja Informal Lainnya</option>
                      <option value="Sudah Meninggal">-</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Kolom Ibu Kandung */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-rose-500" />
                    Data Ibu Kandung
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    fd.statusIbu === 'Meninggal Dunia'
                      ? 'bg-slate-100 text-slate-700 border-slate-300'
                      : fd.statusIbu?.includes('Tidak Diketahui')
                      ? 'bg-amber-50 text-amber-800 border-amber-300'
                      : 'bg-emerald-50 text-emerald-800 border-emerald-300'
                  }`}>
                    {fd.statusIbu || 'Masih Hidup'}
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nama Lengkap Ibu
                  </label>
                  <input
                    type="text"
                    value={fd.namaIbu || ''}
                    onChange={(e) => onChangeField('namaIbu', e.target.value)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
                    placeholder="Nama Ibu Kandung (misal: Ibu Maryam)"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Status Keberadaan Ibu
                    </label>
                    <select
                      value={fd.statusIbu || 'Masih Hidup'}
                      onChange={(e) => onChangeField('statusIbu', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 py-1.5 px-2.5 text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 bg-white font-medium"
                    >
                      <option value="Masih Hidup">Masih Hidup</option>
                      <option value="Meninggal Dunia">Meninggal Dunia (Almh.)</option>
                      <option value="Tidak Diketahui / Terputus Kontak">Tidak Diketahui / Terputus</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Pekerjaan Ibu
                    </label>
                    <select
                      value={fd.pekerjaanIbu || ''}
                      onChange={(e) => onChangeField('pekerjaanIbu', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 py-1.5 px-2.5 text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
                    >
                      <option value="">- Pilih Pekerjaan -</option>
                      <option value="Ibu Rumah Tangga">Ibu Rumah Tangga</option>
                      <option value="Tidak Bekerja">Tidak Bekerja</option>
                      <option value="Buruh Harian / Cuci">Buruh Harian / Cuci</option>
                      <option value="Petani / Buruh Tani">Petani / Buruh Tani</option>
                      <option value="Wiraswasta / Pedagang">Wiraswasta / Pedagang</option>
                      <option value="Karyawan Swasta">Karyawan Swasta</option>
                      <option value="Pekerja Informal">Pekerja Informal Lainnya</option>
                      <option value="Sudah Meninggal">-</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* OPSI 2: JIKA TOGEL = WALI / KERABAT */
            <div className="space-y-4">
              {/* Form Wali */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
                  <UserCheck className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                    Identitas Wali / Pengasuh Alternatif
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Nama Lengkap Wali <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={fd.namaWali || ''}
                      onChange={(e) => onChangeField('namaWali', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-emerald-500 bg-white font-medium"
                      placeholder="Nama wali (misal: H. Sukarna)"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Hubungan dengan Anak <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={fd.hubunganWali || ''}
                      onChange={(e) => onChangeField('hubunganWali', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 py-1.5 px-2.5 text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 bg-white font-medium"
                    >
                      <option value="">- Pilih Hubungan -</option>
                      <option value="Kakek / Nenek">Kakek / Nenek</option>
                      <option value="Paman / Bibi (Om / Tante)">Paman / Bibi (Om / Tante)</option>
                      <option value="Kakak Kandung">Kakak Kandung</option>
                      <option value="Orang Tua Asuh (Foster Parent)">Orang Tua Asuh (Foster Parent)</option>
                      <option value="Tetangga / Tokoh Masyarakat">Tetangga / Tokoh Masyarakat</option>
                      <option value="Pengurus LKSA / Panti Asuhan">Pengurus LKSA / Panti Asuhan</option>
                      <option value="Pamong Desa / Petugas Sosial">Pamong Desa / Petugas Sosial</option>
                      <option value="Lainnya">Lainnya</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Alasan Tinggal Bersama Wali <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={fd.alasanDenganWali || ''}
                      onChange={(e) => onChangeField('alasanDenganWali', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 py-1.5 px-2.5 text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 bg-white font-medium"
                    >
                      <option value="">- Pilih Alasan -</option>
                      <option value="Yatim Piatu (Kedua Orang Tua Meninggal)">Yatim Piatu (Kedua Orang Tua Meninggal)</option>
                      <option value="Yatim (Ayah Meninggal Dunia)">Yatim (Ayah Meninggal Dunia)</option>
                      <option value="Piatu (Ibu Meninggal Dunia)">Piatu (Ibu Meninggal Dunia)</option>
                      <option value="Orang Tua Merantau / Bekerja Luar Daerah/LN">Orang Tua Merantau / Bekerja Luar Daerah/LN</option>
                      <option value="Perceraian Orang Tua / Menikah Lagi">Perceraian Orang Tua / Menikah Lagi</option>
                      <option value="Ditelantarkan / Lepas Pengasuhan">Ditelantarkan / Lepas Pengasuhan</option>
                      <option value="Orang Tua Sakit Menahun / Disabilitas Berat">Orang Tua Sakit Menahun / Disabilitas Berat</option>
                      <option value="Kemiskinan Ekstrem Keluarga Inti">Kemiskinan Ekstrem Keluarga Inti</option>
                      <option value="Lainnya">Lainnya</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Pekerjaan Wali</label>
                    <select
                      value={fd.pekerjaanOrangTua || ''}
                      onChange={(e) => onChangeField('pekerjaanOrangTua', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 py-1.5 px-2.5 text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
                    >
                      <option value="">- Pilih Pekerjaan -</option>
                      <option value="Tidak Bekerja">Tidak Bekerja</option>
                      <option value="Ibu Rumah Tangga">Ibu Rumah Tangga</option>
                      <option value="Buruh Harian / Kuli">Buruh Harian / Kuli</option>
                      <option value="Petani / Buruh Tani">Petani / Buruh Tani</option>
                      <option value="Wiraswasta / Pedagang">Wiraswasta / Pedagang</option>
                      <option value="Karyawan Swasta">Karyawan Swasta</option>
                      <option value="Pekerja Informal">Pekerja Informal Lainnya</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Tetap Ada Status Keberadaan Orang Tua Kandung (Meskipun ada Wali) */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b border-slate-100 pb-2">
                  <span className="text-xs font-bold text-slate-900 uppercase flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-sky-700" />
                    Status Keberadaan Orang Tua Kandung (Kondisi Biologis)
                  </span>
                  <span className="text-[11px] text-slate-500 italic">
                    Wajib dicatat agar peksos mengetahui status ayah & ibu kandung
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Ayah Kandung */}
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                        <User className="w-3 h-3 text-sky-600" /> Ayah Kandung
                      </label>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        fd.statusAyah === 'Meninggal Dunia'
                          ? 'bg-slate-200 text-slate-700 border-slate-300'
                          : fd.statusAyah?.includes('Tidak Diketahui')
                          ? 'bg-amber-100 text-amber-800 border-amber-300'
                          : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      }`}>
                        {fd.statusAyah || 'Tidak Diketahui'}
                      </span>
                    </div>

                    <input
                      type="text"
                      value={fd.namaAyah || ''}
                      onChange={(e) => onChangeField('namaAyah', e.target.value)}
                      className="w-full rounded border border-slate-300 py-1.5 px-2.5 text-xs focus:ring-1 focus:ring-sky-500 bg-white"
                      placeholder="Nama Ayah Kandung (atau 'Alm. ...')"
                    />

                    <select
                      value={fd.statusAyah || 'Tidak Diketahui'}
                      onChange={(e) => onChangeField('statusAyah', e.target.value)}
                      className="w-full rounded border border-slate-300 py-1.5 px-2.5 text-xs focus:ring-1 focus:ring-sky-500 bg-white font-medium"
                    >
                      <option value="Masih Hidup">Masih Hidup</option>
                      <option value="Meninggal Dunia">Meninggal Dunia (Almarhum)</option>
                      <option value="Tidak Diketahui / Terputus Kontak">Tidak Diketahui / Terputus Kontak</option>
                    </select>
                  </div>

                  {/* Ibu Kandung */}
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                        <User className="w-3 h-3 text-rose-500" /> Ibu Kandung
                      </label>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        fd.statusIbu === 'Meninggal Dunia'
                          ? 'bg-slate-200 text-slate-700 border-slate-300'
                          : fd.statusIbu?.includes('Tidak Diketahui')
                          ? 'bg-amber-100 text-amber-800 border-amber-300'
                          : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      }`}>
                        {fd.statusIbu || 'Tidak Diketahui'}
                      </span>
                    </div>

                    <input
                      type="text"
                      value={fd.namaIbu || ''}
                      onChange={(e) => onChangeField('namaIbu', e.target.value)}
                      className="w-full rounded border border-slate-300 py-1.5 px-2.5 text-xs focus:ring-1 focus:ring-sky-500 bg-white"
                      placeholder="Nama Ibu Kandung (atau 'Almh. ...')"
                    />

                    <select
                      value={fd.statusIbu || 'Tidak Diketahui'}
                      onChange={(e) => onChangeField('statusIbu', e.target.value)}
                      className="w-full rounded border border-slate-300 py-1.5 px-2.5 text-xs focus:ring-1 focus:ring-sky-500 bg-white font-medium"
                    >
                      <option value="Masih Hidup">Masih Hidup</option>
                      <option value="Meninggal Dunia">Meninggal Dunia (Almarhumah)</option>
                      <option value="Tidak Diketahui / Terputus Kontak">Tidak Diketahui / Terputus Kontak</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Baris Kontak Telepon & Data Sosioekonomi */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-3 border-t border-emerald-200/60">
            {/* Kontak Telepon / WA */}
            <div className="md:col-span-2 lg:col-span-1">
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">
                  {fd.tipePengasuh === 'Wali' ? 'Kontak Telepon / WA Wali' : 'Kontak Telepon / WA Orang Tua'} <span className="text-rose-500">*</span>
                </label>
                {(() => {
                  const val = (fd.kontakWali || '').trim();
                  const isPhone = /^(?:\+62|62|08)[0-9]{8,13}$/.test(val.replace(/[\s-]/g, ''));
                  const isStandardNoPhone = val.toLowerCase().includes('tidak ada hp') || 
                                            val.toLowerCase().includes('tidak memiliki hp') || 
                                            val.toLowerCase().includes('terputus') ||
                                            val.toLowerCase().includes('via') ||
                                            val.toLowerCase().includes('hub:');

                  if (isPhone) {
                    return (
                      <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" /> HP Aktif
                      </span>
                    );
                  }
                  if (isStandardNoPhone) {
                    return (
                      <span className="text-[10px] text-sky-800 font-bold flex items-center gap-1 bg-sky-50 px-1.5 py-0.2 rounded border border-sky-200">
                        <PhoneOff className="w-3 h-3 text-sky-600" /> Tanpa HP (Valid)
                      </span>
                    );
                  }
                  if (!val) {
                    return (
                      <span className="text-[10px] text-amber-600 font-medium">Belum diisi</span>
                    );
                  }
                  return (
                    <span className="text-[10px] text-rose-600 font-medium">Periksa format</span>
                  );
                })()}
              </div>

              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
                  <Phone className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={fd.kontakWali || ''}
                  onChange={(e) => onChangeField('kontakWali', e.target.value)}
                  className="w-full rounded-lg border border-slate-300 py-1.5 pl-8 pr-3 text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 font-medium bg-white"
                  placeholder="Contoh: 081234567890 atau pilih tombol di bawah"
                />
              </div>

              {/* Quick Helper Pills for Wali / Orang Tua Without Mobile Phone */}
              <div className="mt-1.5 space-y-1">
                <span className="text-[10px] text-slate-500 block">
                  Bila tidak memiliki HP, pilih standar penulisan resmi:
                </span>
                <div className="flex flex-wrap gap-1">
                  <button
                    type="button"
                    onClick={() => onChangeField('kontakWali', 'Tidak Ada HP (Hub: RT/RW Setempat)')}
                    className="px-1.5 py-0.5 text-[10px] bg-slate-100 hover:bg-sky-100 hover:text-sky-800 text-slate-700 rounded border border-slate-200 transition"
                    title="Tidak memiliki ponsel, komunikasi melalui pengurus RT/RW"
                  >
                    + RT/RW Setempat
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeField('kontakWali', 'Tidak Ada HP (Hub: Kerabat/Tetangga)')}
                    className="px-1.5 py-0.5 text-[10px] bg-slate-100 hover:bg-sky-100 hover:text-sky-800 text-slate-700 rounded border border-slate-200 transition"
                    title="Tidak memiliki ponsel, komunikasi melalui kerabat terdekat"
                  >
                    + Kerabat/Tetangga
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeField('kontakWali', 'Tidak Ada HP (Via Kantor Desa/Kelurahan)')}
                    className="px-1.5 py-0.5 text-[10px] bg-slate-100 hover:bg-sky-100 hover:text-sky-800 text-slate-700 rounded border border-slate-200 transition"
                    title="Tidak memiliki ponsel, pemberitahuan melalui aparat desa/kelurahan"
                  >
                    + Kantor Desa
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeField('kontakWali', 'Kontak Terputus / Tidak Diketahui')}
                    className="px-1.5 py-0.5 text-[10px] bg-slate-100 hover:bg-amber-100 hover:text-amber-800 text-slate-700 rounded border border-slate-200 transition"
                    title="Keberadaan keluarga terputus atau tidak terlacak"
                  >
                    + Terputus
                  </button>
                </div>
              </div>
            </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Bantuan Sosial Diterima</label>
            <select
              value={fd.bantuan || ''}
              onChange={(e) => onChangeField('bantuan', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">- Pilih Bansos -</option>
              <option value="Tidak Ada Bantuan">Tidak Ada Bantuan</option>
              <option value="PKH (Program Keluarga Harapan)">PKH (Program Keluarga Harapan)</option>
              <option value="BPNT (Sembako)">BPNT (Sembako)</option>
              <option value="KIP (Kartu Indonesia Pintar) / PIP">KIP / PIP</option>
              <option value="BLT / Bantuan Dana Desa">BLT / Bantuan Dana Desa</option>
              <option value="Bansos Provinsi Jabar">Bansos Provinsi Jabar</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Status BPJS Kesehatan</label>
            <select
              value={fd.bpjs || ''}
              onChange={(e) => onChangeField('bpjs', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">- Pilih BPJS -</option>
              <option value="BPJS PBI (Pemerintah)">BPJS PBI (Pemerintah)</option>
              <option value="BPJS Mandiri (Aktif)">BPJS Mandiri (Aktif)</option>
              <option value="BPJS Mandiri (Menunggak)">BPJS Mandiri (Menunggak)</option>
              <option value="Tidak Punya BPJS">Tidak Punya BPJS</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Desil Kesejahteraan (DTKS)</label>
            <select
              value={fd.desil || ''}
              onChange={(e) => onChangeField('desil', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">- Pilih Desil -</option>
              <option value="Desil 1">Desil 1 (Sangat Miskin)</option>
              <option value="Desil 2">Desil 2 (Miskin)</option>
              <option value="Desil 3">Desil 3 (Hampir Miskin)</option>
              <option value="Desil 4">Desil 4 (Rentan Miskin)</option>
              <option value="Desil 5-10">Desil 5-10</option>
              <option value="Tidak Terdata">Tidak Terdata di DTKS</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Estimasi Penghasilan Bulanan</label>
            <select
              value={fd.penghasilanBulanan || ''}
              onChange={(e) => onChangeField('penghasilanBulanan', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">- Pilih Penghasilan -</option>
              <option value="Tidak Berpenghasilan">Tidak Berpenghasilan</option>
              <option value="< Rp 1 Juta">&lt; Rp 1.000.000</option>
              <option value="Rp 1 Juta - 3 Juta">Rp 1.000.000 - Rp 3.000.000</option>
              <option value="> Rp 3 Juta">&gt; Rp 3.000.000</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Histori Pekerja Anak</label>
            <div className="flex gap-2">
              <select
                value={fd.pekerjaAnak || 'Tidak'}
                onChange={(e) => onChangeField('pekerjaAnak', e.target.value)}
                className="w-full rounded-lg border border-slate-300 py-1.5 px-2 text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="Tidak">Tidak Pernah Bekerja</option>
                <option value="Ya, Sedang Bekerja">Ya, Sedang Bekerja</option>
                <option value="Ya, Pernah Bekerja">Ya, Pernah Bekerja</option>
              </select>
              <input
                type="text"
                value={fd.pekerjaAnakTahun || ''}
                onChange={(e) => onChangeField('pekerjaAnakTahun', e.target.value)}
                placeholder="Tahun"
                className="w-24 rounded-lg border border-slate-300 py-1.5 px-2 text-sm focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Riwayat Tinggal di Jalanan?</label>
            <select
              value={fd.tinggalJalan || 'Tidak Pernah'}
              onChange={(e) => onChangeField('tinggalJalan', e.target.value)}
              className="w-full rounded-lg border border-slate-300 py-1.5 px-3 text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="Tidak Pernah">Tidak Pernah</option>
              <option value="Ya, Pernah">Ya, Pernah (Anjal/Gepeng)</option>
            </select>
          </div>
        </div>
      </div>

        {/* 4. Riwayat Medis / Penyakit */}
        <div className="bg-rose-50/70 px-5 py-3 border-y border-rose-200 flex items-center gap-2">
          <HeartPulse className="w-4 h-4 text-rose-600" />
          <h3 className="text-sm font-bold text-rose-950">4. Riwayat Medis & Kesehatan Anak</h3>
        </div>
        <div className="p-5 space-y-4">
          <form onSubmit={handleAddPenyakitSubmit} className="flex gap-2 max-w-xl">
            <input
              type="text"
              value={penyakitInput}
              onChange={(e) => setPenyakitInput(e.target.value)}
              placeholder="Contoh: Asma kronis, Alergi antibiotik, Gastritis..."
              className="flex-1 rounded-lg border border-slate-300 py-2 px-3 text-sm focus:ring-2 focus:ring-rose-500"
            />
            <button
              type="submit"
              className="bg-rose-600 hover:bg-rose-700 text-white px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition"
            >
              <Plus className="w-3.5 h-3.5" /> Tambah Penyakit
            </button>
          </form>

          <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50/50">
            {client.riwayatPenyakit && client.riwayatPenyakit.length > 0 ? (
              <ul className="divide-y divide-slate-200">
                {client.riwayatPenyakit.map((p, idx) => (
                  <li key={idx} className="p-3 flex items-center justify-between text-sm bg-white">
                    <span className="flex items-center gap-2 font-medium text-slate-800">
                      <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                      {p}
                    </span>
                    <button
                      type="button"
                      onClick={() => onRemovePenyakit(idx)}
                      className="text-rose-500 hover:text-rose-700 p-1"
                      title="Hapus"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-4 text-center text-xs text-slate-500 italic">
                Tidak ada catatan penyakit atau riwayat medis khusus tercatat.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
