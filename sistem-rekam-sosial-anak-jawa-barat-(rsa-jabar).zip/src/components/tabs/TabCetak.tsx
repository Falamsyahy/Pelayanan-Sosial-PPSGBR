import React, { useState } from 'react';
import { 
  Printer, 
  ShieldAlert, 
  FileText, 
  Download, 
  Loader2, 
  CheckCircle2,
  FileSpreadsheet,
  SlidersHorizontal,
  Layers,
  CheckSquare,
  Square,
  Sparkles
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import { safeHtml2Canvas } from '../../utils/safeHtml2Canvas';
import { Client } from '../../types';
import { exportToWord } from '../../services/exportDocumentService';
import { exportClientsToExcel } from '../../services/exportExcelService';
import { KOPSURAT_BASE64 } from '../../data/kopsuratBase64';

export type PartialSectionKey = 'kop' | 'identitas' | 'asesmen' | 'intervensi' | 'evaluasi' | 'aftercare' | 'ttd';

interface TabCetakProps {
  client: Client;
  peksosName: string;
}

export const TabCetak: React.FC<TabCetakProps> = ({ client, peksosName }) => {
  const fd = client.formData;
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [pdfSuccess, setPdfSuccess] = useState(false);
  const [isGeneratingWord, setIsGeneratingWord] = useState(false);
  const [wordSuccess, setWordSuccess] = useState(false);
  const [excelSuccess, setExcelSuccess] = useState(false);

  // Partial Print State
  const [selectedSections, setSelectedSections] = useState<Record<PartialSectionKey, boolean>>({
    kop: true,
    identitas: true,
    asesmen: true,
    intervensi: true,
    evaluasi: true,
    aftercare: true,
    ttd: true,
  });

  const toggleSection = (key: PartialSectionKey) => {
    setSelectedSections((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const applyPreset = (preset: 'all' | 'biodata' | 'asesmen' | 'intervensi' | 'evaluasi') => {
    if (preset === 'all') {
      setSelectedSections({
        kop: true,
        identitas: true,
        asesmen: true,
        intervensi: true,
        evaluasi: true,
        aftercare: true,
        ttd: true,
      });
    } else if (preset === 'biodata') {
      setSelectedSections({
        kop: true,
        identitas: true,
        asesmen: false,
        intervensi: false,
        evaluasi: false,
        aftercare: false,
        ttd: true,
      });
    } else if (preset === 'asesmen') {
      setSelectedSections({
        kop: true,
        identitas: true,
        asesmen: true,
        intervensi: false,
        evaluasi: false,
        aftercare: false,
        ttd: true,
      });
    } else if (preset === 'intervensi') {
      setSelectedSections({
        kop: true,
        identitas: true,
        asesmen: false,
        intervensi: true,
        evaluasi: false,
        aftercare: false,
        ttd: true,
      });
    } else if (preset === 'evaluasi') {
      setSelectedSections({
        kop: true,
        identitas: true,
        asesmen: false,
        intervensi: false,
        evaluasi: true,
        aftercare: true,
        ttd: true,
      });
    }
  };

  const selectedCount = Object.values(selectedSections).filter(Boolean).length;
  const isAllSelected = selectedCount === 7;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = async () => {
    const element = document.getElementById('print-area');
    if (!element) return;

    try {
      setIsGeneratingPdf(true);
      setPdfSuccess(false);

      // Render the printable element into a high-DPI canvas safely
      const canvas = await safeHtml2Canvas(element, {
        scale: 2, // 2x scale for crisp 300dpi-like text
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        windowWidth: element.scrollWidth,
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      
      // Standard A4 in portrait: 210mm x 297mm
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
        compress: true,
      });

      const pdfWidth = pdf.internal.pageSize.getWidth(); // 210mm
      const pdfHeight = pdf.internal.pageSize.getHeight(); // 297mm
      const imgHeight = (canvas.height * pdfWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;

      // Add first page
      pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, imgHeight, undefined, 'FAST');
      heightLeft -= pdfHeight;

      // Add subsequent pages if document height exceeds single A4
      while (heightLeft > 0) {
        position -= pdfHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, imgHeight, undefined, 'FAST');
        heightLeft -= pdfHeight;
      }

      // Safe filename format: Laporan_Sosial_[Nama_Klien]_[ID].pdf
      const safeClientName = (client.nama || 'Anak_Binaan').replace(/[^a-zA-Z0-9_-]/g, '_');
      const safeClientId = (client.id || 'RS').replace(/[^a-zA-Z0-9_-]/g, '_');
      const filename = `Laporan_Sosial_${safeClientName}_${safeClientId}.pdf`;

      pdf.save(filename);
      setPdfSuccess(true);
      setTimeout(() => setPdfSuccess(false), 4500);
    } catch (error) {
      console.error('Gagal membuat dokumen PDF:', error);
      // Fallback to browser print dialog
      window.print();
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const isHighRisk = fd.tingkatRisiko === 'Tinggi' || fd.tingkatRisiko === 'Kritis';

  return (
    <div className="space-y-6">
      {/* Alert Kerahasiaan Dokumen */}
      <div className="bg-rose-50 border-l-4 border-rose-500 p-4 rounded-r-md shadow-xs no-print flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-rose-600 mt-0.5 shrink-0" />
        <div className="text-xs text-rose-800 leading-relaxed">
          <strong className="text-rose-950 font-bold block mb-0.5">Kerahasiaan Dokumen Rekam Sosial:</strong>
          Dokumen laporan ini dilindungi oleh Undang-Undang Perlindungan Anak (UU No. 35/2014) dan UU PDP (UU No. 27/2022). Dilarang menyebarluaskan data pribadi klien tanpa persetujuan resmi <i>(informed consent)</i> dari wali atau ketetapan pengadilan.
        </div>
      </div>

      {/* Action Toolbar */}
      <div className="flex flex-col sm:flex-row justify-between items-center bg-sky-50/80 p-4 rounded-2xl border border-sky-200 no-print gap-3 shadow-xs">
        <div className="flex items-center gap-2.5 text-xs text-sky-950 font-medium">
          <FileText className="w-4 h-4 text-sky-700 shrink-0" />
          <span>Pratinjau dokumen laporan resmi berformat cetak A4 siap arsip fisik atau digital.</span>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto flex-wrap sm:flex-nowrap">
          {/* Tombol Unduh Excel */}
          <button
            type="button"
            onClick={() => {
              const angkatanStr = client.formData?.angkatan || 'Angkatan I - 2026';
              exportClientsToExcel([client], {
                customFilename: `Data_Anak_${(client.nama || 'Anak').replace(/[^a-zA-Z0-9_-]/g, '_')}_${angkatanStr.replace(/[^a-zA-Z0-9_-]/g, '_')}.xlsx`
              });
              setExcelSuccess(true);
              setTimeout(() => setExcelSuccess(false), 3500);
            }}
            disabled={isGeneratingPdf || isGeneratingWord}
            className="w-full sm:w-auto bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition disabled:opacity-50"
            title="Unduh rekap data anak dalam format Microsoft Excel (.xlsx) dengan kolom Angkatan Masuk"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
            <span>Unduh Excel (.xlsx)</span>
          </button>

          {/* Tombol Unduh Word */}
          <button
            type="button"
            onClick={() => {
              setIsGeneratingWord(true);
              exportToWord({ tabType: 'lengkap', client, peksosName });
              setWordSuccess(true);
              setTimeout(() => {
                setIsGeneratingWord(false);
                setWordSuccess(false);
              }, 3500);
            }}
            disabled={isGeneratingPdf || isGeneratingWord}
            className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition disabled:opacity-50"
            title="Unduh laporan lengkap dalam format Microsoft Word (.doc) yang dapat diedit"
          >
            {isGeneratingWord ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Menyiapkan Word...</span>
              </>
            ) : (
              <>
                <FileText className="w-4 h-4 text-blue-200" />
                <span>Unduh Word (.doc)</span>
              </>
            )}
          </button>

          {/* Tombol Unduh PDF */}
          <button
            type="button"
            onClick={handleDownloadPdf}
            disabled={isGeneratingPdf || isGeneratingWord}
            className={`w-full sm:w-auto px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition ${
              isGeneratingPdf
                ? 'bg-emerald-400 text-white cursor-wait'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white'
            }`}
            title="Unduh langsung file laporan dalam format PDF"
          >
            {isGeneratingPdf ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Memproses PDF...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Unduh Laporan (PDF)</span>
              </>
            )}
          </button>

          {/* Tombol Cetak Browser */}
          <button
            type="button"
            onClick={handlePrint}
            disabled={isGeneratingPdf || isGeneratingWord}
            className="w-full sm:w-auto bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-2xs transition"
            title="Buka dialog pencetakan browser"
          >
            <Printer className="w-4 h-4 text-slate-600" />
            <span>Cetak (Print)</span>
          </button>
        </div>
      </div>

      {/* Notifikasi Berhasil Unduh Excel */}
      {excelSuccess && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 p-3 rounded-xl flex items-center gap-2 text-xs font-semibold no-print animate-in fade-in duration-200 shadow-2xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            Data anak <strong>{client.nama} ({client.formData?.angkatan || 'Angkatan I - 2026'})</strong> berhasil diekspor ke Microsoft Excel (.xlsx) dengan kolom <strong>Angkatan Masuk</strong>!
          </span>
        </div>
      )}

      {/* Notifikasi Berhasil Unduh PDF */}
      {pdfSuccess && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 p-3 rounded-xl flex items-center gap-2 text-xs font-semibold no-print animate-in fade-in duration-200 shadow-2xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            Laporan asesmen anak <strong>{client.nama} ({client.id})</strong> berhasil diunduh dalam format PDF! File tersimpan di folder Unduhan / Downloads perangkat Anda.
          </span>
        </div>
      )}

      {/* Notifikasi Berhasil Unduh Word */}
      {wordSuccess && (
        <div className="bg-blue-50 border border-blue-300 text-blue-900 p-3 rounded-xl flex items-center gap-2 text-xs font-semibold no-print animate-in fade-in duration-200 shadow-2xs">
          <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
          <span>
            Laporan asesmen anak <strong>{client.nama} ({client.id})</strong> berhasil diunduh dalam format Microsoft Word (.doc)! File siap diedit menggunakan Microsoft Word, WPS Office, atau Google Docs.
          </span>
        </div>
      )}

      {/* Panel Kontrol Cetak Parsial */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs no-print space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2 text-slate-800">
            <SlidersHorizontal className="w-4 h-4 text-sky-600 shrink-0" />
            <h3 className="text-xs sm:text-sm font-bold text-slate-900">
              Pilih Lembar Dokumen yang Ingin Dicetak (Cetak Parsial)
            </h3>
            <span className="text-[10px] bg-sky-100 text-sky-800 font-bold px-2 py-0.5 rounded-full border border-sky-300 shrink-0">
              {selectedCount} dari 7 Bagian Terpilih
            </span>
          </div>

          {/* Quick Presets */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-[11px] text-slate-500 font-semibold mr-0.5">Preset Cepat:</span>
            <button
              type="button"
              onClick={() => applyPreset('all')}
              className={`px-2 py-1 text-[11px] font-semibold rounded-lg transition border ${
                isAllSelected
                  ? 'bg-sky-600 text-white border-sky-600'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Semua (Lengkap)
            </button>
            <button
              type="button"
              onClick={() => applyPreset('biodata')}
              className="px-2 py-1 text-[11px] font-semibold bg-slate-50 text-slate-700 border border-slate-200 hover:bg-sky-50 hover:text-sky-800 rounded-lg transition"
              title="Cetak hanya biodata identitas klien, rekam medis balai & pengesahan"
            >
              Biodata & Medis
            </button>
            <button
              type="button"
              onClick={() => applyPreset('asesmen')}
              className="px-2 py-1 text-[11px] font-semibold bg-slate-50 text-slate-700 border border-slate-200 hover:bg-sky-50 hover:text-sky-800 rounded-lg transition"
              title="Cetak hanya laporan asesmen BPSS, genogram, ecomap & analisis kasus"
            >
              Asesmen BPSS
            </button>
            <button
              type="button"
              onClick={() => applyPreset('intervensi')}
              className="px-2 py-1 text-[11px] font-semibold bg-slate-50 text-slate-700 border border-slate-200 hover:bg-sky-50 hover:text-sky-800 rounded-lg transition"
              title="Cetak rencana & log pelaksanaan intervensi SOAP multidisiplin"
            >
              Intervensi SOAP
            </button>
            <button
              type="button"
              onClick={() => applyPreset('evaluasi')}
              className="px-2 py-1 text-[11px] font-semibold bg-slate-50 text-slate-700 border border-slate-200 hover:bg-sky-50 hover:text-sky-800 rounded-lg transition"
              title="Cetak lembar evaluasi panca karakter, aftercare & rekomendasi terminasi"
            >
              Evaluasi & Terminasi
            </button>
          </div>
        </div>

        {/* Section Checkboxes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-1 text-xs">
          {/* Kop */}
          <label className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
            selectedSections.kop ? 'bg-sky-50/60 border-sky-300 text-sky-950' : 'bg-slate-50/50 border-slate-200 text-slate-500'
          }`}>
            <input
              type="checkbox"
              checked={selectedSections.kop}
              onChange={() => toggleSection('kop')}
              className="mt-0.5 rounded text-sky-600 focus:ring-sky-500"
            />
            <div>
              <span className="font-bold block">Kop Surat Resmi</span>
              <span className="text-[11px] text-slate-500 leading-tight block">Kop Dinsos Jabar & Balai</span>
            </div>
          </label>

          {/* Bagian I: Identitas */}
          <label className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
            selectedSections.identitas ? 'bg-sky-50/60 border-sky-300 text-sky-950' : 'bg-slate-50/50 border-slate-200 text-slate-500'
          }`}>
            <input
              type="checkbox"
              checked={selectedSections.identitas}
              onChange={() => toggleSection('identitas')}
              className="mt-0.5 rounded text-sky-600 focus:ring-sky-500"
            />
            <div>
              <span className="font-bold block">I. Identitas & Medis</span>
              <span className="text-[11px] text-slate-500 leading-tight block">Biodata, wali, & rekam balai</span>
            </div>
          </label>

          {/* Bagian II: Asesmen */}
          <label className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
            selectedSections.asesmen ? 'bg-sky-50/60 border-sky-300 text-sky-950' : 'bg-slate-50/50 border-slate-200 text-slate-500'
          }`}>
            <input
              type="checkbox"
              checked={selectedSections.asesmen}
              onChange={() => toggleSection('asesmen')}
              className="mt-0.5 rounded text-sky-600 focus:ring-sky-500"
            />
            <div>
              <span className="font-bold block">II. Asesmen BPSS</span>
              <span className="text-[11px] text-slate-500 leading-tight block">Genogram, ecomap & analisis</span>
            </div>
          </label>

          {/* Bagian III: Intervensi */}
          <label className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
            selectedSections.intervensi ? 'bg-sky-50/60 border-sky-300 text-sky-950' : 'bg-slate-50/50 border-slate-200 text-slate-500'
          }`}>
            <input
              type="checkbox"
              checked={selectedSections.intervensi}
              onChange={() => toggleSection('intervensi')}
              className="mt-0.5 rounded text-sky-600 focus:ring-sky-500"
            />
            <div>
              <span className="font-bold block">III. Intervensi SOAP</span>
              <span className="text-[11px] text-slate-500 leading-tight block">Tujuan & log multidisiplin</span>
            </div>
          </label>

          {/* Bagian IV: Evaluasi */}
          <label className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
            selectedSections.evaluasi ? 'bg-sky-50/60 border-sky-300 text-sky-950' : 'bg-slate-50/50 border-slate-200 text-slate-500'
          }`}>
            <input
              type="checkbox"
              checked={selectedSections.evaluasi}
              onChange={() => toggleSection('evaluasi')}
              className="mt-0.5 rounded text-sky-600 focus:ring-sky-500"
            />
            <div>
              <span className="font-bold block">IV. Evaluasi & Karakter</span>
              <span className="text-[11px] text-slate-500 leading-tight block">Panca Karakter & status akhir</span>
            </div>
          </label>

          {/* Bagian V: Aftercare */}
          <label className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
            selectedSections.aftercare ? 'bg-sky-50/60 border-sky-300 text-sky-950' : 'bg-slate-50/50 border-slate-200 text-slate-500'
          }`}>
            <input
              type="checkbox"
              checked={selectedSections.aftercare}
              onChange={() => toggleSection('aftercare')}
              className="mt-0.5 rounded text-sky-600 focus:ring-sky-500"
            />
            <div>
              <span className="font-bold block">V. Bimbingan Lanjut</span>
              <span className="text-[11px] text-slate-500 leading-tight block">Sekolah, PKBM & buku pantau</span>
            </div>
          </label>

          {/* Pengesahan */}
          <label className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
            selectedSections.ttd ? 'bg-sky-50/60 border-sky-300 text-sky-950' : 'bg-slate-50/50 border-slate-200 text-slate-500'
          }`}>
            <input
              type="checkbox"
              checked={selectedSections.ttd}
              onChange={() => toggleSection('ttd')}
              className="mt-0.5 rounded text-sky-600 focus:ring-sky-500"
            />
            <div>
              <span className="font-bold block">Tanda Tangan & Sah</span>
              <span className="text-[11px] text-slate-500 leading-tight block">Kolom TTD Peksos & Wali</span>
            </div>
          </label>
        </div>
      </div>

      {/* Dokumen Laporan (Printable Container) */}
      <div id="print-area" className="bg-white border border-slate-300 p-8 sm:p-12 max-w-4xl mx-auto shadow-md font-serif text-slate-900 text-sm leading-relaxed rounded-lg">
        {selectedCount === 0 ? (
          <div className="py-16 text-center text-slate-500">
            <Layers className="w-12 h-12 text-slate-300 mx-auto mb-2" />
            <h4 className="font-bold text-base text-slate-700">Tidak ada bagian yang dipilih</h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Silakan centang setidaknya satu bagian dokumen pada panel kontrol cetak parsial di atas untuk menampilkan dan mencetak lembar yang diinginkan.
            </p>
          </div>
        ) : (
          <>
            {/* Kop Surat Resmi Gambar Utuh UPTD PPS Griya Bina Remaja */}
            {selectedSections.kop && (
              <div className="mb-6 text-center border-b-2 border-black pb-3">
                <img 
                  src={KOPSURAT_BASE64}
                  alt="Kop Surat UPTD Pusat Pelayanan Sosial Griya Bina Remaja Lembang" 
                  className="w-full max-h-44 object-contain mx-auto block"
                />
              </div>
            )}

            <div className="text-center mb-6">
              <h2 className="text-base font-bold uppercase underline tracking-wide">
                {isAllSelected 
                  ? 'Laporan Asesmen BPSS & Catatan Intervensi Anak' 
                  : 'Laporan Dokumen Rekam Sosial (Parsial)'}
              </h2>
              <p className="text-xs text-slate-600 mt-1 font-mono">
                Nomor Registrasi: {client.id} | Angkatan: {fd.angkatan || '-'}
                {!isAllSelected && <span className="ml-2 font-bold text-sky-800">[Dokumen Parsial]</span>}
              </p>
            </div>

            {isHighRisk && (
              <div className="border-2 border-black p-2 font-bold text-center uppercase mb-5 bg-slate-100 text-xs">
                PERINGATAN ATENSI KHUSUS: KEDARURATAN RISIKO {fd.tingkatRisiko}
              </div>
            )}

            {/* I. Identitas Klien */}
            {selectedSections.identitas && (
              <div className="mb-6">
                <h3 className="font-bold text-xs sm:text-sm border-b border-black pb-1 uppercase tracking-wide mb-2">
                  I. Identitas Klien & Lingkungan Sosial
                </h3>
                <table className="w-full text-xs sm:text-sm mb-3" style={{ borderCollapse: 'collapse' }}>
                  <tbody>
                    <tr>
                      <td className="w-44 py-1 font-bold">Nama Lengkap Klien</td>
                      <td className="py-1">: {client.nama}</td>
                    </tr>
                    <tr>
                      <td className="py-1 font-bold">Nomor Identitas (NIK)</td>
                      <td className="py-1">: {fd.noIdentitas || '-'} ({fd.statusIdentitas || '-'})</td>
                    </tr>
                    <tr>
                      <td className="py-1 font-bold">Usia & Jenis Kelamin</td>
                      <td className="py-1">: {client.umur} Tahun / {client.gender}</td>
                    </tr>
                    <tr>
                      <td className="py-1 font-bold">Tempat, Tanggal Lahir</td>
                      <td className="py-1">: {fd.tempatLahir || '-'}, {fd.tanggalLahir || '-'} (Agama: {fd.agama || '-'})</td>
                    </tr>
                    <tr>
                      <td className="py-1 font-bold">Pendidikan / Jurusan</td>
                      <td className="py-1">: {fd.pendidikan || '-'} / {fd.jurusan || '-'}</td>
                    </tr>
                    <tr>
                      <td className="py-1 font-bold align-top">Orang Tua / Wali</td>
                      <td className="py-1 align-top">
                        {fd.tipePengasuh === 'Wali' ? (
                          <div>
                            <div>
                              : <strong>Wali:</strong> {fd.namaWali || '-'} {fd.hubunganWali ? `(${fd.hubunganWali})` : ''}
                              {fd.alasanDenganWali ? ` • Alasan: ${fd.alasanDenganWali}` : ''}
                              {fd.pekerjaanOrangTua ? ` • Pekerjaan: ${fd.pekerjaanOrangTua}` : ''}
                              {fd.kontakWali ? ` • Telp: ${fd.kontakWali}` : ''}
                            </div>
                            <div className="text-[11px] text-slate-700 mt-0.5">
                              &nbsp; <strong>Status Orang Tua Kandung:</strong> Ayah ({fd.namaAyah || '-'}: <em>{fd.statusAyah || 'Tidak Diketahui'}</em>) | Ibu ({fd.namaIbu || '-'}: <em>{fd.statusIbu || 'Tidak Diketahui'}</em>)
                            </div>
                          </div>
                        ) : (
                          <div>
                            <div>
                              : <strong>Ayah:</strong> {fd.namaAyah || fd.namaWali || '-'} ({fd.statusAyah || 'Masih Hidup'}{fd.pekerjaanAyah || fd.pekerjaanOrangTua ? `, ${fd.pekerjaanAyah || fd.pekerjaanOrangTua}` : ''})
                            </div>
                            <div>
                              &nbsp; <strong>Ibu:</strong> {fd.namaIbu || '-'} ({fd.statusIbu || 'Masih Hidup'}{fd.pekerjaanIbu ? `, ${fd.pekerjaanIbu}` : ''})
                            </div>
                            <div className="text-[11px] text-slate-700">
                              &nbsp; <strong>Kontak Keluarga:</strong> {fd.kontakWali || '-'}
                            </div>
                          </div>
                        )}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-1 font-bold align-top">Alamat Asal Daerah</td>
                      <td className="py-1 align-top">
                        : {fd.alamat || '-'}, Desa {fd.desa || '-'}, Kec. {fd.kecamatan || '-'}, {fd.kabupatenKota || '-'}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-1 font-bold">Riwayat Medis / Penyakit</td>
                      <td className="py-1">
                        : {client.riwayatPenyakit && client.riwayatPenyakit.length > 0 ? client.riwayatPenyakit.join(', ') : 'Tidak ada riwayat medis berat.'}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {/* II. Asesmen Masalah & BPSS */}
            {selectedSections.asesmen && (
              <div className="mb-6">
                <h3 className="font-bold text-xs sm:text-sm border-b border-black pb-1 uppercase tracking-wide mb-2">
                  II. Asesmen Masalah & Dimensi BPSS
                </h3>

                <div className="mb-3">
                  <p className="font-bold text-xs uppercase mb-1">Kronologi / Latar Belakang Masalah:</p>
                  <p className="border border-slate-400 p-2.5 text-xs sm:text-sm text-justify leading-relaxed bg-slate-50/30">
                    {fd.asesmenKronologi || 'Belum ada catatan kronologi.'}
                  </p>
                </div>

                {/* Metodologi & Instrumen Penggalian Data Peksos */}
                <div className="mb-3 border border-black p-2.5 bg-slate-50 text-xs space-y-1.5">
                  <p className="font-bold uppercase text-[11px] border-b border-black pb-0.5 text-slate-800">
                    Metodologi & Sumber Penggalian Data Asesmen:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <p>
                      <strong>Metode Penggalian:</strong>{' '}
                      {fd.asesmenMetodePenggalian && fd.asesmenMetodePenggalian.length > 0
                        ? fd.asesmenMetodePenggalian.join(', ')
                        : 'Wawancara mendalam anak, observasi'}
                    </p>
                    <p>
                      <strong>Sumber Informan:</strong>{' '}
                      {fd.asesmenSumberInforman && fd.asesmenSumberInforman.length > 0
                        ? fd.asesmenSumberInforman.join(', ')
                        : 'Anak binaan, orang tua/wali'}
                    </p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <p>
                      <strong>Instrumen Diagnostik:</strong>{' '}
                      {fd.asesmenInstrumenDigunakan && fd.asesmenInstrumenDigunakan.length > 0
                        ? fd.asesmenInstrumenDigunakan.join(', ')
                        : 'Genogram, Ecomap'}
                    </p>
                    <p>
                      <strong>Kecukupan Data:</strong>{' '}
                      {fd.asesmenKecukupanData || 'Data Lengkap & Memadai (Data Saturated)'}
                    </p>
                  </div>
                  {fd.asesmenCatatanPenggalian && (
                    <p className="pt-1 text-slate-700 italic border-t border-slate-300">
                      <strong>Catatan Lapangan:</strong> {fd.asesmenCatatanPenggalian}
                    </p>
                  )}

                  {/* Triangulasi Genogram, Ecomap & Social Roadmap */}
                  <div className="pt-2 border-t border-slate-300 space-y-1">
                    <p className="font-bold uppercase text-[10px] text-slate-700">Triangulasi Instrumen Diagnostik:</p>
                    <p><strong>Genogram (3 Generasi):</strong> {fd.genogramCatatan || 'Pola asuh dan silsilah keluarga tercatat.'}</p>
                    <p><strong>Ecomap Lingkungan:</strong> {fd.ecomapCatatan || 'Jejaring ekologis dan sistem sumber tercatat.'}</p>
                    <p><strong>Social Roadmap:</strong> {fd.socialRoadmapCatatan || 'Target alur 3 fase kemandirian tercatat.'}</p>
                  </div>

                  {/* Lampiran Visualisasi Diagnostik (Genogram & Ecomap) */}
                  {(fd.genogramImage || fd.ecomapImage) && (
                    <div className="pt-2 border-t border-slate-300">
                      <p className="font-bold uppercase text-[10px] text-slate-700 mb-2">Visualisasi Diagram Diagnostik:</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {fd.genogramImage && (
                          <div className="border border-slate-400 p-2 text-center bg-slate-50 rounded">
                            <p className="text-[10px] font-bold text-indigo-900 mb-1">Diagram Genogram 3 Generasi</p>
                            <img src={fd.genogramImage} alt="Diagram Genogram" className="max-h-48 mx-auto object-contain" />
                          </div>
                        )}
                        {fd.ecomapImage && (
                          <div className="border border-slate-400 p-2 text-center bg-slate-50 rounded">
                            <p className="text-[10px] font-bold text-sky-900 mb-1">Diagram Ecomap Ekologi Sosial</p>
                            <img src={fd.ecomapImage} alt="Diagram Ecomap" className="max-h-48 mx-auto object-contain" />
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                <table className="w-full text-xs border border-black mb-3" style={{ borderCollapse: 'collapse' }}>
                  <thead>
                    <tr className="bg-slate-100 border-b border-black">
                      <th className="border-r border-black p-1.5 w-1/4 text-left font-bold uppercase">Dimensi Asesmen</th>
                      <th className="p-1.5 text-left font-bold uppercase">Temuan & Dinamika Kondisi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-black">
                    <tr>
                      <td className="border-r border-black p-1.5 font-bold align-top bg-slate-50">Biologis & Rekam Kesehatan Balai</td>
                      <td className="p-1.5 text-xs">
                        <div><strong>Antropometri:</strong> Gol. Darah: <strong>{fd.kesehatanGolonganDarah || '-'}</strong> | TB: <strong>{fd.kesehatanTinggiBadan || '-'} cm</strong> | BB: <strong>{fd.kesehatanBeratBadan || '-'} kg</strong> | IMT: <strong>{fd.kesehatanIMT || '-'}</strong> ({fd.kesehatanStatusGizi || 'Normal'})</div>
                        <div className="mt-1"><strong>Skrining Balai:</strong> Imunisasi: {fd.kesehatanStatusImunisasi || '-'} | Kulit: {fd.kesehatanPenyakitKulit || 'Bebas keluhan'} | Zat: {fd.kesehatanSkriningZat || 'Bebas zat'} | Alergi: {fd.kesehatanRiwayatAlergi || '-'}</div>
                        {fd.kesehatanCatatanKlinik && <div className="mt-1"><strong>Catatan Klinik:</strong> {fd.kesehatanCatatanKlinik}</div>}
                        <div className="mt-1"><strong>Deskripsi Fisik:</strong> {fd.asesmenBiologis || '-'}</div>
                      </td>
                    </tr>
                    <tr>
                      <td className="border-r border-black p-1.5 font-bold align-top bg-slate-50">Psikologis / Emosi</td>
                      <td className="p-1.5 text-justify">{fd.asesmenPsikologis || '-'}</td>
                    </tr>
                    <tr>
                      <td className="border-r border-black p-1.5 font-bold align-top bg-slate-50">Sosial & Relasi</td>
                      <td className="p-1.5 text-justify">{fd.asesmenSosial || '-'}</td>
                    </tr>
                    <tr>
                      <td className="border-r border-black p-1.5 font-bold align-top bg-slate-50">Spiritual & Nilai</td>
                      <td className="p-1.5 text-justify">{fd.asesmenSpiritual || '-'}</td>
                    </tr>
                  </tbody>
                </table>

                {/* Pemaknaan Teoretis */}
                <div className="mt-3">
                  <p className="font-bold text-xs uppercase mb-1">Analisis & Pemaknaan Kasus Berbasis Teori (Meaning-Making):</p>
                  <div className="border border-black p-3 text-xs sm:text-sm text-justify leading-relaxed bg-slate-50">
                    {fd.asesmenPemaknaan || 'Belum ada rumusan analisis pemaknaan teoretis.'}
                  </div>
                </div>
              </div>
            )}

            {/* III. Rencana & Log Intervensi */}
            {selectedSections.intervensi && (
              <div className="mb-6 page-break">
                <h3 className="font-bold text-xs sm:text-sm border-b border-black pb-1 uppercase tracking-wide mb-2">
                  III. Rencana & Pelaksanaan Intervensi Sosial
                </h3>

                <div className="mb-3 space-y-1.5 text-xs sm:text-sm">
                  <p><strong>Tujuan Intervensi:</strong> {fd.intervensiTujuan || '-'}</p>
                  <p><strong>Strategi & Pendekatan:</strong> {fd.intervensiStrategi || '-'}</p>
                </div>

                <p className="font-bold text-xs uppercase mb-1">Log Pelaksanaan Layanan / Sesi Pembinaan Terpadu (SOAP Multidisiplin):</p>
                <table className="w-full text-xs border border-black mb-3" style={{ borderCollapse: 'collapse' }}>
                  <thead>
                    <tr className="bg-slate-100 border-b border-black">
                      <th className="border-r border-black p-1.5 w-32 text-left font-bold">Tanggal & Pelaksana</th>
                      <th className="border-r border-black p-1.5 text-left font-bold">Tindakan / Catatan SOAP</th>
                      <th className="p-1.5 text-left font-bold w-48">Indikator Capaian</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-black">
                    {client.pelaksanaanIntervensi && client.pelaksanaanIntervensi.length > 0 ? (
                      client.pelaksanaanIntervensi.map((item, idx) => (
                        <tr key={item.id || `intervensi-${idx}`}>
                          <td className="border-r border-black p-1.5 font-semibold whitespace-nowrap align-top">
                            {item.tanggal}<br/>
                            <span className="text-[10px] text-indigo-800 font-bold">[{item.peranPelaksana || 'Pekerja Sosial'}]</span>
                          </td>
                          <td className="border-r border-black p-1.5 align-top">
                            <strong>{item.deskripsi}</strong>
                            {(item.subjective || item.objective || item.assessment || item.plan) && (
                              <div className="mt-1 pt-1 border-t border-dashed border-slate-300 text-[10px] space-y-0.5 text-slate-700">
                                {item.subjective && <div><strong>S:</strong> <em>{item.subjective}</em></div>}
                                {item.objective && <div><strong>O:</strong> {item.objective}</div>}
                                {item.assessment && <div><strong>A:</strong> {item.assessment}</div>}
                                {item.plan && <div><strong>P:</strong> {item.plan}</div>}
                              </div>
                            )}
                          </td>
                          <td className="p-1.5 align-top">{item.indikator}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={3} className="p-2 text-center italic">Tidak ada catatan sesi intervensi.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* IV. Evaluasi & Status Kasus */}
            {selectedSections.evaluasi && (
              <div className="mb-6">
                <h3 className="font-bold text-xs sm:text-sm border-b border-black pb-1 uppercase tracking-wide mb-2">
                  IV. Evaluasi, Panca Karakter & Rekomendasi Kasus
                </h3>

                {/* Panca Karakter Scores */}
                {fd.pancaKarakterTerakhir && (
                  <div className="border border-black p-2.5 bg-emerald-50/50 mb-3 text-xs">
                    <p className="font-bold uppercase text-[11px] text-emerald-950 mb-1 border-b border-black pb-0.5">
                      Pengukuran Skala Kemandirian: Panca Karakter Jabar
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 pt-1 font-bold text-slate-800 text-[11px]">
                      <div>Béréhan: <span className="text-emerald-700">{fd.pancaKarakterTerakhir.berehan}</span></div>
                      <div>Calakan: <span className="text-indigo-700">{fd.pancaKarakterTerakhir.calakan}</span></div>
                      <div>Waringkas: <span className="text-amber-700">{fd.pancaKarakterTerakhir.waringkas}</span></div>
                      <div>Motékar: <span className="text-emerald-700">{fd.pancaKarakterTerakhir.motekar}</span></div>
                      <div>Berséka: <span className="text-cyan-700">{fd.pancaKarakterTerakhir.berseka}</span></div>
                    </div>
                    <div className="mt-1 pt-1 border-t border-slate-300 flex justify-between items-center text-[11px]">
                      <span>Skor Komposit: <strong>{fd.pancaKarakterTerakhir.skorKomposit}/100</strong></span>
                      {fd.pancaKarakterTerakhir.catatan && <span className="italic text-slate-600">"{fd.pancaKarakterTerakhir.catatan}"</span>}
                    </div>
                  </div>
                )}

                <p className="text-xs sm:text-sm mb-2 text-justify">
                  <strong>Capaian Perkembangan:</strong> {fd.evaluasiPerkembangan || '-'}
                </p>
                {fd.evaluasiHambatan && (
                  <p className="text-xs sm:text-sm mb-2 text-justify">
                    <strong>Catatan Hambatan:</strong> {fd.evaluasiHambatan}
                  </p>
                )}

                <div className="border border-black p-2.5 bg-slate-100 text-center font-bold text-xs uppercase mt-3">
                  STATUS KASUS SAAT INI: <span>{client.status}</span>
                  {fd.terminasiAlasan && (
                    <span className="block normal-case font-normal text-slate-700 mt-1">
                      Keterangan: {fd.terminasiAlasan}
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* V. Indikator Bimbingan Lanjut (Aftercare / Reintegrasi Pendidikan) */}
            {selectedSections.aftercare && (
              <div className="mb-6">
                <h3 className="font-bold text-xs sm:text-sm border-b border-black pb-1 uppercase tracking-wide mb-2">
                  V. Indikator Bimbingan Lanjut (Aftercare) & Keberlanjutan Pendidikan
                </h3>
                <div className="border border-black p-3 bg-slate-50 text-xs sm:text-sm space-y-1.5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <p>
                      <strong>Jalur Pendidikan:</strong>{' '}
                      {fd.aftercareStatusPendidikan || 'Belum diisi / Dalam proses advokasi'}
                    </p>
                    <p>
                      <strong>Jenjang / Paket Belajar:</strong>{' '}
                      {fd.aftercareJenjang || '-'}
                    </p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <p>
                      <strong>Nama Sekolah / Lembaga PKBM:</strong>{' '}
                      {fd.aftercareNamaSekolah || '-'}
                    </p>
                    <p>
                      <strong>Status Keaktifan Siswa:</strong>{' '}
                      {fd.aftercareStatusSiswa || '-'}
                    </p>
                  </div>
                  {fd.aftercareCatatanPendidikan && (
                    <p className="pt-1 text-slate-800 text-justify">
                      <strong>Catatan Pemantauan Peksos:</strong> {fd.aftercareCatatanPendidikan}
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* VI. Buku Pantau Pasca-Binaan (Aftercare Follow-Up Logbook) */}
            {selectedSections.aftercare && fd.aftercareFollowUps && fd.aftercareFollowUps.length > 0 && (
              <div className="mb-8 page-break">
                <h3 className="font-bold text-xs sm:text-sm border-b border-black pb-1 uppercase tracking-wide mb-2">
                  VI. Buku Pantau Pasca-Binaan (Aftercare Follow-Up Logbook)
                </h3>
                <table className="w-full text-xs border border-black mb-3" style={{ borderCollapse: 'collapse' }}>
                  <thead>
                    <tr className="bg-slate-100 border-b border-black">
                      <th className="border-r border-black p-1.5 w-28 text-left font-bold">Tanggal & Periode</th>
                      <th className="border-r border-black p-1.5 w-36 text-left font-bold">Metode & Status</th>
                      <th className="border-r border-black p-1.5 text-left font-bold">Kondisi Sekolah/Kerja & Keluarga</th>
                      <th className="p-1.5 text-left font-bold">Catatan Peksos</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-black">
                    {fd.aftercareFollowUps.map((item, idx) => (
                      <tr key={item.id || `aftercare-${idx}`}>
                        <td className="border-r border-black p-1.5 align-top whitespace-nowrap">
                          <strong>{item.tanggal}</strong><br/>
                          <span className="text-[10px] text-indigo-800 font-bold">[{item.periode}]</span>
                        </td>
                        <td className="border-r border-black p-1.5 align-top">
                          <div>{item.metodeKontak}</div>
                          <strong>[{item.statusReintegrasi}]</strong>
                        </td>
                        <td className="border-r border-black p-1.5 align-top text-[11px]">
                          <div><strong>Sekolah/Kerja:</strong> {item.kondisiSekolahKerja}</div>
                          <div><strong>Keluarga:</strong> {item.kondisiKeluarga}</div>
                        </td>
                        <td className="p-1.5 align-top text-[11px]">{item.catatanPeksos}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Lembar Tanda Tangan */}
            {selectedSections.ttd && (
              <div className="mt-12 pt-4 flex justify-between items-end text-xs sm:text-sm">
                <div className="text-center w-60">
                  <p className="font-bold mb-16">Penerima Manfaat / Wali,</p>
                  <p className="border-t border-black font-bold pt-1">{client.nama}</p>
                </div>

                <div className="text-center w-64">
                  <p className="mb-1 text-slate-700">
                    {fd.kabupatenKota ? fd.kabupatenKota.replace('Kabupaten ', '').replace('Kota ', '') : 'Bandung'},{' '}
                    {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </p>
                  <p className="font-bold mb-16">Pekerja Sosial Pendamping,</p>
                  <p className="border-t border-black font-bold pt-1">{peksosName || 'Pekerja Sosial Ahli'}</p>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
