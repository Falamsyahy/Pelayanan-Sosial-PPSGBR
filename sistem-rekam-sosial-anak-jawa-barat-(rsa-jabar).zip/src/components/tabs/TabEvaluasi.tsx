import React, { useState } from 'react';
import { 
  Flag, 
  CheckCircle2, 
  GraduationCap, 
  BookOpen, 
  School, 
  AlertCircle,
  Sparkles,
  HelpCircle,
  FileCheck,
  Compass,
  Network,
  Users,
  Milestone,
  Award,
  Plus,
  Trash2,
  PhoneCall,
  Home,
  Briefcase,
  Calendar,
  ClipboardList,
  ShieldAlert,
  Clock,
  HeartHandshake
} from 'lucide-react';
import { 
  Client, 
  ClientStatus, 
  AftercareFollowUpItem, 
  AftercarePeriod, 
  AftercareContactMethod, 
  ReintegrationStatus,
  PancaKarakterScores
} from '../../types';
import { ExportToolbar } from '../ExportToolbar';
import { ChildGrowthChart } from '../charts/ChildGrowthChart';
import { PancaKarakterModal } from '../modals/PancaKarakterModal';

interface TabEvaluasiProps {
  client: Client;
  onChangeField: (key: string, value: any) => void;
  peksosName?: string;
  onShowToast?: (msg: string, type?: 'success' | 'error') => void;
}

export const TabEvaluasi: React.FC<TabEvaluasiProps> = ({ 
  client, 
  onChangeField,
  peksosName,
  onShowToast
}) => {
  const fd = client.formData;

  const [isPancaKarakterOpen, setIsPancaKarakterOpen] = useState(false);

  // New follow-up form state
  const [followUpTanggal, setFollowUpTanggal] = useState(new Date().toISOString().split('T')[0]);
  const [followUpPeriode, setFollowUpPeriode] = useState<AftercarePeriod>('Bulan ke-1');
  const [followUpMetode, setFollowUpMetode] = useState<AftercareContactMethod>('Home Visit (Kunjungan Rumah)');
  const [followUpStatus, setFollowUpStatus] = useState<ReintegrationStatus>('Mandiri Stabil');
  const [followUpSekolahKerja, setFollowUpSekolahKerja] = useState('');
  const [followUpKeluarga, setFollowUpKeluarga] = useState('');
  const [followUpCatatan, setFollowUpCatatan] = useState('');

  const handleStatusChange = (val: ClientStatus) => {
    onChangeField('terminasiStatus', val);
    onChangeField('status', val);
  };

  const handleAddFollowUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!followUpCatatan.trim() && !followUpSekolahKerja.trim()) {
      if (onShowToast) onShowToast('Mohon lengkapi catatan pemantauan atau kondisi anak.', 'error');
      return;
    }

    const newItem: AftercareFollowUpItem = {
      id: `af-${Date.now()}`,
      tanggal: followUpTanggal,
      periode: followUpPeriode,
      metodeKontak: followUpMetode,
      statusReintegrasi: followUpStatus,
      kondisiSekolahKerja: followUpSekolahKerja.trim() || 'Melanjutkan pendidikan/kegiatan terstruktur.',
      kondisiKeluarga: followUpKeluarga.trim() || 'Hubungan dengan keluarga suportif.',
      catatanPeksos: followUpCatatan.trim(),
    };

    const currentList = fd.aftercareFollowUps || [];
    onChangeField('aftercareFollowUps', [newItem, ...currentList]);

    setFollowUpSekolahKerja('');
    setFollowUpKeluarga('');
    setFollowUpCatatan('');
    if (onShowToast) onShowToast('Catatan buku pantau aftercare berhasil disimpan.', 'success');
  };

  const handleRemoveFollowUp = (id: string) => {
    const currentList = fd.aftercareFollowUps || [];
    const updated = currentList.filter(item => item.id !== id);
    onChangeField('aftercareFollowUps', updated);
    if (onShowToast) onShowToast('Catatan pemantauan dihapus.', 'success');
  };

  const statusPendidikan = fd.aftercareStatusPendidikan || '';
  const isSekolah = statusPendidikan.includes('Formal') || statusPendidikan.includes('PKBM');
  const lastPanca = fd.pancaKarakterTerakhir;

  return (
    <div className="space-y-6">
      {/* Export Toolbar: Unduh PDF & Word untuk Evaluasi & Aftercare */}
      <ExportToolbar
        tabType="evaluasi"
        title="Evaluasi & Aftercare"
        client={client}
        peksosName={peksosName}
        onShowToast={onShowToast}
      />

      {/* Panduan Etik */}
      <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-r-md shadow-xs no-print">
        <div className="flex items-start">
          <Flag className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
          <div className="ml-3">
            <h3 className="text-sm font-bold text-amber-900">Panduan Etik: Evaluasi, Terminasi & Bimbingan Lanjut (Do-No-Harm)</h3>
            <p className="text-xs text-amber-800 mt-1 leading-relaxed">
              Lakukan evaluasi keberhasilan secara jujur dan berbasis data log layanan. Pada tahap terminasi dan pasca pembinaan (*aftercare*), pastikan hak pendidikan anak terlindungi baik melalui reintegrasi sekolah formal maupun non-formal (PKBM) tanpa menimbulkan stigma atau trauma baru.
            </p>
          </div>
        </div>
      </div>

      {/* Quick Launch & Status: Rubrik Panca Karakter Jabar */}
      <div className="bg-linear-to-r from-emerald-900 via-teal-900 to-indigo-950 text-white rounded-2xl p-5 shadow-sm border border-emerald-700/60 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 text-amber-300 shrink-0">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-base font-black tracking-tight text-white">
                Skala Kemandirian Sosial: Panca Karakter Jabar
              </h3>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-amber-400 text-slate-900">
                Kearifan Lokal Jawa Barat
              </span>
            </div>
            <p className="text-xs text-emerald-200 mt-1">
              {lastPanca ? (
                <>
                  Penilaian Terakhir: <strong className="text-white">{lastPanca.tanggal}</strong> • Skor Komposit: <strong className="text-amber-300">{lastPanca.skorKomposit}/100</strong>
                </>
              ) : (
                'Evaluasi kemandirian sosial anak dengan 5 karakter: Béréhan, Calakan, Waringkas, Motékar, Berséka.'
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          {lastPanca && (
            <div className="hidden sm:flex items-center gap-1.5 text-[11px] font-bold">
              <span className="bg-emerald-800/80 px-2 py-1 rounded border border-emerald-600/60 text-emerald-200" title="Béréhan">B: {lastPanca.berehan}</span>
              <span className="bg-indigo-800/80 px-2 py-1 rounded border border-indigo-600/60 text-indigo-200" title="Calakan">C: {lastPanca.calakan}</span>
              <span className="bg-amber-800/80 px-2 py-1 rounded border border-amber-600/60 text-amber-200" title="Waringkas">W: {lastPanca.waringkas}</span>
              <span className="bg-emerald-800/80 px-2 py-1 rounded border border-emerald-600/60 text-emerald-200" title="Motékar">M: {lastPanca.motekar}</span>
              <span className="bg-cyan-800/80 px-2 py-1 rounded border border-cyan-600/60 text-cyan-200" title="Berséka">S: {lastPanca.berseka}</span>
            </div>
          )}

          <button
            type="button"
            onClick={() => setIsPancaKarakterOpen(true)}
            className="w-full md:w-auto bg-amber-400 hover:bg-amber-300 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow-md transition shrink-0"
          >
            <Sparkles className="w-4 h-4 text-slate-900" />
            <span>{lastPanca ? 'Buka / Perbarui Rubrik Panca Karakter' : 'Ukur Panca Karakter Klien'}</span>
          </button>
        </div>
      </div>

      {/* 1. Kurva Pertumbuhan & Perkembangan Anak (Growth Chart Visualizer via Recharts) */}
      <ChildGrowthChart client={client} onChangeField={onChangeField} />

      {/* 2. Evaluasi Perkembangan Terpadu: Social Roadmap, Genogram & Ecomap */}
      <div className="bg-white rounded-2xl border-2 border-indigo-200/90 p-6 space-y-6 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-indigo-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-linear-to-tr from-indigo-600 to-sky-600 text-white flex items-center justify-center shadow-xs">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span>2. Evaluasi Perkembangan Terpadu</span>
                <span className="bg-indigo-100 text-indigo-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-indigo-300">
                  Social Roadmap • Genogram • Ecomap
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Pemantauan lintasan tahapan kemandirian anak (Roadmap) dipadukan dengan kesiapan sistem keluarga (Genogram) dan relasi ekologis purna binaan (Ecomap).
              </p>
            </div>
          </div>
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
            Status Kasus: <strong className="text-indigo-700">{client.status || 'Kasus Aktif'}</strong>
          </span>
        </div>

        {/* Visualisasi 3-Fase Social Roadmap */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5 uppercase tracking-wide">
              <Milestone className="w-4 h-4 text-indigo-600" />
              Alur 3-Fase Social Roadmap Anak Menuju Kemandirian
            </h4>
            <span className="text-[11px] text-slate-500">
              Sinkron dengan Rekam Asesmen & Intervensi
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* Fase 1: Intake & Kerentanan Awal */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2 relative">
              <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                <span className="text-[11px] font-bold text-slate-800 flex items-center gap-1">
                  <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-[10px] font-black flex items-center justify-center">1</span>
                  Fase 1: Intake & Kerentanan
                </span>
                <span className="text-[9px] font-bold uppercase bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">
                  {fd.tingkatRisiko || 'Risiko Terdata'}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Kondisi awal anak saat masuk balai (riwayat putus sekolah, pengasuhan rentan/jalanan, trauma keluarga).
              </p>
              <div className="text-[10px] text-slate-500 bg-white p-2 rounded-lg border border-slate-200/80">
                <strong>Alasan Masuk:</strong> {fd.alasanMasuk || (fd.asesmenKronologi ? fd.asesmenKronologi.slice(0, 48) + '...' : 'Anak terlantar / putus sekolah')}
              </div>
            </div>

            {/* Fase 2: Pembinaan Sentra / Asrama & Vokasi */}
            <div className="bg-sky-50/70 border border-sky-200 rounded-xl p-4 space-y-2 relative">
              <div className="flex items-center justify-between border-b border-sky-200 pb-1.5">
                <span className="text-[11px] font-bold text-sky-950 flex items-center gap-1">
                  <span className="w-5 h-5 rounded-full bg-sky-600 text-white text-[10px] font-black flex items-center justify-center">2</span>
                  Fase 2: Pembinaan Balai & Vokasi
                </span>
                <span className="text-[9px] font-bold uppercase bg-sky-100 text-sky-800 px-1.5 py-0.5 rounded">
                  {(client.pelaksanaanIntervensi || []).length} Sesi Terlaksana
                </span>
              </div>
              <p className="text-[11px] text-sky-900 leading-relaxed">
                Pengembangan keterampilan hidup (life skills), bimbingan vokasional bersertifikat, dan kestabilan mental-spiritual.
              </p>
              <div className="text-[10px] text-sky-900 bg-white p-2 rounded-lg border border-sky-200">
                <strong>Fokus:</strong> {fd.intervensiStrategi ? fd.intervensiStrategi.slice(0, 60) + '...' : 'Pelatihan vokasional & penguatan resiliensi'}
              </div>
            </div>

            {/* Fase 3: Transisi & Aftercare Kemandirian */}
            <div className={`rounded-xl p-4 space-y-2 relative border ${
              client.status === 'Terminasi (Selesai)'
                ? 'bg-emerald-50/90 border-emerald-300'
                : 'bg-emerald-50/40 border-emerald-200'
            }`}>
              <div className="flex items-center justify-between border-b border-emerald-200 pb-1.5">
                <span className="text-[11px] font-bold text-emerald-950 flex items-center gap-1">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-[10px] font-black flex items-center justify-center">3</span>
                  Fase 3: Kemandirian & Reintegrasi
                </span>
                <span className="text-[9px] font-bold uppercase bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">
                  {fd.aftercareStatusPendidikan ? 'Teradvokasi' : 'Persiapan'}
                </span>
              </div>
              <p className="text-[11px] text-emerald-900 leading-relaxed">
                Kelanjutan pendidikan (Sekolah/PKBM), magang kerja mandiri, dan reintegrasi keluarga tanpa stigma.
              </p>
              <div className="text-[10px] text-emerald-900 bg-white p-2 rounded-lg border border-emerald-200">
                <strong>Status Studi:</strong> {fd.aftercareStatusPendidikan || 'Dalam pemetaan aftercare'}
              </div>
            </div>
          </div>
        </div>

        {/* Input & Evaluasi Catatan Roadmap, Genogram & Ecomap */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 pt-1">
          {/* Roadmap Notes */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-indigo-600" />
              Capaian Target Social Roadmap
            </label>
            <textarea
              rows={3}
              value={fd.socialRoadmapCatatan || ''}
              onChange={(e) => onChangeField('socialRoadmapCatatan', e.target.value)}
              placeholder="Catat evaluasi ketercapaian milestone anak: apakah target vokasi dan kesiapan hidup mandiri sudah terpenuhi..."
              className="w-full rounded-lg border border-slate-300 p-2 text-xs text-slate-800 bg-white focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Genogram Readiness */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-blue-600" />
              Kesiapan Keluarga (Genogram)
            </label>
            <textarea
              rows={3}
              value={fd.genogramCatatan || ''}
              onChange={(e) => onChangeField('genogramCatatan', e.target.value)}
              placeholder="Evaluasi kesiapan figur pengasuh dalam keluarga (reunifikasi) atau perlunya rujukan ke pengasuhan alternatif..."
              className="w-full rounded-lg border border-slate-300 p-2 text-xs text-slate-800 bg-white focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Ecomap Ecological Support */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Network className="w-3.5 h-3.5 text-emerald-600" />
              Jejaring Ekologis (Ecomap)
            </label>
            <textarea
              rows={3}
              value={fd.ecomapCatatan || ''}
              onChange={(e) => onChangeField('ecomapCatatan', e.target.value)}
              placeholder="Evaluasi dukungan lingkungan luar: keterhubungan dengan PKBM mitra, aparat desa/Dinsos, dan peluang kerja lokal..."
              className="w-full rounded-lg border border-slate-300 p-2 text-xs text-slate-800 bg-white focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 3. Evaluasi Perkembangan */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4 shadow-2xs">
          <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-2">
            <span>3. Catatan Evaluasi Perkembangan Klien</span>
          </h3>

          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              Capaian Perkembangan & Perubahan Sikap
            </label>
            <textarea
              rows={4}
              value={fd.evaluasiPerkembangan || ''}
              onChange={(e) => onChangeField('evaluasiPerkembangan', e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-3 text-sm focus:ring-2 focus:ring-sky-500 text-slate-800"
              placeholder="Deskripsikan perubahan perilaku, kestabilan emosi, pencapaian keterampilan vokasional, dan relasi sosial klien..."
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              Hambatan Selama Proses Pendampingan
            </label>
            <textarea
              rows={3}
              value={fd.evaluasiHambatan || ''}
              onChange={(e) => onChangeField('evaluasiHambatan', e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-3 text-sm focus:ring-2 focus:ring-sky-500 text-slate-800"
              placeholder="Faktor internal/eksternal yang menghambat (misal: kurangnya dukungan keluarga, masalah adaptasi)..."
            />
          </div>
        </div>

        {/* 4. Terminasi & Status Kasus */}
        <div className="bg-amber-50/40 rounded-xl border-2 border-amber-200 p-6 space-y-4 shadow-2xs">
          <h3 className="text-base font-bold text-amber-950 border-b border-amber-200 pb-2 flex items-center gap-2">
            <span>4. Status Akhir Kasus & Terminasi</span>
          </h3>

          <div>
            <label className="block text-xs font-bold text-amber-950 mb-1">
              Status Akhir Kasus
            </label>
            <select
              value={fd.terminasiStatus || client.status}
              onChange={(e) => handleStatusChange(e.target.value as ClientStatus)}
              className="w-full rounded-lg border-2 border-amber-300 p-2.5 text-sm font-bold text-amber-950 bg-white focus:ring-2 focus:ring-amber-500"
            >
              <option value="Calon Klien (Proses Seleksi)">Calon Klien (Tahap Seleksi)</option>
              <option value="Kasus Aktif">Kasus Aktif (Sedang Berjalan)</option>
              <option value="Terminasi (Selesai)">Terminasi (Lulus / Selesai Mandiri)</option>
              <option value="Referal (Rujukan)">Referal (Dirujuk ke Lembaga Lain)</option>
              <option value="Drop Out">Drop Out (Meninggalkan Asrama)</option>
              <option value="Ditolak (Tidak Memenuhi Syarat)">Ditolak</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-amber-950 mb-1">
              Alasan Terminasi / Ringkasan Rujukan
            </label>
            <textarea
              rows={4}
              value={fd.terminasiAlasan || ''}
              onChange={(e) => onChangeField('terminasiAlasan', e.target.value)}
              className="w-full rounded-lg border border-amber-300 p-3 text-sm focus:ring-2 focus:ring-amber-500 bg-white text-slate-800"
              placeholder="Jelaskan alasan terminasi (misal: telah menyelesaikan pelatihan vokasional dan reintegrasi keluarga; atau dirujuk ke RSUD / Sentra Terpadu)..."
            />
          </div>

          <div className="flex items-center gap-2 text-xs text-amber-900 bg-amber-100/60 p-3 rounded-lg border border-amber-200">
            <CheckCircle2 className="w-4 h-4 text-amber-700 shrink-0" />
            <span>
              Perubahan status kasus di sini secara otomatis memperbarui status global anak di seluruh sistem rekam medis sosial.
            </span>
          </div>
        </div>
      </div>

      {/* 5. Indikator Bimbingan Lanjut (Aftercare): Keberlanjutan Sekolah Formal & Non-Formal (PKBM) */}
      <div className="bg-linear-to-br from-emerald-50/70 via-teal-50/50 to-sky-50/70 rounded-2xl border-2 border-emerald-300 p-6 space-y-5 shadow-xs">
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-emerald-200/80 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-emerald-950">
                  5. Indikator Bimbingan Lanjut (Aftercare): Keberlanjutan Sekolah
                </h3>
                {isSekolah && (
                  <span className="bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-1 shadow-2xs">
                    <CheckCircle2 className="w-3 h-3" /> Bersekolah Terverifikasi
                  </span>
                )}
              </div>
              <p className="text-xs text-emerald-800 mt-0.5">
                Pemantauan hak pendidikan purna binaan (Reintegrasi sosial): Sekolah Formal (SD/SMP/SMA/SMK) atau Non-Formal (PKBM Paket A/B/C).
              </p>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] font-bold text-emerald-900">Preset Cepat:</span>
            <button
              type="button"
              onClick={() => {
                onChangeField('aftercareStatusPendidikan', 'Pendidikan Non-Formal (PKBM)');
                onChangeField('aftercareJenjang', 'Paket B (Setara SMP)');
                onChangeField('aftercareStatusSiswa', 'Aktif Bersekolah & Hadir Rutin');
              }}
              className="text-[11px] font-bold bg-white text-emerald-800 border border-emerald-300 hover:bg-emerald-100 px-2.5 py-1 rounded-lg transition shadow-2xs"
            >
              + PKBM Paket B
            </button>
            <button
              type="button"
              onClick={() => {
                onChangeField('aftercareStatusPendidikan', 'Pendidikan Non-Formal (PKBM)');
                onChangeField('aftercareJenjang', 'Paket C (Setara SMA)');
                onChangeField('aftercareStatusSiswa', 'Aktif Bersekolah & Hadir Rutin');
              }}
              className="text-[11px] font-bold bg-white text-emerald-800 border border-emerald-300 hover:bg-emerald-100 px-2.5 py-1 rounded-lg transition shadow-2xs"
            >
              + PKBM Paket C
            </button>
            <button
              type="button"
              onClick={() => {
                onChangeField('aftercareStatusPendidikan', 'Sekolah Formal');
                onChangeField('aftercareJenjang', 'SMK Sederajat');
                onChangeField('aftercareStatusSiswa', 'Aktif Bersekolah & Hadir Rutin');
              }}
              className="text-[11px] font-bold bg-white text-sky-800 border border-sky-300 hover:bg-sky-100 px-2.5 py-1 rounded-lg transition shadow-2xs"
            >
              + Sekolah Formal
            </button>
          </div>
        </div>

        {/* Input Fields Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Jalur Pendidikan */}
          <div>
            <label className="block text-xs font-bold text-emerald-950 mb-1.5 flex items-center gap-1.5">
              <School className="w-3.5 h-3.5 text-emerald-700" />
              A. Jalur Pendidikan Aftercare
            </label>
            <select
              value={fd.aftercareStatusPendidikan || ''}
              onChange={(e) => onChangeField('aftercareStatusPendidikan', e.target.value)}
              className="w-full rounded-xl border-2 border-emerald-300 p-2.5 text-xs font-bold text-emerald-950 bg-white focus:ring-2 focus:ring-emerald-500 shadow-2xs"
            >
              <option value="">-- Pilih Jalur Pendidikan --</option>
              <option value="Sekolah Formal">Sekolah Formal (SD/SMP/SMA/SMK)</option>
              <option value="Pendidikan Non-Formal (PKBM)">Pendidikan Non-Formal (PKBM Paket A/B/C)</option>
              <option value="Pendidikan Vokasional / Magang">Pendidikan Vokasional / Balai Latihan Kerja (BLK)</option>
              <option value="Belum Melanjutkan Sekolah (Proses Advokasi)">Belum Melanjutkan Sekolah (Proses Advokasi Peksos)</option>
              <option value="Bekerja Mandiri / Wirausaha (Tidak Melanjutkan)">Bekerja Mandiri / Wirausaha (Tidak Melanjutkan)</option>
            </select>
          </div>

          {/* Jenjang / Paket Belajar */}
          <div>
            <label className="block text-xs font-bold text-emerald-950 mb-1.5 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-emerald-700" />
              B. Jenjang / Paket Kesetaraan
            </label>
            <select
              value={fd.aftercareJenjang || ''}
              onChange={(e) => onChangeField('aftercareJenjang', e.target.value)}
              className="w-full rounded-xl border-2 border-emerald-300 p-2.5 text-xs font-bold text-emerald-950 bg-white focus:ring-2 focus:ring-emerald-500 shadow-2xs"
            >
              <option value="">-- Pilih Jenjang / Tingkat --</option>
              <option value="SD / MI (Formal)">SD / MI (Formal)</option>
              <option value="SMP / MTs (Formal)">SMP / MTs (Formal)</option>
              <option value="SMA / MA (Formal)">SMA / MA (Formal)</option>
              <option value="SMK Sederajat (Formal)">SMK Sederajat (Formal Vokasional)</option>
              <option value="Paket A (Setara SD - PKBM)">Paket A (Setara SD - PKBM)</option>
              <option value="Paket B (Setara SMP - PKBM)">Paket B (Setara SMP - PKBM)</option>
              <option value="Paket C (Setara SMA - PKBM)">Paket C (Setara SMA/SMK - PKBM)</option>
              <option value="Pelatihan Vokasi Bersertifikat">Pelatihan Vokasi Bersertifikat</option>
            </select>
          </div>

          {/* Status Keaktifan Belajar */}
          <div>
            <label className="block text-xs font-bold text-emerald-950 mb-1.5 flex items-center gap-1.5">
              <FileCheck className="w-3.5 h-3.5 text-emerald-700" />
              C. Status Keaktifan Belajar
            </label>
            <select
              value={fd.aftercareStatusSiswa || ''}
              onChange={(e) => onChangeField('aftercareStatusSiswa', e.target.value)}
              className="w-full rounded-xl border-2 border-emerald-300 p-2.5 text-xs font-bold text-emerald-950 bg-white focus:ring-2 focus:ring-emerald-500 shadow-2xs"
            >
              <option value="">-- Status Keaktifan Siswa --</option>
              <option value="Aktif Bersekolah & Hadir Rutin">Aktif Bersekolah & Hadir Rutin (Kooperatif)</option>
              <option value="Sedang Proses Pendaftaran / Registrasi">Sedang Proses Pendaftaran / Registrasi Berkas</option>
              <option value="Terkendala Biaya / NISN / Ijazah">Terkendala (Biaya/Transportasi/NISN/Ijazah)</option>
              <option value="Mangkir / Memerlukan Kunjungan Rumah">Mangkir / Memerlukan Home Visit Khusus</option>
              <option value="Lulus Ujian Kesetaraan">Lulus Ujian Kesetaraan / Ujian Akhir</option>
            </select>
          </div>

        </div>

        {/* Nama Sekolah / PKBM & Detail Lembaga */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-emerald-950 mb-1">
              D. Nama Satuan Pendidikan Formal / Lembaga PKBM
            </label>
            <input
              type="text"
              value={fd.aftercareNamaSekolah || ''}
              onChange={(e) => onChangeField('aftercareNamaSekolah', e.target.value)}
              placeholder="Contoh: PKBM Mandiri Sejahtera Kab. Bandung / SMP Negeri 2 Cileunyi / dsb."
              className="w-full rounded-xl border border-emerald-300 p-2.5 text-xs text-slate-800 bg-white focus:ring-2 focus:ring-emerald-500 shadow-2xs"
            />
            <p className="text-[11px] text-emerald-800 mt-1">
              Sebutkan nama jelas sekolah formal atau lembaga PKBM tempat anak terdaftar/melanjutkan studi.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-emerald-950 mb-1">
              E. Catatan & Log Pemantauan Peksos (*Aftercare Monitoring Log*)
            </label>
            <textarea
              rows={3}
              value={fd.aftercareCatatanPendidikan || ''}
              onChange={(e) => onChangeField('aftercareCatatanPendidikan', e.target.value)}
              placeholder="Tuliskan hasil pemantauan berkala (frekuensi kehadiran, koordinasi dengan tutor PKBM/sekolah, kepemilikan KIP/PIP, dan kendala pengasuhan di rumah)..."
              className="w-full rounded-xl border border-emerald-300 p-2.5 text-xs text-slate-800 bg-white focus:ring-2 focus:ring-emerald-500 shadow-2xs"
            />
          </div>
        </div>

        {/* Information Banner */}
        <div className="flex items-center gap-2.5 text-xs text-emerald-900 bg-emerald-100/70 p-3 rounded-xl border border-emerald-300">
          <Sparkles className="w-4 h-4 text-emerald-700 shrink-0" />
          <span className="leading-relaxed">
            <strong>Indikator Keberhasilan Aftercare:</strong> Anak yang kembali bersekolah (baik di sekolah formal maupun PKBM kesetaraan) mencerminkan tuntasnya pemulihan hak dasar anak dan keberhasilan reintegrasi sosial purna binaan. Data ini akan dicantumkan secara otomatis pada Laporan Sosial (Lapsos) resmi.
          </span>
        </div>

      </div>

      {/* 6. Buku Pantau Pasca-Binaan (Aftercare Follow-Up Logbook) */}
      <div className="bg-white rounded-2xl border-2 border-slate-300 p-6 space-y-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center shadow-xs">
              <ClipboardList className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span>6. Buku Pantau Pasca-Binaan</span>
                <span className="bg-slate-100 text-slate-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-slate-300">
                  Aftercare Follow-Up Logbook
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Pelacakan terstruktur pasca-terminasi (Bulan ke-1, 3, 6, 12) guna memastikan stabilitas kemandirian dan mencegah kekambuhan (relaps).
              </p>
            </div>
          </div>

          <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200">
            Total Pemantauan: <strong>{(fd.aftercareFollowUps || []).length} Catatan</strong>
          </span>
        </div>

        {/* Form Tambah Catatan Pemantauan Aftercare */}
        <form onSubmit={handleAddFollowUp} className="bg-linear-to-br from-slate-50 to-emerald-50/30 p-4 rounded-xl border border-emerald-200/80 space-y-3.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
            <Plus className="w-4 h-4 text-emerald-600" />
            <span>Formulir Entri Pemantauan Berkala Pasca-Terminasi:</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Tanggal */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Tanggal Pemantauan
              </label>
              <input
                type="date"
                value={followUpTanggal}
                onChange={(e) => setFollowUpTanggal(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Periode */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Tahap / Periode
              </label>
              <select
                value={followUpPeriode}
                onChange={(e) => setFollowUpPeriode(e.target.value as AftercarePeriod)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs font-bold bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
              >
                <option value="Bulan ke-1">Bulan ke-1 (Transisi Awal)</option>
                <option value="Bulan ke-3">Bulan ke-3 (Stabilisasi Belajar/Kerja)</option>
                <option value="Bulan ke-6">Bulan ke-6 (Kemandirian Berkelanjutan)</option>
                <option value="Bulan ke-12">Bulan ke-12 (Evaluasi Tahunan)</option>
                <option value="Pemantauan Insidental">Pemantauan Insidental (Kasus Mendesak)</option>
              </select>
            </div>

            {/* Metode Kontak */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Metode Kontak
              </label>
              <select
                value={followUpMetode}
                onChange={(e) => setFollowUpMetode(e.target.value as AftercareContactMethod)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
              >
                <option value="Home Visit (Kunjungan Rumah)">Home Visit (Kunjungan Rumah)</option>
                <option value="Panggilan Telepon / Video Call">Panggilan Telepon / Video Call</option>
                <option value="Kunjungan ke Sentra / Balai">Kunjungan ke Sentra / Balai</option>
                <option value="Laporan Mitra PKBM / Tempat Magang">Laporan Mitra PKBM / Tempat Magang</option>
              </select>
            </div>

            {/* Status Reintegrasi */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Status Reintegrasi Anak
              </label>
              <select
                value={followUpStatus}
                onChange={(e) => setFollowUpStatus(e.target.value as ReintegrationStatus)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs font-bold bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
              >
                <option value="Mandiri Stabil">Mandiri Stabil (Kondisi Aman)</option>
                <option value="Dalam Pendampingan">Dalam Pendampingan (Perlu Support)</option>
                <option value="Berisiko Relaps / Rentan">Berisiko Relaps / Rentan (Waspada)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Kondisi Sekolah / Pekerjaan Anak
              </label>
              <input
                type="text"
                value={followUpSekolahKerja}
                onChange={(e) => setFollowUpSekolahKerja(e.target.value)}
                placeholder="Contoh: Hadir PKBM Paket B setiap Selasa-Kamis, atau magang di bengkel motor mitra..."
                className="w-full rounded-lg border border-slate-300 p-2 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Kondisi Keluarga & Lingkungan Rumah
              </label>
              <input
                type="text"
                value={followUpKeluarga}
                onChange={(e) => setFollowUpKeluarga(e.target.value)}
                placeholder="Contoh: Hubungan dengan ibu harmonis, tinggal bersama keluarga paman, tidak ada friksi..."
                className="w-full rounded-lg border border-slate-300 p-2 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              Catatan Dinamika Peksos & Rekomendasi Tindak Lanjut
            </label>
            <textarea
              rows={2}
              value={followUpCatatan}
              onChange={(e) => setFollowUpCatatan(e.target.value)}
              placeholder="Jelaskan temuan pemantauan: kepatuhan jam malam, motivasi, kendala biaya, serta langkah penanganan lanjutan..."
              className="w-full rounded-lg border border-slate-300 p-2 text-xs bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Simpan Catatan Pemantauan Aftercare</span>
            </button>
          </div>
        </form>

        {/* Tabel Riwayat Pemantauan Aftercare */}
        <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
          {(fd.aftercareFollowUps || []).length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-[11px] text-slate-700 uppercase font-bold">
                  <tr>
                    <th className="py-2.5 px-3 w-28">Tanggal & Tahap</th>
                    <th className="py-2.5 px-3 w-40">Metode & Status</th>
                    <th className="py-2.5 px-3">Kondisi Sekolah/Kerja & Keluarga</th>
                    <th className="py-2.5 px-3">Catatan & Analisis Peksos</th>
                    <th className="py-2.5 px-3 w-16 text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {(fd.aftercareFollowUps || []).map((item) => {
                    const statusColor = 
                      item.statusReintegrasi === 'Mandiri Stabil'
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                        : item.statusReintegrasi === 'Dalam Pendampingan'
                        ? 'bg-amber-100 text-amber-800 border-amber-300'
                        : 'bg-rose-100 text-rose-800 border-rose-300';

                    return (
                      <tr key={item.id} className="hover:bg-slate-50/70 transition">
                        <td className="py-3 px-3 align-top whitespace-nowrap">
                          <span className="font-bold text-slate-900 block">{item.tanggal}</span>
                          <span className="text-[10px] text-indigo-700 font-semibold bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200 mt-1 inline-block">
                            {item.periode}
                          </span>
                        </td>
                        <td className="py-3 px-3 align-top">
                          <div className="text-[11px] text-slate-700 font-medium mb-1">
                            {item.metodeKontak}
                          </div>
                          <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusColor}`}>
                            {item.statusReintegrasi}
                          </span>
                        </td>
                        <td className="py-3 px-3 align-top text-[11px] space-y-1">
                          <div className="text-slate-800">
                            <strong>Sekolah/Kerja:</strong> {item.kondisiSekolahKerja}
                          </div>
                          <div className="text-slate-600">
                            <strong>Keluarga:</strong> {item.kondisiKeluarga}
                          </div>
                        </td>
                        <td className="py-3 px-3 align-top text-[11px] text-slate-700 leading-relaxed">
                          {item.catatanPeksos}
                        </td>
                        <td className="py-3 px-3 align-top text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveFollowUp(item.id)}
                            className="text-rose-500 hover:text-rose-700 p-1 rounded hover:bg-rose-50 transition"
                            title="Hapus Catatan"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-8 text-center text-xs text-slate-500 italic bg-white">
              Belum ada catatan buku pantau pasca-binaan yang diinput. Tambahkan log pemantauan berkala pada formulir di atas.
            </div>
          )}
        </div>
      </div>

      {/* Modal Rubrik Panca Karakter Jabar */}
      <PancaKarakterModal
        isOpen={isPancaKarakterOpen}
        onClose={() => setIsPancaKarakterOpen(false)}
        client={client}
        onChangeField={onChangeField}
        peksosName={peksosName}
        onShowToast={onShowToast}
      />
    </div>
  );
};

