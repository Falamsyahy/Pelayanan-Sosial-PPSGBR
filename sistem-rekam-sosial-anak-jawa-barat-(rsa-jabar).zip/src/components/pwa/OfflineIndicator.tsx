import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2.5 rounded-xl bg-amber-600 text-white px-3.5 py-2 text-xs font-bold shadow-xl border border-amber-400 animate-in fade-in slide-in-from-bottom-3 duration-200">
      <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping shrink-0" />
      <WifiOff className="w-4 h-4 text-amber-100 shrink-0" />
      <span>Mode Luar Jaringan (Offline) — Data lokal tersimpan aman di perangkat</span>
    </div>
  );
};
