import React, { useState, useRef, useEffect } from 'react';
import { 
  Users, 
  Plus, 
  Trash2, 
  Download, 
  Save, 
  RotateCcw, 
  FileText, 
  HelpCircle, 
  CheckCircle2, 
  Move,
  Edit2,
  Heart,
  Zap,
  Scissors,
  X
} from 'lucide-react';
import { Client } from '../../types';

export interface GenogramNode {
  id: string;
  name: string;
  role: string;
  gender: 'Laki-laki' | 'Perempuan';
  isClient: boolean;
  isDeceased: boolean;
  age?: string | number;
  notes?: string;
  x: number;
  y: number;
  generation: 1 | 2 | 3;
}

export interface GenogramLink {
  id: string;
  fromId: string;
  toId: string;
  type: 'pernikahan' | 'perceraian' | 'pisah' | 'orangtua_anak' | 'harmonis' | 'konflik' | 'putus_kontak';
  label?: string;
}

export interface GenogramState {
  nodes: GenogramNode[];
  links: GenogramLink[];
}

interface GenogramBuilderProps {
  client: Client;
  onSaveDiagram: (data: GenogramState, imagePng?: string) => void;
  onSyncCatatan?: (catatan: string) => void;
  onShowToast?: (msg: string, type?: 'success' | 'error') => void;
}

export const GenogramBuilder: React.FC<GenogramBuilderProps> = ({
  client,
  onSaveDiagram,
  onSyncCatatan,
  onShowToast
}) => {
  const fd = client.formData;
  const svgRef = useRef<SVGSVGElement>(null);

  // Default initial 3-generation layout based on client
  const getDefaultState = (): GenogramState => {
    const isClientMale = client.gender === 'Laki-laki';
    const guardianName = fd.namaWali || 'Wali / Ayah';

    const defaultNodes: GenogramNode[] = [
      // Generasi 1: Kakek & Nenek Paternal (Ayah)
      { id: 'g1-p-m', name: 'Kakek Paternal', role: 'Kakek (Ayah)', gender: 'Laki-laki', isClient: false, isDeceased: true, age: '74 (Alm)', notes: 'Petani', x: 120, y: 70, generation: 1 },
      { id: 'g1-p-f', name: 'Nenek Paternal', role: 'Nenek (Ayah)', gender: 'Perempuan', isClient: false, isDeceased: false, age: '68', notes: 'Ibu rumah tangga', x: 230, y: 70, generation: 1 },
      
      // Generasi 1: Kakek & Nenek Maternal (Ibu)
      { id: 'g1-m-m', name: 'Kakek Maternal', role: 'Kakek (Ibu)', gender: 'Laki-laki', isClient: false, isDeceased: false, age: '70', notes: 'Buruh tani', x: 550, y: 70, generation: 1 },
      { id: 'g1-m-f', name: 'Nenek Maternal', role: 'Nenek (Ibu)', gender: 'Perempuan', isClient: false, isDeceased: false, age: '65', notes: 'Pengasuh masa kecil', x: 660, y: 70, generation: 1 },

      // Generasi 2: Orang Tua
      { id: 'g2-f', name: guardianName.includes('Ibu') ? 'Ayah Kandung' : guardianName, role: 'Ayah', gender: 'Laki-laki', isClient: false, isDeceased: false, age: '45', notes: fd.pekerjaanOrangTua || 'Buruh harian', x: 270, y: 220, generation: 2 },
      { id: 'g2-m', name: 'Ibu Kandung', role: 'Ibu', gender: 'Perempuan', isClient: false, isDeceased: false, age: '41', notes: 'Pedagang asongan', x: 510, y: 220, generation: 2 },

      // Generasi 3: Klien & Saudara
      { id: 'g3-client', name: client.nama, role: 'Anak Binaan (Klien)', gender: isClientMale ? 'Laki-laki' : 'Perempuan', isClient: true, isDeceased: false, age: client.umur || '16', notes: `Jurusan ${fd.jurusan || 'Vokasi'}`, x: 390, y: 380, generation: 3 },
      { id: 'g3-s1', name: 'Kakak Kandung', role: 'Kakak (Sulung)', gender: 'Laki-laki', isClient: false, isDeceased: false, age: '19', notes: 'Bekerja serabutan', x: 250, y: 380, generation: 3 },
      { id: 'g3-s2', name: 'Adik Kandung', role: 'Adik (Bungsu)', gender: 'Perempuan', isClient: false, isDeceased: false, age: '10', notes: 'Masih SD', x: 530, y: 380, generation: 3 },
    ];

    const defaultLinks: GenogramLink[] = [
      // Pernikahan Kakek Nenek
      { id: 'l-g1-p', fromId: 'g1-p-m', toId: 'g1-p-f', type: 'pernikahan' },
      { id: 'l-g1-m', fromId: 'g1-m-m', toId: 'g1-m-f', type: 'pernikahan' },
      
      // Orang Tua
      { id: 'l-parents', fromId: 'g2-f', toId: 'g2-m', type: 'perceraian', label: 'Cerai Hidup (2020)' },
      
      // Relasi Emosional
      { id: 'l-rel-mother-client', fromId: 'g2-m', toId: 'g3-client', type: 'harmonis', label: 'Dukungan Erat' },
      { id: 'l-rel-father-client', fromId: 'g2-f', toId: 'g3-client', type: 'konflik', label: 'Pernah Bertengkar' },
      { id: 'l-rel-grandma-client', fromId: 'g1-m-f', toId: 'g3-client', type: 'harmonis', label: 'Figur Pengasuh' }
    ];

    return { nodes: defaultNodes, links: defaultLinks };
  };

  // State
  const [diagramState, setDiagramState] = useState<GenogramState>(() => {
    if (fd.genogramData && fd.genogramData.nodes && fd.genogramData.nodes.length > 0) {
      return fd.genogramData;
    }
    return getDefaultState();
  });

  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedLinkId, setSelectedLinkId] = useState<string | null>(null);
  const [isEditingNode, setIsEditingNode] = useState(false);
  const [isAddingNode, setIsAddingNode] = useState(false);
  const [isAddingLink, setIsAddingLink] = useState(false);
  const [isExportingImage, setIsExportingImage] = useState(false);

  // New Node Form State
  const [newNodeName, setNewNodeName] = useState('');
  const [newNodeRole, setNewNodeRole] = useState('Paman / Bibi');
  const [newNodeGender, setNewNodeGender] = useState<'Laki-laki' | 'Perempuan'>('Laki-laki');
  const [newNodeGen, setNewNodeGen] = useState<1 | 2 | 3>(2);
  const [newNodeAge, setNewNodeAge] = useState('');
  const [newNodeDeceased, setNewNodeDeceased] = useState(false);
  const [newNodeNotes, setNewNodeNotes] = useState('');

  // New Link Form State
  const [newLinkFrom, setNewLinkFrom] = useState('');
  const [newLinkTo, setNewLinkTo] = useState('');
  const [newLinkType, setNewLinkType] = useState<GenogramLink['type']>('harmonis');
  const [newLinkLabel, setNewLinkLabel] = useState('');

  // Dragging state
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Handle Drag Start
  const handleMouseDown = (nodeId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const node = diagramState.nodes.find(n => n.id === nodeId);
    if (!node || !svgRef.current) return;

    const rect = svgRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    setDraggingNodeId(nodeId);
    setDragOffset({ x: mouseX - node.x, y: mouseY - node.y });
    setSelectedNodeId(nodeId);
  };

  // Handle Touch Start for Mobile / Tablet
  const handleTouchStart = (nodeId: string, e: React.TouchEvent) => {
    e.stopPropagation();
    const node = diagramState.nodes.find(n => n.id === nodeId);
    if (!node || !svgRef.current || e.touches.length === 0) return;

    const touch = e.touches[0];
    const rect = svgRef.current.getBoundingClientRect();
    const touchX = touch.clientX - rect.left;
    const touchY = touch.clientY - rect.top;

    setDraggingNodeId(nodeId);
    setDragOffset({ x: touchX - node.x, y: touchY - node.y });
    setSelectedNodeId(nodeId);
  };

  // Handle Mouse Move
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggingNodeId || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const newX = Math.max(40, Math.min(rect.width - 40, e.clientX - rect.left - dragOffset.x));
    const newY = Math.max(40, Math.min(rect.height - 40, e.clientY - rect.top - dragOffset.y));

    setDiagramState(prev => ({
      ...prev,
      nodes: prev.nodes.map(n => n.id === draggingNodeId ? { ...n, x: newX, y: newY } : n)
    }));
  };

  // Handle Touch Move
  const handleTouchMove = (e: React.TouchEvent) => {
    if (!draggingNodeId || !svgRef.current || e.touches.length === 0) return;
    const touch = e.touches[0];
    const rect = svgRef.current.getBoundingClientRect();
    const newX = Math.max(40, Math.min(rect.width - 40, touch.clientX - rect.left - dragOffset.x));
    const newY = Math.max(40, Math.min(rect.height - 40, touch.clientY - rect.top - dragOffset.y));

    setDiagramState(prev => ({
      ...prev,
      nodes: prev.nodes.map(n => n.id === draggingNodeId ? { ...n, x: newX, y: newY } : n)
    }));
  };

  const handleEndDrag = () => {
    setDraggingNodeId(null);
  };

  // Add Node
  const handleAddNode = () => {
    if (!newNodeName.trim()) {
      alert('Nama anggota keluarga wajib diisi.');
      return;
    }

    const defaultY = newNodeGen === 1 ? 80 : newNodeGen === 2 ? 220 : 380;
    const newNode: GenogramNode = {
      id: `node-${Date.now()}`,
      name: newNodeName.trim(),
      role: newNodeRole,
      gender: newNodeGender,
      isClient: false,
      isDeceased: newNodeDeceased,
      age: newNodeAge || '-',
      notes: newNodeNotes,
      x: 350 + (Math.random() * 80 - 40),
      y: defaultY + (Math.random() * 40 - 20),
      generation: newNodeGen
    };

    setDiagramState(prev => ({
      ...prev,
      nodes: [...prev.nodes, newNode]
    }));

    setNewNodeName('');
    setNewNodeAge('');
    setNewNodeNotes('');
    setIsAddingNode(false);
    if (onShowToast) onShowToast(`Anggota keluarga "${newNode.name}" berhasil ditambahkan ke Genogram.`, 'success');
  };

  // Delete Selected Node
  const handleDeleteNode = (id: string) => {
    const node = diagramState.nodes.find(n => n.id === id);
    if (node?.isClient) {
      alert('Node Klien (Identified Patient) tidak dapat dihapus.');
      return;
    }
    setDiagramState(prev => ({
      nodes: prev.nodes.filter(n => n.id !== id),
      links: prev.links.filter(l => l.fromId !== id && l.toId !== id)
    }));
    if (selectedNodeId === id) setSelectedNodeId(null);
  };

  // Add Link
  const handleAddLink = () => {
    if (!newLinkFrom || !newLinkTo) {
      alert('Pilih dua anggota keluarga yang akan dihubungkan.');
      return;
    }
    if (newLinkFrom === newLinkTo) {
      alert('Tidak dapat menghubungkan anggota keluarga dengan dirinya sendiri.');
      return;
    }

    const newLink: GenogramLink = {
      id: `link-${Date.now()}`,
      fromId: newLinkFrom,
      toId: newLinkTo,
      type: newLinkType,
      label: newLinkLabel.trim() || undefined
    };

    setDiagramState(prev => ({
      ...prev,
      links: [...prev.links, newLink]
    }));

    setNewLinkLabel('');
    setIsAddingLink(false);
    if (onShowToast) onShowToast('Garis hubungan relasi keluarga berhasil ditambahkan.', 'success');
  };

  // Delete Link
  const handleDeleteLink = (id: string) => {
    setDiagramState(prev => ({
      ...prev,
      links: prev.links.filter(l => l.id !== id)
    }));
    if (selectedLinkId === id) setSelectedLinkId(null);
  };

  // Reset to default
  const handleReset = () => {
    if (window.confirm('Susun ulang diagram ke template standar 3 generasi untuk klien ini? Perubahan posisi kustom akan direset.')) {
      setDiagramState(getDefaultState());
      if (onShowToast) onShowToast('Genogram berhasil direset ke susunan 3 generasi standar.', 'success');
    }
  };

  // Auto Generate Summary Narrative for Asesmen Field
  const generateNarrativeSummary = () => {
    const g1 = diagramState.nodes.filter(n => n.generation === 1);
    const g2 = diagramState.nodes.filter(n => n.generation === 2);
    const g3 = diagramState.nodes.filter(n => n.generation === 3);

    const deceased = diagramState.nodes.filter(n => n.isDeceased).map(n => `${n.role} (${n.name})`);
    const conflictLinks = diagramState.links.filter(l => l.type === 'konflik');
    const harmonisLinks = diagramState.links.filter(l => l.type === 'harmonis');
    const divorcedLinks = diagramState.links.filter(l => l.type === 'perceraian' || l.type === 'pisah');

    let summary = `Berdasarkan pemetaan Genogram 3 generasi, struktur keluarga ${client.nama} terdiri dari ${diagramState.nodes.length} figur keluarga (${g1.length} di Gen I, ${g2.length} di Gen II, dan ${g3.length} di Gen III). `;
    
    if (deceased.length > 0) {
      summary += `Terdapat anggota keluarga yang telah wafat: ${deceased.join(', ')}. `;
    }

    if (divorcedLinks.length > 0) {
      summary += `Ditemukan riwayat perceraian / perpisahan orang tua yang mempengaruhi stabilitas pengasuhan masa kecil. `;
    }

    if (harmonisLinks.length > 0) {
      const harmPartners = harmonisLinks.map(l => {
        const from = diagramState.nodes.find(n => n.id === l.fromId)?.name || 'Keluarga';
        const to = diagramState.nodes.find(n => n.id === l.toId)?.name || 'Klien';
        return `${from} dengan ${to}`;
      });
      summary += `Hubungan positif dan suportif terjalin antara: ${harmPartners.join('; ')}. `;
    }

    if (conflictLinks.length > 0) {
      const confPartners = conflictLinks.map(l => {
        const from = diagramState.nodes.find(n => n.id === l.fromId)?.name || 'Keluarga';
        const to = diagramState.nodes.find(n => n.id === l.toId)?.name || 'Klien';
        return `${from} dan ${to}`;
      });
      summary += `Pekerja sosial perlu memitigasi sumber ketegangan relasi antara: ${confPartners.join('; ')}. `;
    }

    summary += `Secara umum, anak membutuhkan penguatan peran figur asuh pengganti dan pemulihan relasi keluarga sebelum terminasi.`;

    if (onSyncCatatan) {
      onSyncCatatan(summary);
      if (onShowToast) onShowToast('Catatan temuan Genogram berhasil dirangkum ke Form Asesmen!', 'success');
    }
    return summary;
  };

  // Convert SVG to PNG & Download / Save
  const exportSvgToPng = (andSaveToDoc = false) => {
    if (!svgRef.current) return;
    setIsExportingImage(true);

    try {
      const svgElement = svgRef.current;
      const svgString = new XMLSerializer().serializeToString(svgElement);
      const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
      const URL = window.URL || window.webkitURL || window;
      const blobURL = URL.createObjectURL(svgBlob);
      
      const image = new Image();
      image.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = svgElement.clientWidth * 2 || 1600;
        canvas.height = svgElement.clientHeight * 2 || 1000;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

          const pngDataUrl = canvas.toDataURL('image/png');

          // Download File to user
          const link = document.createElement('a');
          link.download = `Genogram_${(client.nama || 'Klien').replace(/[^a-zA-Z0-9_-]/g, '_')}_3Generasi.png`;
          link.href = pngDataUrl;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          // Save to diagram state
          onSaveDiagram(diagramState, pngDataUrl);

          if (onShowToast) onShowToast('Gambar diagram Genogram (PNG) berhasil diunduh dan disimpan ke data klien!', 'success');
        }
        URL.revokeObjectURL(blobURL);
        setIsExportingImage(false);
      };

      image.src = blobURL;
    } catch (err) {
      console.error(err);
      setIsExportingImage(false);
      if (onShowToast) onShowToast('Gagal mengunduh gambar diagram Genogram.', 'error');
    }
  };

  // Save Diagram State
  const handleSaveStateOnly = () => {
    onSaveDiagram(diagramState);
    if (onShowToast) onShowToast('Posisi dan relasi Genogram berhasil disimpan ke rekam medis sosial.', 'success');
  };

  return (
    <div className="bg-slate-900 text-white rounded-2xl border-2 border-indigo-400/40 p-4 sm:p-5 shadow-xl space-y-4">
      {/* Top Header & Action Controls */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-indigo-600 rounded-lg text-white">
              <Users className="w-4 h-4" />
            </span>
            <h4 className="font-extrabold text-sm sm:text-base text-white tracking-wide">
              Visualisasi Genogram Interaktif (3 Generasi)
            </h4>
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-400/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
              Drag & Drop Canvas
            </span>
          </div>
          <p className="text-[11px] text-slate-300 mt-1">
            Petakan pohon keluarga {client.nama}. Geser simbol anggota keluarga (drag) untuk mengatur tata letak, tambah relasi, dan unduh gambar diagram.
          </p>
        </div>

        {/* Toolbar Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setIsAddingNode(true)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1 transition shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah Anggota</span>
          </button>

          <button
            type="button"
            onClick={() => setIsAddingLink(true)}
            className="bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-indigo-500/40 font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1 transition"
          >
            <Heart className="w-3.5 h-3.5" />
            <span>Hubungan Relasi</span>
          </button>

          <button
            type="button"
            onClick={generateNarrativeSummary}
            className="bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1 transition shadow-xs"
            title="Rangkum hasil pembacaan genogram ke kolom Catatan Asesmen"
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Rangkum Narasi</span>
          </button>

          <button
            type="button"
            onClick={() => exportSvgToPng(true)}
            disabled={isExportingImage}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition shadow-xs disabled:opacity-50"
            title="Unduh diagram beresolusi tinggi dalam format PNG"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExportingImage ? 'Memproses...' : 'Unduh Gambar (PNG)'}</span>
          </button>

          <button
            type="button"
            onClick={handleSaveStateOnly}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs px-2.5 py-1.5 rounded-xl flex items-center gap-1 transition"
            title="Simpan posisi node dan konfigurasi diagram saat ini"
          >
            <Save className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Simpan</span>
          </button>

          <button
            type="button"
            onClick={handleReset}
            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
            title="Reset ke struktur 3 generasi awal"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Generation Watermark Indicator */}
      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 px-2 py-1 bg-slate-800/60 rounded-lg border border-slate-800">
        <span className="flex items-center gap-1">
          <Move className="w-3 h-3 text-indigo-400" /> Tips: Klik dan tahan simbol keluarga untuk menggeser posisinya di canvas
        </span>
        <span className="text-slate-400 hidden sm:inline">
          Generasi I (Kakek/Nenek) &rarr; Generasi II (Orang Tua) &rarr; Generasi III (Anak/Klien)
        </span>
      </div>

      {/* SVG Canvas Area */}
      <div className="relative bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-inner select-none">
        <svg
          ref={svgRef}
          className="w-full h-[480px] sm:h-[520px] cursor-crosshair"
          onMouseMove={handleMouseMove}
          onMouseUp={handleEndDrag}
          onMouseLeave={handleEndDrag}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleEndDrag}
        >
          {/* Grid Background Pattern */}
          <defs>
            <pattern id="genogramGrid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#1e293b" strokeWidth="0.8" />
            </pattern>
            {/* Arrow marker for direction */}
            <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#818cf8" />
            </marker>
          </defs>

          <rect width="100%" height="100%" fill="url(#genogramGrid)" />

          {/* Generation Background Bands */}
          <g opacity="0.35">
            <line x1="0" y1="150" x2="100%" y2="150" stroke="#334155" strokeDasharray="4 4" strokeWidth="1" />
            <text x="15" y="30" fill="#94a3b8" fontSize="11" fontWeight="bold" fontFamily="sans-serif">GENERASI I: Kakek & Nenek</text>
            
            <line x1="0" y1="310" x2="100%" y2="310" stroke="#334155" strokeDasharray="4 4" strokeWidth="1" />
            <text x="15" y="175" fill="#94a3b8" fontSize="11" fontWeight="bold" fontFamily="sans-serif">GENERASI II: Orang Tua & Wali</text>

            <text x="15" y="335" fill="#94a3b8" fontSize="11" fontWeight="bold" fontFamily="sans-serif">GENERASI III: Klien & Saudara Kandung</text>
          </g>

          {/* Render Relationships (Lines) */}
          {diagramState.links.map(link => {
            const fromNode = diagramState.nodes.find(n => n.id === link.fromId);
            const toNode = diagramState.nodes.find(n => n.id === link.toId);
            if (!fromNode || !toNode) return null;

            const isSelected = selectedLinkId === link.id;

            // Line style according to relationship type
            let strokeColor = '#94a3b8';
            let strokeWidth = 2;
            let strokeDasharray = 'none';

            if (link.type === 'pernikahan') {
              strokeColor = '#60a5fa'; // Blue solid
              strokeWidth = 2.5;
            } else if (link.type === 'perceraian') {
              strokeColor = '#f43f5e'; // Red with hash
              strokeWidth = 2.5;
            } else if (link.type === 'pisah') {
              strokeColor = '#fb923c'; // Orange
              strokeDasharray = '4 4';
              strokeWidth = 2;
            } else if (link.type === 'harmonis') {
              strokeColor = '#22c55e'; // Green solid thick
              strokeWidth = 4;
            } else if (link.type === 'konflik') {
              strokeColor = '#ef4444'; // Red zigzag
              strokeWidth = 3;
            } else if (link.type === 'putus_kontak') {
              strokeColor = '#a855f7'; // Purple dashed
              strokeDasharray = '6 6';
              strokeWidth = 2;
            }

            const midX = (fromNode.x + toNode.x) / 2;
            const midY = (fromNode.y + toNode.y) / 2;

            return (
              <g 
                key={link.id} 
                onClick={(e) => { e.stopPropagation(); setSelectedLinkId(link.id); }}
                className="cursor-pointer group"
              >
                {/* Main connector line */}
                {link.type === 'konflik' ? (
                  // Zigzag line simulation
                  <path
                    d={`M ${fromNode.x} ${fromNode.y} Q ${midX - 15} ${midY - 15}, ${midX} ${midY} T ${toNode.x} ${toNode.y}`}
                    stroke={strokeColor}
                    strokeWidth={strokeWidth}
                    fill="none"
                  />
                ) : (
                  <line
                    x1={fromNode.x}
                    y1={fromNode.y}
                    x2={toNode.x}
                    y2={toNode.y}
                    stroke={isSelected ? '#38bdf8' : strokeColor}
                    strokeWidth={isSelected ? strokeWidth + 2 : strokeWidth}
                    strokeDasharray={strokeDasharray}
                  />
                )}

                {/* Perceraian Slash symbol */}
                {link.type === 'perceraian' && (
                  <g transform={`translate(${midX}, ${midY})`}>
                    <line x1="-8" y1="-10" x2="-2" y2="10" stroke="#f43f5e" strokeWidth="3" />
                    <line x1="2" y1="-10" x2="8" y2="10" stroke="#f43f5e" strokeWidth="3" />
                  </g>
                )}

                {/* Pisah Slash symbol */}
                {link.type === 'pisah' && (
                  <g transform={`translate(${midX}, ${midY})`}>
                    <line x1="-4" y1="-10" x2="4" y2="10" stroke="#fb923c" strokeWidth="3" />
                  </g>
                )}

                {/* Label text if present */}
                {link.label && (
                  <g transform={`translate(${midX}, ${midY - 12})`}>
                    <rect x="-45" y="-10" width="90" height="18" rx="4" fill="#0f172a" fillOpacity="0.85" stroke="#334155" strokeWidth="1" />
                    <text textAnchor="middle" y="3" fill="#cbd5e1" fontSize="9" fontWeight="bold">
                      {link.label}
                    </text>
                  </g>
                )}
              </g>
            );
          })}

          {/* Render Member Nodes */}
          {diagramState.nodes.map(node => {
            const isSelected = selectedNodeId === node.id;
            const isMale = node.gender === 'Laki-laki';
            const size = node.isClient ? 48 : 40;
            const half = size / 2;

            return (
              <g
                key={node.id}
                transform={`translate(${node.x}, ${node.y})`}
                onMouseDown={(e) => handleMouseDown(node.id, e)}
                onTouchStart={(e) => handleTouchStart(node.id, e)}
                className="cursor-move select-none"
              >
                {/* Highlight Halo for Selected */}
                {isSelected && (
                  <circle r={half + 12} fill="#38bdf8" fillOpacity="0.2" stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="3 3" />
                )}

                {/* Client Glow Aura */}
                {node.isClient && (
                  <circle r={half + 8} fill="#3b82f6" fillOpacity="0.25" />
                )}

                {/* Node Symbol: Male = Square, Female = Circle */}
                {isMale ? (
                  // Square for Male
                  <g>
                    <rect
                      x={-half}
                      y={-half}
                      width={size}
                      height={size}
                      rx="4"
                      fill={node.isClient ? '#1e3a8a' : '#0f172a'}
                      stroke={node.isClient ? '#60a5fa' : '#94a3b8'}
                      strokeWidth={node.isClient ? 3 : 2}
                    />
                    {/* Double outline if Identified Patient (Klien) */}
                    {node.isClient && (
                      <rect
                        x={-half + 4}
                        y={-half + 4}
                        width={size - 8}
                        height={size - 8}
                        rx="2"
                        fill="none"
                        stroke="#93c5fd"
                        strokeWidth="1.5"
                      />
                    )}
                  </g>
                ) : (
                  // Circle for Female
                  <g>
                    <circle
                      r={half}
                      fill={node.isClient ? '#1e3a8a' : '#0f172a'}
                      stroke={node.isClient ? '#f472b6' : '#cbd5e1'}
                      strokeWidth={node.isClient ? 3 : 2}
                    />
                    {/* Double outline if Identified Patient (Klien) */}
                    {node.isClient && (
                      <circle
                        r={half - 4}
                        fill="none"
                        stroke="#fbcfe8"
                        strokeWidth="1.5"
                      />
                    )}
                  </g>
                )}

                {/* Deceased Cross (Silang X) if deceased */}
                {node.isDeceased && (
                  <g stroke="#ef4444" strokeWidth="2.5">
                    <line x1={-half + 6} y1={-half + 6} x2={half - 6} y2={half - 6} />
                    <line x1={half - 6} y1={-half + 6} x2={-half + 6} y2={half - 6} />
                  </g>
                )}

                {/* Age in center of symbol if alive */}
                {!node.isDeceased && node.age && (
                  <text
                    textAnchor="middle"
                    y="4"
                    fill="#f8fafc"
                    fontSize="11"
                    fontWeight="bold"
                    fontFamily="sans-serif"
                  >
                    {node.age}
                  </text>
                )}

                {/* Node Label Below */}
                <g transform={`translate(0, ${half + 16})`}>
                  <text
                    textAnchor="middle"
                    fill={node.isClient ? '#93c5fd' : '#f1f5f9'}
                    fontSize="11"
                    fontWeight={node.isClient ? 'bold' : '600'}
                    fontFamily="sans-serif"
                  >
                    {node.name}
                  </text>
                  <text
                    textAnchor="middle"
                    y="13"
                    fill="#94a3b8"
                    fontSize="9.5"
                    fontFamily="sans-serif"
                  >
                    {node.role} {node.isDeceased ? '(Alm)' : ''}
                  </text>
                  {node.notes && (
                    <text
                      textAnchor="middle"
                      y="24"
                      fill="#64748b"
                      fontSize="8.5"
                      fontFamily="sans-serif"
                      fontStyle="italic"
                    >
                      {node.notes.length > 22 ? `${node.notes.slice(0, 20)}...` : node.notes}
                    </text>
                  )}
                </g>
              </g>
            );
          })}
        </svg>

        {/* Selected Element Quick Action Floating Bar */}
        {(selectedNodeId || selectedLinkId) && (
          <div className="absolute bottom-3 left-3 right-3 sm:left-auto sm:right-3 bg-slate-900/90 border border-slate-700 backdrop-blur-md p-2.5 rounded-xl flex items-center justify-between gap-3 text-xs shadow-2xl animate-in fade-in">
            {selectedNodeId ? (
              <>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">
                    {diagramState.nodes.find(n => n.id === selectedNodeId)?.name}
                  </span>
                  <span className="text-slate-400">
                    ({diagramState.nodes.find(n => n.id === selectedNodeId)?.role})
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      const node = diagramState.nodes.find(n => n.id === selectedNodeId);
                      if (node) {
                        const newName = prompt('Ubah Nama Anggota Keluarga:', node.name);
                        if (newName && newName.trim()) {
                          setDiagramState(prev => ({
                            ...prev,
                            nodes: prev.nodes.map(n => n.id === selectedNodeId ? { ...n, name: newName.trim() } : n)
                          }));
                        }
                      }
                    }}
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg"
                    title="Ganti Nama"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteNode(selectedNodeId)}
                    className="p-1.5 bg-rose-900/80 hover:bg-rose-800 text-rose-200 rounded-lg"
                    title="Hapus Anggota Keluarga"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedNodeId(null)}
                    className="p-1.5 text-slate-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </>
            ) : selectedLinkId ? (
              <>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-300">Hubungan:</span>
                  <span className="text-indigo-300 uppercase font-bold text-[10px] bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800">
                    {diagramState.links.find(l => l.id === selectedLinkId)?.type}
                  </span>
                  {diagramState.links.find(l => l.id === selectedLinkId)?.label && (
                    <span className="text-slate-400 italic">
                      "{diagramState.links.find(l => l.id === selectedLinkId)?.label}"
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleDeleteLink(selectedLinkId)}
                    className="p-1.5 bg-rose-900/80 hover:bg-rose-800 text-rose-200 rounded-lg flex items-center gap-1 font-bold text-[11px]"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Hapus Hubungan
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedLinkId(null)}
                    className="p-1.5 text-slate-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </>
            ) : null}
          </div>
        )}
      </div>

      {/* Legend & Instructions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2 text-[10px] bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-slate-300">
        <div className="flex items-center gap-2">
          <div className="w-3.5 h-3.5 border-2 border-slate-400 rounded-xs bg-slate-900" />
          <span>Laki-laki</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3.5 h-3.5 border-2 border-slate-400 rounded-full bg-slate-900" />
          <span>Perempuan</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3.5 h-3.5 border-2 border-sky-400 rounded-xs bg-blue-950 ring-1 ring-sky-300" />
          <span className="text-sky-300 font-bold">Klien (IP)</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-rose-500 font-bold font-mono text-sm leading-none">&#10006;</span>
          <span>Meninggal</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-5 h-1 bg-green-500 rounded" />
          <span>Harmonis / Erat</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-5 h-1 bg-rose-500 rounded" />
          <span>Konflik / Tegang</span>
        </div>
      </div>

      {/* MODAL: Tambah Anggota Keluarga */}
      {isAddingNode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 text-white border border-slate-700 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <h5 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-indigo-400" /> Tambah Anggota Keluarga
              </h5>
              <button onClick={() => setIsAddingNode(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Nama Anggota Keluarga *</label>
                <input
                  type="text"
                  value={newNodeName}
                  onChange={e => setNewNodeName(e.target.value)}
                  placeholder="Misal: Paman Hendra, Tante Lina"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Peran / Hubungan</label>
                  <select
                    value={newNodeRole}
                    onChange={e => setNewNodeRole(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="Kakek (Ayah)">Kakek (Ayah)</option>
                    <option value="Nenek (Ayah)">Nenek (Ayah)</option>
                    <option value="Kakek (Ibu)">Kakek (Ibu)</option>
                    <option value="Nenek (Ibu)">Nenek (Ibu)</option>
                    <option value="Ayah Tiri">Ayah Tiri</option>
                    <option value="Ibu Tiri">Ibu Tiri</option>
                    <option value="Paman / Om">Paman / Om</option>
                    <option value="Bibi / Tante">Bibi / Tante</option>
                    <option value="Saudara Tiri">Saudara Tiri</option>
                    <option value="Sepupu">Sepupu</option>
                    <option value="Wali Asuh">Wali Asuh</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Jenis Kelamin</label>
                  <select
                    value={newNodeGender}
                    onChange={e => setNewNodeGender(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="Laki-laki">Laki-laki (Kotak)</option>
                    <option value="Perempuan">Perempuan (Lingkaran)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Tingkatan Generasi</label>
                  <select
                    value={newNodeGen}
                    onChange={e => setNewNodeGen(Number(e.target.value) as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value={1}>Generasi I (Kakek/Nenek)</option>
                    <option value={2}>Generasi II (Orang Tua/Paman)</option>
                    <option value={3}>Generasi III (Anak/Saudara)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Usia / Status</label>
                  <input
                    type="text"
                    value={newNodeAge}
                    onChange={e => setNewNodeAge(e.target.value)}
                    placeholder="Misal: 42"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="newNodeDeceasedCheck"
                  checked={newNodeDeceased}
                  onChange={e => setNewNodeDeceased(e.target.checked)}
                  className="rounded border-slate-700 text-indigo-600 focus:ring-0"
                />
                <label htmlFor="newNodeDeceasedCheck" className="text-slate-300 font-semibold cursor-pointer">
                  Anggota keluarga sudah meninggal dunia (Tanda Silang &#10006;)
                </label>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Catatan Khusus (Pekerjaan / Kondisi)</label>
                <input
                  type="text"
                  value={newNodeNotes}
                  onChange={e => setNewNodeNotes(e.target.value)}
                  placeholder="Misal: Riwayat migrasi ke luar kota, tinggal serumah"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsAddingNode(false)}
                className="px-3 py-1.5 text-slate-400 hover:text-white text-xs font-semibold"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleAddNode}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition"
              >
                Tambahkan ke Diagram
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Tambah Hubungan Relasi */}
      {isAddingLink && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 text-white border border-slate-700 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <h5 className="font-bold text-sm text-white flex items-center gap-2">
                <Heart className="w-4 h-4 text-rose-400" /> Hubungkan Dua Anggota Keluarga
              </h5>
              <button onClick={() => setIsAddingLink(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Anggota Keluarga 1</label>
                <select
                  value={newLinkFrom}
                  onChange={e => setNewLinkFrom(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                >
                  <option value="">-- Pilih Anggota Pertama --</option>
                  {diagramState.nodes.map(n => (
                    <option key={n.id} value={n.id}>{n.name} ({n.role})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Anggota Keluarga 2</label>
                <select
                  value={newLinkTo}
                  onChange={e => setNewLinkTo(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                >
                  <option value="">-- Pilih Anggota Kedua --</option>
                  {diagramState.nodes.map(n => (
                    <option key={n.id} value={n.id}>{n.name} ({n.role})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Karakter Hubungan Relasi</label>
                <select
                  value={newLinkType}
                  onChange={e => setNewLinkType(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                >
                  <option value="harmonis">Harmonis / Suportif (Garis Hijau Tebal)</option>
                  <option value="konflik">Konflik / Penuh Tekanan (Garis Merah Zigzag)</option>
                  <option value="putus_kontak">Putus Kontak / Renggang (Garis Ungu Putus-putus)</option>
                  <option value="pernikahan">Ikatan Pernikahan (Garis Biru Solid)</option>
                  <option value="perceraian">Perceraian (Garis dengan 2 Tanda Miring //)</option>
                  <option value="pisah">Pisah Ranjang (Garis Putus Oranye)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Keterangan Tambahan (Opsional)</label>
                <input
                  type="text"
                  value={newLinkLabel}
                  onChange={e => setNewLinkLabel(e.target.value)}
                  placeholder="Misal: Sering bertengkar soal nafkah, Hak asuh bersama"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsAddingLink(false)}
                className="px-3 py-1.5 text-slate-400 hover:text-white text-xs font-semibold"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleAddLink}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition"
              >
                Simpan Hubungan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
