import React, { useState, useRef } from 'react';
import { 
  Network, 
  Plus, 
  Trash2, 
  Download, 
  Save, 
  RotateCcw, 
  FileText, 
  Move,
  Edit2,
  ArrowRight,
  ArrowLeftRight,
  ArrowLeft,
  X,
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { Client } from '../../types';

export interface EcomapDomainNode {
  id: string;
  name: string;
  category: 'pendidikan' | 'kesehatan' | 'pekerjaan' | 'sosial' | 'spiritual' | 'pemerintah' | 'keluarga' | 'komunitas';
  color: string;
  strength: 'kuat' | 'sedang' | 'lemah' | 'stres';
  flow: 'dua_arah' | 'ke_klien' | 'dari_klien' | 'netral';
  notes?: string;
  x: number;
  y: number;
}

export interface EcomapState {
  centerNode: {
    name: string;
    sublabel: string;
    x: number;
    y: number;
  };
  domains: EcomapDomainNode[];
}

interface EcomapBuilderProps {
  client: Client;
  onSaveDiagram: (data: EcomapState, imagePng?: string) => void;
  onSyncCatatan?: (catatan: string) => void;
  onShowToast?: (msg: string, type?: 'success' | 'error') => void;
}

export const EcomapBuilder: React.FC<EcomapBuilderProps> = ({
  client,
  onSaveDiagram,
  onSyncCatatan,
  onShowToast
}) => {
  const fd = client.formData;
  const svgRef = useRef<SVGSVGElement>(null);

  // Default ecological domains mapped around the client
  const getDefaultState = (): EcomapState => {
    const centerX = 400;
    const centerY = 260;
    const radius = 190;

    const rawDomains: Array<Omit<EcomapDomainNode, 'x' | 'y'>> = [
      {
        id: 'eco-balai',
        name: 'Sentra GBR / Balai RSA',
        category: 'pemerintah',
        color: '#3b82f6',
        strength: 'kuat',
        flow: 'ke_klien',
        notes: `Pelayanan asrama, makan, dan vokasi jurusan ${fd.jurusan || 'Otomotif'}`
      },
      {
        id: 'eco-sekolah',
        name: fd.aftercareNamaSekolah || 'PKBM Kejar Paket',
        category: 'pendidikan',
        color: '#06b6d4',
        strength: fd.putusSekolah?.includes('Ya') ? 'lemah' : 'sedang',
        flow: 'dua_arah',
        notes: fd.kondisiPendidikan || 'Pendidikan kesetaraan paket'
      },
      {
        id: 'eco-sebaya',
        name: 'Teman Sebaya / Pergaulan',
        category: 'sosial',
        color: '#8b5cf6',
        strength: fd.tinggalJalan?.includes('Ya') ? 'stres' : 'sedang',
        flow: 'dua_arah',
        notes: fd.tinggalJalan?.includes('Ya') ? 'Pengaruh negatif lingkungan jalanan lama' : 'Teman asrama suportif'
      },
      {
        id: 'eco-pekerjaan',
        name: 'Pekerjaan / Magang Vokasi',
        category: 'pekerjaan',
        color: '#f59e0b',
        strength: 'sedang',
        flow: 'ke_klien',
        notes: 'Praktik kerja lapangan (PKL) mitra bengkel'
      },
      {
        id: 'eco-faskes',
        name: 'Puskesmas / Faskes BPJS',
        category: 'kesehatan',
        color: '#10b981',
        strength: 'sedang',
        flow: 'ke_klien',
        notes: `Status jaminan: ${fd.bpjs || 'BPJS PBI'}`
      },
      {
        id: 'eco-spiritual',
        name: 'Bimbingan Mental & Agama',
        category: 'spiritual',
        color: '#ec4899',
        strength: 'kuat',
        flow: 'ke_klien',
        notes: 'Salat berjamaah, pengajian, pembiasaan akhlak'
      },
      {
        id: 'eco-dinsos',
        name: 'Dinsos Daerah Asal',
        category: 'pemerintah',
        color: '#6366f1',
        strength: 'sedang',
        flow: 'dua_arah',
        notes: `Kab/Kota: ${fd.kabupatenKota || 'Jawa Barat'}`
      },
      {
        id: 'eco-lingkungan',
        name: 'Lingkungan RT / Tetangga',
        category: 'komunitas',
        color: '#64748b',
        strength: 'lemah',
        flow: 'netral',
        notes: 'Stigma masyarakat terhadap anak jalanan'
      }
    ];

    // Distribute around center in an oval
    const domains: EcomapDomainNode[] = rawDomains.map((d, index) => {
      const angle = (index / rawDomains.length) * 2 * Math.PI - Math.PI / 2;
      return {
        ...d,
        x: Math.round(centerX + radius * 1.4 * Math.cos(angle)),
        y: Math.round(centerY + radius * 0.95 * Math.sin(angle))
      };
    });

    return {
      centerNode: {
        name: client.nama,
        sublabel: `Klien & Keluarga (${client.formData?.angkatan || 'Angkatan I'})`,
        x: centerX,
        y: centerY
      },
      domains
    };
  };

  const [diagramState, setDiagramState] = useState<EcomapState>(() => {
    if (fd.ecomapData && fd.ecomapData.domains && fd.ecomapData.domains.length > 0) {
      return fd.ecomapData;
    }
    return getDefaultState();
  });

  const [selectedDomainId, setSelectedDomainId] = useState<string | null>(null);
  const [isAddingDomain, setIsAddingDomain] = useState(false);
  const [isExportingImage, setIsExportingImage] = useState(false);

  // New Domain Form State
  const [newDomainName, setNewDomainName] = useState('');
  const [newDomainCat, setNewDomainCat] = useState<EcomapDomainNode['category']>('sosial');
  const [newDomainStrength, setNewDomainStrength] = useState<EcomapDomainNode['strength']>('sedang');
  const [newDomainFlow, setNewDomainFlow] = useState<EcomapDomainNode['flow']>('dua_arah');
  const [newDomainNotes, setNewDomainNotes] = useState('');

  // Dragging state
  const [draggingDomainId, setDraggingDomainId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Mouse Drag Handlers
  const handleMouseDown = (domainId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const domain = diagramState.domains.find(d => d.id === domainId);
    if (!domain || !svgRef.current) return;

    const rect = svgRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    setDraggingDomainId(domainId);
    setDragOffset({ x: mouseX - domain.x, y: mouseY - domain.y });
    setSelectedDomainId(domainId);
  };

  // Touch Drag Handlers
  const handleTouchStart = (domainId: string, e: React.TouchEvent) => {
    e.stopPropagation();
    const domain = diagramState.domains.find(d => d.id === domainId);
    if (!domain || !svgRef.current || e.touches.length === 0) return;

    const touch = e.touches[0];
    const rect = svgRef.current.getBoundingClientRect();
    const touchX = touch.clientX - rect.left;
    const touchY = touch.clientY - rect.top;

    setDraggingDomainId(domainId);
    setDragOffset({ x: touchX - domain.x, y: touchY - domain.y });
    setSelectedDomainId(domainId);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggingDomainId || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const newX = Math.max(50, Math.min(rect.width - 50, e.clientX - rect.left - dragOffset.x));
    const newY = Math.max(50, Math.min(rect.height - 50, e.clientY - rect.top - dragOffset.y));

    setDiagramState(prev => ({
      ...prev,
      domains: prev.domains.map(d => d.id === draggingDomainId ? { ...d, x: newX, y: newY } : d)
    }));
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!draggingDomainId || !svgRef.current || e.touches.length === 0) return;
    const touch = e.touches[0];
    const rect = svgRef.current.getBoundingClientRect();
    const newX = Math.max(50, Math.min(rect.width - 50, touch.clientX - rect.left - dragOffset.x));
    const newY = Math.max(50, Math.min(rect.height - 50, touch.clientY - rect.top - dragOffset.y));

    setDiagramState(prev => ({
      ...prev,
      domains: prev.domains.map(d => d.id === draggingDomainId ? { ...d, x: newX, y: newY } : d)
    }));
  };

  const handleEndDrag = () => {
    setDraggingDomainId(null);
  };

  // Add Domain
  const handleAddDomain = () => {
    if (!newDomainName.trim()) {
      alert('Nama sistem/jejaring sosial wajib diisi.');
      return;
    }

    const catColors: Record<EcomapDomainNode['category'], string> = {
      pendidikan: '#06b6d4',
      kesehatan: '#10b981',
      pekerjaan: '#f59e0b',
      sosial: '#8b5cf6',
      spiritual: '#ec4899',
      pemerintah: '#3b82f6',
      keluarga: '#f43f5e',
      komunitas: '#64748b'
    };

    const newDomain: EcomapDomainNode = {
      id: `eco-${Date.now()}`,
      name: newDomainName.trim(),
      category: newDomainCat,
      color: catColors[newDomainCat] || '#6366f1',
      strength: newDomainStrength,
      flow: newDomainFlow,
      notes: newDomainNotes.trim() || undefined,
      x: 400 + (Math.random() * 160 - 80),
      y: 100 + (Math.random() * 80)
    };

    setDiagramState(prev => ({
      ...prev,
      domains: [...prev.domains, newDomain]
    }));

    setNewDomainName('');
    setNewDomainNotes('');
    setIsAddingDomain(false);
    if (onShowToast) onShowToast(`Sistem ekologis "${newDomain.name}" berhasil ditambahkan.`, 'success');
  };

  // Delete Domain
  const handleDeleteDomain = (id: string) => {
    setDiagramState(prev => ({
      ...prev,
      domains: prev.domains.filter(d => d.id !== id)
    }));
    if (selectedDomainId === id) setSelectedDomainId(null);
    if (onShowToast) onShowToast('Sistem ekologis berhasil dihapus dari Ecomap.', 'success');
  };

  // Update Selected Domain Properties
  const handleUpdateDomainStrength = (strength: EcomapDomainNode['strength']) => {
    if (!selectedDomainId) return;
    setDiagramState(prev => ({
      ...prev,
      domains: prev.domains.map(d => d.id === selectedDomainId ? { ...d, strength } : d)
    }));
  };

  const handleUpdateDomainFlow = (flow: EcomapDomainNode['flow']) => {
    if (!selectedDomainId) return;
    setDiagramState(prev => ({
      ...prev,
      domains: prev.domains.map(d => d.id === selectedDomainId ? { ...d, flow } : d)
    }));
  };

  // Reset
  const handleReset = () => {
    if (window.confirm('Reset Ecomap ke susunan sistem standar Sentra/Balai? Perubahan tata letak kustom akan diatur ulang.')) {
      setDiagramState(getDefaultState());
      if (onShowToast) onShowToast('Ecomap berhasil direset ke template standar.', 'success');
    }
  };

  // Narrative Summary Generator
  const generateNarrativeSummary = () => {
    const strongList = diagramState.domains.filter(d => d.strength === 'kuat').map(d => d.name);
    const stressList = diagramState.domains.filter(d => d.strength === 'stres').map(d => d.name);
    const weakList = diagramState.domains.filter(d => d.strength === 'lemah').map(d => d.name);

    let summary = `Pemetaan Ecomap menunjukkan bahwa ${client.nama} terhubung dengan ${diagramState.domains.length} sistem ekologis sosial. `;
    
    if (strongList.length > 0) {
      summary += `Sumber dukungan terkuat dan paling positif diperoleh dari: ${strongList.join(', ')}. `;
    }

    if (stressList.length > 0) {
      summary += `Terdapat sistem yang menimbulkan stres atau konflik relasional tinggi: ${stressList.join(', ')}, yang memerlukan mediasi dan proteksi peksos. `;
    }

    if (weakList.length > 0) {
      summary += `Sementara itu, hubungan dengan ${weakList.join(', ')} tergolong lemah / renggang dan membutuhkan penguatan kembali (bridging social capital). `;
    }

    summary += `Arah aliran energi sebagian besar berupa transfer bimbingan dan perlindungan sosial ke klien, dengan fokus memperkuat kemandirian transisi pasca-asrama.`;

    if (onSyncCatatan) {
      onSyncCatatan(summary);
      if (onShowToast) onShowToast('Rangkuman analisis Ecomap berhasil disalin ke formulir Asesmen!', 'success');
    }
    return summary;
  };

  // Export SVG to PNG
  const exportSvgToPng = (andSaveToDoc = false) => {
    if (!svgRef.current) return;
    setIsExportingImage(true);

    try {
      const svgElement = svgRef.current;
      const svgString = new XMLSerializer().serializeToString(svgElement);
      const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
      const URL = window.URL || window.webkitURL || window;
      const blobURL = URL.createObjectURL(svgBlob);
      
      const image = new Image();
      image.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = svgElement.clientWidth * 2 || 1600;
        canvas.height = svgElement.clientHeight * 2 || 1040;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

          const pngDataUrl = canvas.toDataURL('image/png');

          // Trigger browser download
          const link = document.createElement('a');
          link.download = `Ecomap_${(client.nama || 'Klien').replace(/[^a-zA-Z0-9_-]/g, '_')}_EkologiSosial.png`;
          link.href = pngDataUrl;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          // Save state to parent document
          onSaveDiagram(diagramState, pngDataUrl);

          if (onShowToast) onShowToast('Gambar diagram Ecomap (PNG) berhasil diunduh dan disimpan ke profil!', 'success');
        }
        URL.revokeObjectURL(blobURL);
        setIsExportingImage(false);
      };

      image.src = blobURL;
    } catch (err) {
      console.error(err);
      setIsExportingImage(false);
      if (onShowToast) onShowToast('Gagal memproses gambar Ecomap.', 'error');
    }
  };

  const handleSaveStateOnly = () => {
    onSaveDiagram(diagramState);
    if (onShowToast) onShowToast('Konfigurasi diagram Ecomap berhasil disimpan.', 'success');
  };

  return (
    <div className="bg-slate-900 text-white rounded-2xl border-2 border-sky-400/40 p-4 sm:p-5 shadow-xl space-y-4">
      {/* Top Header & Toolbar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-sky-600 rounded-lg text-white">
              <Network className="w-4 h-4" />
            </span>
            <h4 className="font-extrabold text-sm sm:text-base text-white tracking-wide">
              Visualisasi Ecomap Interaktif (Ekologi Sosial)
            </h4>
            <span className="bg-sky-500/20 text-sky-300 border border-sky-400/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
              Peta Relasi & Dukungan
            </span>
          </div>
          <p className="text-[11px] text-slate-300 mt-1">
            Petakan jejaring relasi, kekuatan dukungan sosial, dan titik stres {client.nama}. Geser posisi lingkaran jejaring di sekitar klien secara drag & drop.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setIsAddingDomain(true)}
            className="bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1 transition shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah Sistem</span>
          </button>

          <button
            type="button"
            onClick={generateNarrativeSummary}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1 transition shadow-xs"
            title="Salin temuan analisis ke Catatan Asesmen Ecomap"
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Rangkum Analisis</span>
          </button>

          <button
            type="button"
            onClick={() => exportSvgToPng(true)}
            disabled={isExportingImage}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition shadow-xs disabled:opacity-50"
            title="Unduh diagram beresolusi tinggi dalam format PNG"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExportingImage ? 'Memproses...' : 'Unduh Gambar (PNG)'}</span>
          </button>

          <button
            type="button"
            onClick={handleSaveStateOnly}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs px-2.5 py-1.5 rounded-xl flex items-center gap-1 transition"
            title="Simpan konfigurasi Ecomap"
          >
            <Save className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Simpan</span>
          </button>

          <button
            type="button"
            onClick={handleReset}
            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
            title="Reset ke susunan awal"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Navigation Subbar */}
      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 px-2 py-1 bg-slate-800/60 rounded-lg border border-slate-800">
        <span className="flex items-center gap-1">
          <Move className="w-3 h-3 text-sky-400" /> Tips: Klik atau sentuh bulatan sistem ekologis untuk menggeser posisinya melingkari Klien
        </span>
        <span className="text-slate-400 hidden sm:inline">
          Garis Hijau: Kuat & Suportif • Garis Putus: Renggang • Garis Zigzag: Tekanan/Stres
        </span>
      </div>

      {/* SVG Canvas Area */}
      <div className="relative bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-inner select-none">
        <svg
          ref={svgRef}
          className="w-full h-[500px] sm:h-[540px] cursor-crosshair"
          onMouseMove={handleMouseMove}
          onMouseUp={handleEndDrag}
          onMouseLeave={handleEndDrag}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleEndDrag}
        >
          {/* Defs for Patterns & Arrows */}
          <defs>
            <pattern id="ecomapGrid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#1e293b" strokeWidth="0.8" />
            </pattern>
            {/* Arrow Towards Client */}
            <marker id="arrowToClient" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#38bdf8" />
            </marker>
            {/* Arrow Outwards from Client */}
            <marker id="arrowFromClient" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#f43f5e" />
            </marker>
          </defs>

          <rect width="100%" height="100%" fill="url(#ecomapGrid)" />

          {/* Background Concentric Radial Guides */}
          <g opacity="0.15">
            <ellipse cx={diagramState.centerNode.x} cy={diagramState.centerNode.y} rx="260" ry="190" fill="none" stroke="#38bdf8" strokeWidth="1" strokeDasharray="6 6" />
            <ellipse cx={diagramState.centerNode.x} cy={diagramState.centerNode.y} rx="160" ry="120" fill="none" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="4 4" />
          </g>

          {/* Connector Lines between Center Node and Domains */}
          {diagramState.domains.map(domain => {
            const centerX = diagramState.centerNode.x;
            const centerY = diagramState.centerNode.y;
            const isSelected = selectedDomainId === domain.id;

            // Styles based on strength
            let strokeColor = '#38bdf8';
            let strokeWidth = 2.5;
            let strokeDasharray = 'none';

            if (domain.strength === 'kuat') {
              strokeColor = '#22c55e'; // Green solid thick
              strokeWidth = 4.5;
            } else if (domain.strength === 'sedang') {
              strokeColor = '#0ea5e9'; // Sky solid normal
              strokeWidth = 2.5;
            } else if (domain.strength === 'lemah') {
              strokeColor = '#f59e0b'; // Amber dashed
              strokeDasharray = '5 5';
              strokeWidth = 2;
            } else if (domain.strength === 'stres') {
              strokeColor = '#ef4444'; // Red zigzag/thick
              strokeWidth = 3.5;
            }

            const midX = (centerX + domain.x) / 2;
            const midY = (centerY + domain.y) / 2;

            return (
              <g 
                key={`line-${domain.id}`} 
                onClick={(e) => { e.stopPropagation(); setSelectedDomainId(domain.id); }}
                className="cursor-pointer"
              >
                {/* Main line */}
                {domain.strength === 'stres' ? (
                  // Red Stress Zigzag
                  <path
                    d={`M ${centerX} ${centerY} Q ${midX - 12} ${midY - 12}, ${midX} ${midY} T ${domain.x} ${domain.y}`}
                    stroke={strokeColor}
                    strokeWidth={strokeWidth}
                    fill="none"
                  />
                ) : (
                  <line
                    x1={centerX}
                    y1={centerY}
                    x2={domain.x}
                    y2={domain.y}
                    stroke={isSelected ? '#f43f5e' : strokeColor}
                    strokeWidth={isSelected ? strokeWidth + 2 : strokeWidth}
                    strokeDasharray={strokeDasharray}
                  />
                )}

                {/* Energy Flow Arrows */}
                {domain.flow === 'dua_arah' && (
                  <g transform={`translate(${midX}, ${midY})`}>
                    <circle r="12" fill="#0f172a" stroke="#334155" strokeWidth="1" />
                    <text textAnchor="middle" y="4" fill="#38bdf8" fontSize="12" fontWeight="bold">&#8646;</text>
                  </g>
                )}
                {domain.flow === 'ke_klien' && (
                  <g transform={`translate(${midX}, ${midY})`}>
                    <circle r="12" fill="#0f172a" stroke="#334155" strokeWidth="1" />
                    <text textAnchor="middle" y="4" fill="#22c55e" fontSize="12" fontWeight="bold">&#8601;</text>
                  </g>
                )}
                {domain.flow === 'dari_klien' && (
                  <g transform={`translate(${midX}, ${midY})`}>
                    <circle r="12" fill="#0f172a" stroke="#334155" strokeWidth="1" />
                    <text textAnchor="middle" y="4" fill="#f43f5e" fontSize="12" fontWeight="bold">&#8599;</text>
                  </g>
                )}
              </g>
            );
          })}

          {/* Central Client Node (Klien & Keluarga Inti) */}
          <g transform={`translate(${diagramState.centerNode.x}, ${diagramState.centerNode.y})`}>
            {/* Outer ring */}
            <circle r="68" fill="#1e3a8a" fillOpacity="0.4" stroke="#60a5fa" strokeWidth="2.5" />
            <circle r="56" fill="#172554" stroke="#93c5fd" strokeWidth="2" strokeDasharray="3 3" />
            <circle r="44" fill="#1e40af" />

            <text textAnchor="middle" y="-6" fill="#ffffff" fontSize="13" fontWeight="bold" fontFamily="sans-serif">
              {diagramState.centerNode.name}
            </text>
            <text textAnchor="middle" y="10" fill="#93c5fd" fontSize="9.5" fontWeight="600" fontFamily="sans-serif">
              Klien & Keluarga Inti
            </text>
            <text textAnchor="middle" y="24" fill="#bfdbfe" fontSize="8.5" fontFamily="sans-serif">
              Identified Client
            </text>
          </g>

          {/* Ecological System Domain Nodes */}
          {diagramState.domains.map(domain => {
            const isSelected = selectedDomainId === domain.id;
            const r = 40;

            return (
              <g
                key={domain.id}
                transform={`translate(${domain.x}, ${domain.y})`}
                onMouseDown={(e) => handleMouseDown(domain.id, e)}
                onTouchStart={(e) => handleTouchStart(domain.id, e)}
                className="cursor-move select-none"
              >
                {/* Selection Halo */}
                {isSelected && (
                  <circle r={r + 10} fill="#38bdf8" fillOpacity="0.25" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 3" />
                )}

                {/* Domain Circle */}
                <circle
                  r={r}
                  fill="#0f172a"
                  stroke={domain.color}
                  strokeWidth={isSelected ? 3.5 : 2.5}
                />
                <circle
                  r={r - 4}
                  fill={domain.color}
                  fillOpacity="0.2"
                />

                {/* Domain Label Inside Circle */}
                <text
                  textAnchor="middle"
                  y="-4"
                  fill="#ffffff"
                  fontSize="9.5"
                  fontWeight="bold"
                  fontFamily="sans-serif"
                >
                  {domain.name.length > 15 ? `${domain.name.slice(0, 14)}...` : domain.name}
                </text>
                <text
                  textAnchor="middle"
                  y="9"
                  fill={domain.color}
                  fontSize="8"
                  fontWeight="bold"
                  fontFamily="sans-serif"
                >
                  {domain.category.toUpperCase()}
                </text>

                {/* Strength pill badge */}
                <g transform="translate(0, 22)">
                  <rect
                    x="-24"
                    y="-6"
                    width="48"
                    height="13"
                    rx="6"
                    fill={
                      domain.strength === 'kuat' ? '#166534' :
                      domain.strength === 'sedang' ? '#0369a1' :
                      domain.strength === 'lemah' ? '#854d0e' : '#991b1b'
                    }
                  />
                  <text
                    textAnchor="middle"
                    y="3.5"
                    fill="#ffffff"
                    fontSize="7.5"
                    fontWeight="bold"
                    fontFamily="sans-serif"
                  >
                    {domain.strength === 'kuat' ? 'KUAT' :
                     domain.strength === 'sedang' ? 'SEDANG' :
                     domain.strength === 'lemah' ? 'LEMAH' : 'STRES'}
                  </text>
                </g>

                {/* Notes tooltip below circle if present */}
                {domain.notes && (
                  <text
                    textAnchor="middle"
                    y={r + 14}
                    fill="#94a3b8"
                    fontSize="8"
                    fontStyle="italic"
                    fontFamily="sans-serif"
                  >
                    {domain.notes.length > 22 ? `${domain.notes.slice(0, 20)}...` : domain.notes}
                  </text>
                )}
              </g>
            );
          })}
        </svg>

        {/* Selected Domain Action Dock */}
        {selectedDomainId && (
          <div className="absolute bottom-3 left-3 right-3 sm:left-auto sm:right-3 bg-slate-900/95 border border-slate-700 backdrop-blur-md p-3 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs shadow-2xl animate-in fade-in">
            {(() => {
              const domain = diagramState.domains.find(d => d.id === selectedDomainId);
              if (!domain) return null;
              return (
                <>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-white text-xs">{domain.name}</span>
                      <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 rounded" style={{ backgroundColor: `${domain.color}20`, color: domain.color }}>
                        {domain.category}
                      </span>
                    </div>
                    {domain.notes && (
                      <p className="text-[10px] text-slate-400 mt-0.5 italic">{domain.notes}</p>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    {/* Change Strength */}
                    <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-lg border border-slate-700">
                      <span className="text-[10px] text-slate-400 px-1 font-bold">Relasi:</span>
                      <button
                        type="button"
                        onClick={() => handleUpdateDomainStrength('kuat')}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${domain.strength === 'kuat' ? 'bg-green-600 text-white' : 'text-slate-400 hover:text-white'}`}
                      >
                        Kuat
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateDomainStrength('sedang')}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${domain.strength === 'sedang' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'}`}
                      >
                        Sedang
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateDomainStrength('lemah')}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${domain.strength === 'lemah' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'}`}
                      >
                        Lemah
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateDomainStrength('stres')}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${domain.strength === 'stres' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'}`}
                      >
                        Stres
                      </button>
                    </div>

                    {/* Change Flow */}
                    <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-lg border border-slate-700">
                      <span className="text-[10px] text-slate-400 px-1 font-bold">Aliran:</span>
                      <button
                        type="button"
                        onClick={() => handleUpdateDomainFlow('dua_arah')}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${domain.flow === 'dua_arah' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
                        title="Dua arah timbal balik"
                      >
                        &#8646; 2 Arah
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateDomainFlow('ke_klien')}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${domain.flow === 'ke_klien' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
                        title="Memberikan dukungan ke klien"
                      >
                        &#8601; Masuk
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateDomainFlow('dari_klien')}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${domain.flow === 'dari_klien' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
                        title="Klien mencurahkan energi ke sistem"
                      >
                        &#8599; Keluar
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        const newName = prompt('Ganti Nama Sistem Ekologis:', domain.name);
                        if (newName && newName.trim()) {
                          setDiagramState(prev => ({
                            ...prev,
                            domains: prev.domains.map(d => d.id === selectedDomainId ? { ...d, name: newName.trim() } : d)
                          }));
                        }
                      }}
                      className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg"
                      title="Ganti Nama"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDeleteDomain(domain.id)}
                      className="p-1.5 bg-rose-900/80 hover:bg-rose-800 text-rose-200 rounded-lg"
                      title="Hapus Sistem"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedDomainId(null)}
                      className="p-1.5 text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </>
              );
            })()}
          </div>
        )}
      </div>

      {/* Legend & Standard Ecomap Conventions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-2 text-[10px] bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-slate-300">
        <div className="flex items-center gap-2">
          <div className="w-6 h-1 bg-green-500 rounded" />
          <span>Kuat & Suportif</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-0.5 bg-sky-400 rounded" />
          <span>Sedang / Biasa</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-0.5 border-t border-dashed border-amber-400" />
          <span>Lemah / Renggang</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-1 bg-rose-500 rounded" />
          <span>Penuh Tekanan / Stres</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-bold text-sky-400 text-xs">&#8646;</span>
          <span>Arah Aliran Energi</span>
        </div>
      </div>

      {/* MODAL: Tambah Sistem Ekologis Baru */}
      {isAddingDomain && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 text-white border border-slate-700 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <h5 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-sky-400" /> Tambah Jejaring Ekologis
              </h5>
              <button onClick={() => setIsAddingDomain(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Nama Lembaga / Sistem Lingkungan *</label>
                <input
                  type="text"
                  value={newDomainName}
                  onChange={e => setNewDomainName(e.target.value)}
                  placeholder="Misal: Sanggar Tari Tradisional, Klub Futsal RT, Karang Taruna"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Kategori Sistem</label>
                  <select
                    value={newDomainCat}
                    onChange={e => setNewDomainCat(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="pendidikan">Pendidikan / Sekolah</option>
                    <option value="kesehatan">Kesehatan / Faskes</option>
                    <option value="pekerjaan">Dunia Kerja / Bengkel</option>
                    <option value="sosial">Sosial / Komunitas</option>
                    <option value="spiritual">Spiritual / Agama</option>
                    <option value="pemerintah">Lembaga Pemerintah</option>
                    <option value="komunitas">Lingkungan Warga / RT</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Kekuatan Relasi</label>
                  <select
                    value={newDomainStrength}
                    onChange={e => setNewDomainStrength(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="kuat">Kuat & Suportif (Hijau)</option>
                    <option value="sedang">Sedang / Cukup (Biru)</option>
                    <option value="lemah">Lemah / Renggang (Oranye)</option>
                    <option value="stres">Tekanan / Stres Tinggi (Merah)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Arah Aliran Energi / Bantuan</label>
                <select
                  value={newDomainFlow}
                  onChange={e => setNewDomainFlow(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                >
                  <option value="dua_arah">Dua Arah (Saling Memberi Manfaat)</option>
                  <option value="ke_klien">Masuk ke Klien (Memberi Bantuan/Materi)</option>
                  <option value="dari_klien">Keluar dari Klien (Klien Menguras Tenaga/Stres)</option>
                  <option value="netral">Netral (Tanpa Aliran Khusus)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Catatan Keterlibatan Anak</label>
                <input
                  type="text"
                  value={newDomainNotes}
                  onChange={e => setNewDomainNotes(e.target.value)}
                  placeholder="Misal: Ikut latihan seminggu 2 kali, sering dipinjamkan peralatan"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsAddingDomain(false)}
                className="px-3 py-1.5 text-slate-400 hover:text-white text-xs font-semibold"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleAddDomain}
                className="px-4 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition"
              >
                Tambahkan ke Ecomap
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
