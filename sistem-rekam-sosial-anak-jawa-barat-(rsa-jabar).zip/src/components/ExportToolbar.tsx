import React, { useState } from 'react';
import { 
  Download, 
  FileText, 
  Printer, 
  Loader2, 
  CheckCircle2, 
  Sparkles,
  FileDown,
  FileSpreadsheet
} from 'lucide-react';
import { Client } from '../types';
import { exportToPdf, exportToWord, TabExportType } from '../services/exportDocumentService';
import { exportClientsToExcel } from '../services/exportExcelService';

interface ExportToolbarProps {
  tabType: TabExportType;
  title: string;
  client: Client;
  peksosName?: string;
  onGoToFullReport?: () => void;
  onShowToast?: (msg: string, type?: 'success' | 'error') => void;
}

export const ExportToolbar: React.FC<ExportToolbarProps> = ({
  tabType,
  title,
  client,
  peksosName = 'Pekerja Sosial Ahli',
  onGoToFullReport,
  onShowToast
}) => {
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isExportingWord, setIsExportingWord] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleExportPdf = async () => {
    try {
      setIsExportingPdf(true);
      await exportToPdf({ tabType, client, peksosName });
      const msg = `Dokumen PDF ${title} untuk ${client.nama} berhasil diunduh!`;
      setSuccessMsg(msg);
      if (onShowToast) onShowToast(msg, 'success');
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err) {
      console.error(err);
      if (onShowToast) onShowToast('Gagal memproses dokumen PDF.', 'error');
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleExportWord = () => {
    try {
      setIsExportingWord(true);
      exportToWord({ tabType, client, peksosName });
      const msg = `Dokumen Word (.doc) ${title} untuk ${client.nama} berhasil diunduh!`;
      setSuccessMsg(msg);
      if (onShowToast) onShowToast(msg, 'success');
      setTimeout(() => {
        setIsExportingWord(false);
        setSuccessMsg(null);
      }, 3500);
    } catch (err) {
      console.error(err);
      setIsExportingWord(false);
      if (onShowToast) onShowToast('Gagal memproses dokumen Word.', 'error');
    }
  };

  const handleExportExcel = () => {
    try {
      const angkatanStr = client.formData?.angkatan || 'Angkatan I - 2026';
      exportClientsToExcel([client], {
        customFilename: `Data_Anak_${(client.nama || 'Anak').replace(/[^a-zA-Z0-9_-]/g, '_')}_${angkatanStr.replace(/[^a-zA-Z0-9_-]/g, '_')}.xlsx`
      });
      const msg = `Data Excel ${client.nama} (${angkatanStr}) berhasil diunduh lengkap dengan kolom Angkatan Masuk!`;
      setSuccessMsg(msg);
      if (onShowToast) onShowToast(msg, 'success');
      setTimeout(() => setSuccessMsg(null), 3500);
    } catch (err: any) {
      console.error(err);
      if (onShowToast) onShowToast('Gagal memproses file Excel.', 'error');
    }
  };

  return (
    <div className="space-y-2 no-print">
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between bg-slate-900 text-white p-3 sm:p-4 rounded-2xl border border-slate-800 shadow-md gap-3">
        {/* Title & Badge */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-sky-500 flex items-center justify-center text-white shrink-0 shadow-xs">
            <FileDown className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-extrabold text-white tracking-wide">
                Ekspor & Cetak: {title}
              </span>
              <span className="hidden sm:inline-block bg-sky-500/20 text-sky-300 border border-sky-400/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                Standar Dinsos Jabar
              </span>
            </div>
            <p className="text-[11px] text-slate-300">
              Dokumentasikan perkembangan {client.nama} ({client.formData?.angkatan || 'Angkatan I - 2026'}) dalam format PDF, Word, atau Excel.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          {/* Unduh Excel Button */}
          <button
            type="button"
            onClick={handleExportExcel}
            className="flex-1 sm:flex-initial bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-xs px-3 py-2 rounded-xl flex items-center justify-center gap-1.5 transition shadow-xs"
            title="Unduh data anak ke Excel (.xlsx) lengkap dengan kolom Angkatan Masuk"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
            <span>Excel (.xlsx)</span>
          </button>

          {/* Unduh Word Button */}
          <button
            type="button"
            onClick={handleExportWord}
            disabled={isExportingWord || isExportingPdf}
            className="flex-1 sm:flex-initial bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs px-3 py-2 rounded-xl flex items-center justify-center gap-1.5 transition shadow-xs disabled:opacity-50"
            title="Unduh berkas Microsoft Word (.doc) yang dapat diedit di Word / Docs"
          >
            {isExportingWord ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Word...</span>
              </>
            ) : (
              <>
                <FileText className="w-3.5 h-3.5 text-blue-200" />
                <span>Word (.doc)</span>
              </>
            )}
          </button>

          {/* Unduh PDF Button */}
          <button
            type="button"
            onClick={handleExportPdf}
            disabled={isExportingPdf || isExportingWord}
            className="flex-1 sm:flex-initial bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs px-3 py-2 rounded-xl flex items-center justify-center gap-1.5 transition shadow-xs disabled:opacity-50"
            title="Unduh berkas PDF siap cetak A4 beresolusi tinggi"
          >
            {isExportingPdf ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>PDF...</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5 text-emerald-200" />
                <span>PDF</span>
              </>
            )}
          </button>

          {/* Rujuk ke Laporan Lengkap / Cetak */}
          {onGoToFullReport && (
            <button
              type="button"
              onClick={onGoToFullReport}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs px-3 py-2 rounded-xl flex items-center justify-center gap-1.5 transition shrink-0"
              title="Lihat Laporan Sosial Lengkap (Semua Tahapan)"
            >
              <Printer className="w-3.5 h-3.5 text-slate-300" />
              <span className="hidden sm:inline">Laporan Lengkap</span>
            </button>
          )}
        </div>
      </div>

      {/* Success Notification Alert */}
      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in duration-200 shadow-2xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}
    </div>
  );
};
