import React from 'react';
import { 
  Users, 
  UserPlus, 
  Database, 
  Bot, 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  Shield,
  Sparkles,
  CloudCheck,
  LogIn,
  LogOut,
  FileSpreadsheet,
  Search
} from 'lucide-react';
import { Client } from '../types';
import { JAWA_BARAT_REGIONS } from '../data/defaultData';
import { User as FirebaseUser } from 'firebase/auth';
import { PWAInstallButton } from './pwa/PWAInstallButton';

interface HeaderNavProps {
  clients: Client[];
  filteredClients: Client[];
  currentClientId: string | null;
  onSelectClient: (id: string) => void;
  regionFilter: string;
  onRegionFilterChange: (reg: string) => void;
  angkatanFilter: string;
  onAngkatanFilterChange: (ang: string) => void;
  allAngkatanList: string[];
  onlyActiveFilter: boolean;
  onToggleActiveFilter: () => void;
  onOpenAddClient: () => void;
  onOpenGlobalDashboard: () => void;
  onOpenDataManagement: () => void;
  onOpenExcelImport?: () => void;
  onOpenAIConsult: () => void;
  onOpenQuickSearch: () => void;
  peksosName: string;
  onOpenProfile: () => void;
  isCloudConnected: boolean;
  currentUser: FirebaseUser | null;
  isAdmin?: boolean;
  onOpenAdminPanel?: () => void;
  onSignOut: () => void;
  onOpenAuthModal: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  clients,
  filteredClients,
  currentClientId,
  onSelectClient,
  regionFilter,
  onRegionFilterChange,
  angkatanFilter,
  onAngkatanFilterChange,
  allAngkatanList,
  onlyActiveFilter,
  onToggleActiveFilter,
  onOpenAddClient,
  onOpenGlobalDashboard,
  onOpenDataManagement,
  onOpenExcelImport,
  onOpenAIConsult,
  onOpenQuickSearch,
  peksosName,
  onOpenProfile,
  isCloudConnected,
  currentUser,
  isAdmin = false,
  onOpenAdminPanel,
  onSignOut,
  onOpenAuthModal,
}) => {
  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row justify-between py-2.5 items-center gap-2.5">
          {/* Brand */}
          <div className="flex items-center justify-between w-full lg:w-auto">
            <div className="flex items-center gap-2.5 text-sky-600">
              <div className="w-9 h-9 rounded-lg bg-sky-50 flex items-center justify-center border border-sky-200">
                <ShieldCheck className="w-5 h-5 text-sky-600" />
              </div>
              <div>
                <span className="font-bold text-base sm:text-lg tracking-tight text-slate-900 flex items-center gap-1.5">
                  Rekam Sosial Anak
                  <span className="text-[10px] bg-sky-100 text-sky-700 font-bold px-1.5 py-0.5 rounded">JABAR</span>
                  <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded-md" title="Autentikasi Firebase semarakppsgbr Aktif">
                    semarakppsgbr
                  </span>
                </span>
                <p className="text-[11px] text-slate-500 hidden sm:block">Sistem Manajemen Kasus BPSS Terintegrasi Gemini AI & semarakppsgbr</p>
              </div>
            </div>

            {/* Mobile Actions */}
            <div className="flex lg:hidden items-center gap-1.5">
              {isAdmin && onOpenAdminPanel && (
                <button
                  onClick={onOpenAdminPanel}
                  className="p-2 rounded-lg bg-slate-900 text-white hover:bg-slate-800"
                  title="Panel Admin"
                >
                  <Shield className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={onOpenQuickSearch}
                className="p-2 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200"
                title="Pencarian Global Cepat"
              >
                <Search className="w-4 h-4 text-sky-600" />
              </button>
              <button
                onClick={onOpenAIConsult}
                className="p-2 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-100"
                title="Asisten Gemini AI"
              >
                <Sparkles className="w-4 h-4" />
              </button>
              <button
                onClick={onOpenAddClient}
                className="p-2 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100"
                title="Tambah Anak"
              >
                <UserPlus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Controls & Filters */}
          <div className="flex flex-wrap items-center justify-center lg:justify-end gap-1.5 sm:gap-2 w-full lg:w-auto flex-1 text-xs">
            {/* Quick Global Search Button (Omnisearch) */}
            <button
              onClick={onOpenQuickSearch}
              className="inline-flex items-center gap-1.5 rounded-lg bg-white border border-slate-300 py-1.5 pl-2.5 pr-2 text-slate-700 font-medium hover:bg-slate-50 hover:border-sky-400 transition shadow-2xs cursor-pointer"
              title="Pencarian Cepat Klien / Kasus (Tekan Ctrl+K)"
            >
              <Search className="w-3.5 h-3.5 text-sky-600" />
              <span className="hidden xl:inline text-slate-500">Cari Klien...</span>
              <kbd className="hidden sm:inline-flex items-center px-1.5 py-0.2 text-[10px] font-mono text-slate-500 bg-slate-100 border border-slate-200 rounded">
                Ctrl+K
              </kbd>
            </button>

            {/* AI Assistant Button */}
            <button
              onClick={onOpenAIConsult}
              className="inline-flex items-center gap-1.5 rounded-lg bg-linear-to-r from-purple-600 to-indigo-600 px-3 py-1.5 font-bold text-white shadow-xs hover:from-purple-700 hover:to-indigo-700 transition"
              title="Konsultasi Kasus dengan Gemini AI"
            >
              <Bot className="w-3.5 h-3.5" />
              <span>Asisten AI</span>
            </button>

            {/* Global Data Button */}
            <button
              onClick={onOpenGlobalDashboard}
              className="inline-flex items-center gap-1.5 rounded-lg bg-cyan-600 px-2.5 py-1.5 font-semibold text-white shadow-xs hover:bg-cyan-700 transition"
              title="Tampilkan Data Global Anak"
            >
              <Users className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Data Global</span>
            </button>

            {/* Angkatan Filter */}
            <select
              value={angkatanFilter}
              onChange={(e) => onAngkatanFilterChange(e.target.value)}
              className="rounded-lg border border-slate-300 py-1.5 pl-2 pr-6 bg-slate-50 font-medium text-slate-700 focus:ring-2 focus:ring-sky-500 cursor-pointer max-w-[130px] truncate"
            >
              <option value="">Semua Angkatan</option>
              {allAngkatanList.map((ang) => (
                <option key={ang} value={ang}>{ang}</option>
              ))}
            </select>

            {/* Region Filter */}
            <select
              value={regionFilter}
              onChange={(e) => onRegionFilterChange(e.target.value)}
              className="rounded-lg border border-slate-300 py-1.5 pl-2 pr-6 bg-slate-50 font-medium text-slate-700 focus:ring-2 focus:ring-sky-500 cursor-pointer max-w-[140px] truncate"
            >
              <option value="">Semua Wilayah</option>
              {JAWA_BARAT_REGIONS.map((reg) => (
                <option key={reg} value={reg}>{reg}</option>
              ))}
            </select>

            {/* Status Toggle */}
            <button
              onClick={onToggleActiveFilter}
              className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 font-semibold transition border ${
                onlyActiveFilter
                  ? 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                  : 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100'
              }`}
              title="Filter Status Kasus"
            >
              {onlyActiveFilter ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span className="hidden md:inline">{onlyActiveFilter ? 'Hanya Aktif' : 'Semua Status'}</span>
            </button>

            {/* Client Selector */}
            <select
              value={currentClientId || ''}
              onChange={(e) => onSelectClient(e.target.value)}
              className="rounded-lg border border-sky-300 py-1.5 pl-2.5 pr-8 bg-sky-50/50 font-bold text-sky-950 focus:ring-2 focus:ring-sky-500 cursor-pointer max-w-[160px] sm:max-w-[200px] truncate"
            >
              {filteredClients.length === 0 ? (
                <option value="">-- Kosong --</option>
              ) : (
                filteredClients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.nama} ({c.id})
                  </option>
                ))
              )}
            </select>

            {/* New Client Button */}
            <button
              onClick={onOpenAddClient}
              className="inline-flex items-center gap-1.5 rounded-lg bg-sky-600 px-2.5 py-1.5 font-semibold text-white shadow-xs hover:bg-sky-700 transition"
              title="Tambah Anak Baru"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Baru</span>
            </button>

            {/* Data Management Button (Ekspor & Backup) */}
            <button
              onClick={onOpenDataManagement}
              className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2.5 py-1.5 font-semibold text-slate-700 border border-slate-200 hover:bg-slate-200 transition"
              title="Ekspor Excel / Backup JSON"
            >
              <Database className="w-3.5 h-3.5" />
              <span className="hidden xl:inline">Ekspor/Data</span>
            </button>

            {/* Import Excel Shortcut Button */}
            <button
              onClick={onOpenExcelImport || onOpenDataManagement}
              className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 px-2.5 py-1.5 font-semibold text-emerald-800 border border-emerald-300 hover:bg-emerald-100 transition shadow-2xs"
              title="Impor Data Anak dari Berkas Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Impor Excel</span>
            </button>

            {/* PWA Install Button for Offline Work (Luar Jaringan) */}
            <PWAInstallButton />

            {/* Cloud & User Auth Status */}
            <div className="flex items-center gap-1.5 pl-2 border-l border-slate-200 ml-1">
              {isAdmin && onOpenAdminPanel && (
                <button
                  type="button"
                  onClick={onOpenAdminPanel}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white px-2.5 py-1.5 font-semibold shadow-2xs transition whitespace-nowrap shrink-0"
                  title="Buka Panel Administrator"
                >
                  <Shield className="w-3.5 h-3.5 text-sky-400" />
                  <span>Panel Admin</span>
                </button>
              )}
              {currentUser ? (
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={onOpenProfile}
                    className="flex flex-col items-end text-right hover:bg-slate-100 px-2 py-1 rounded-md transition"
                    title={`Masuk sebagai ${currentUser.email || currentUser.displayName || 'Pekerja Sosial'}`}
                  >
                    <span className="font-bold text-slate-800 text-[11px] leading-tight truncate max-w-[110px]">
                      {currentUser.displayName || peksosName}
                    </span>
                    <span className="text-[9px] text-emerald-600 font-bold flex items-center gap-1">
                      <CloudCheck className="w-2.5 h-2.5" /> {isAdmin ? 'Admin' : 'Peksos'}
                    </span>
                  </button>
                  <button
                    onClick={onSignOut}
                    className="text-slate-500 hover:text-rose-600 px-2 py-1.5 rounded-md hover:bg-rose-50 transition flex items-center gap-1 text-[11px] font-semibold"
                    title="Keluar & Kunci Sesi"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span className="hidden xl:inline">Keluar</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={onOpenAuthModal}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white px-3 py-1.5 font-bold shadow-xs transition"
                  title="Masuk / Daftar Akun Pekerja Sosial (semarakppsgbr)"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Masuk Peksos</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

