export type RiskLevel = 'Rendah' | 'Sedang' | 'Tinggi' | 'Kritis';

export type ClientStatus =
  | 'Calon Klien (Proses Seleksi)'
  | 'Kasus Aktif'
  | 'Terminasi (Selesai)'
  | 'Referal (Rujukan)'
  | 'Drop Out'
  | 'Ditolak (Tidak Memenuhi Syarat)';

export type MultidisciplinaryRole =
  | 'Pekerja Sosial'
  | 'Instruktur Vokasi'
  | 'Pengasuh Asrama'
  | 'Tenaga Medis'
  | 'Psikolog Klinis';

export interface InterventionLogItem {
  id: string;
  tanggal: string;
  deskripsi: string;
  indikator: string;
  skorKomposit?: number; // 0 - 100 Keberfungsian Sosial
  skorBiologis?: number; // 0 - 100 Kesehatan & Kedisiplinan Fisik
  skorPsikologis?: number; // 0 - 100 Regulasi Emosi & Kestabilan
  skorSosial?: number; // 0 - 100 Adaptasi Sosial & Relasi Sebaya
  skorKemandirian?: number; // 0 - 100 Vokasional & Tanggung Jawab

  // Format SOAP & Peran Multidisiplin
  isSOAP?: boolean;
  peranPelaksana?: MultidisciplinaryRole;
  subjective?: string; // S: Keluhan / Ungkapan Klien / Wali
  objective?: string; // O: Temuan Observasi / Perilaku Terukur / Presensi
  assessment?: string; // A: Analisis Klinis / Capaian Dinamika Sosial
  plan?: string; // P: Rencana Intervensi / Tugas Mandiri / Rujukan
}

export interface PancaKarakterScores {
  id: string;
  tanggal: string;
  berehan: number; // 20 - 100 (Béréhan: Solidaritas, Empati, Kedermawanan)
  calakan: number; // 20 - 100 (Calakan: Cerdas, Kognitif, Literasi PKBM, Berpikir Kritis)
  waringkas: number; // 20 - 100 (Waringkas: Tangkas, Sigap, Disiplin Waktu, Etos Kerja)
  motekar: number; // 20 - 100 (Motékar: Kreatif, Inovatif, Kejuruan/Vokasi, Wirausaha)
  berseka: number; // 20 - 100 (Berséka: Bersih Diri & Lingkungan, Higienis, Nilai Spiritual)
  skorKomposit: number; // Rata-rata 5 karakter (0 - 100)
  catatan?: string;
  penilai?: string;
}

export type AftercarePeriod = 'Bulan ke-1' | 'Bulan ke-3' | 'Bulan ke-6' | 'Bulan ke-12' | 'Pemantauan Insidental';

export type AftercareContactMethod =
  | 'Home Visit (Kunjungan Rumah)'
  | 'Panggilan Telepon / Video Call'
  | 'Kunjungan ke Sentra / Balai'
  | 'Laporan Mitra PKBM / Tempat Magang';

export type ReintegrationStatus = 'Mandiri Stabil' | 'Dalam Pendampingan' | 'Berisiko Relaps / Rentan';

export interface AftercareFollowUpItem {
  id: string;
  tanggal: string;
  periode: AftercarePeriod;
  metodeKontak: AftercareContactMethod;
  statusReintegrasi: ReintegrationStatus;
  kondisiSekolahKerja: string;
  kondisiKeluarga: string;
  catatanPeksos: string;
}

export interface ClientFormData {
  // Wilayah & Biodata
  kabupatenKota: string;
  kecamatan: string;
  desa: string;
  alamat: string;
  tempatLahir: string;
  tanggalLahir: string;
  agama: string;
  angkatan: string;
  
  // Identitas & Pendidikan
  statusIdentitas: string;
  noIdentitas: string; // NIK
  pendidikan: string;
  jurusan: string;
  putusSekolah: string;
  kondisiPendidikan: string;

  // Wali & Sosioekonomi
  tipePengasuh?: 'Orang Tua' | 'Wali';
  namaAyah?: string;
  statusAyah?: 'Masih Hidup' | 'Meninggal Dunia' | 'Tidak Diketahui' | 'Terputus Kontak';
  pekerjaanAyah?: string;
  namaIbu?: string;
  statusIbu?: 'Masih Hidup' | 'Meninggal Dunia' | 'Tidak Diketahui' | 'Terputus Kontak';
  pekerjaanIbu?: string;
  namaWali: string;
  hubunganWali?: string;
  alasanDenganWali?: string;
  kontakWali: string;
  pekerjaanOrangTua: string;
  penghasilanBulanan: string;
  desil: string;
  bantuan: string;
  bpjs: string;
  pekerjaAnak: string;
  pekerjaAnakTahun: string;
  tinggalJalan: string;

  // Asesmen & Risiko
  tingkatRisiko: RiskLevel;
  asesmenKronologi: string;
  alasanMasuk?: string;

  // Metodologi & Instrumen Penggalian Data Asesmen Peksos
  asesmenMetodePenggalian?: string[]; // Wawancara Anak, Home Visit, Observasi, dll.
  asesmenSumberInforman?: string[]; // Anak, Wali, Pihak Sekolah/PKBM, dll.
  asesmenInstrumenDigunakan?: string[]; // Genogram, Ecomap, Social Roadmap, Life History Grid, dll.
  asesmenKecukupanData?: string; // Data Lengkap, Perlu Asesmen Lanjutan, dll.
  asesmenCatatanPenggalian?: string; // Catatan metodologi & informan lapangan
  genogramCatatan?: string; // Temuan pohon keluarga 3 generasi & pola asuh
  genogramData?: any; // Data struktur node dan relasi genogram
  genogramImage?: string; // Data URL PNG diagram genogram
  ecomapCatatan?: string; // Temuan pemetaan ekologi & jejaring sistem sosial
  ecomapData?: any; // Data struktur node dan relasi ecomap
  ecomapImage?: string; // Data URL PNG diagram ecomap
  socialRoadmapCatatan?: string; // Peta jalan 3 fase perjalanan sosial & kemandirian anak

  // Modul Kesehatan Fisik Dasar & Antropometri Balai (Balai Health Record)
  kesehatanGolonganDarah?: string; // A, B, AB, O, Belum Tahu
  kesehatanTinggiBadan?: number; // cm
  kesehatanBeratBadan?: number; // kg
  kesehatanIMT?: number; // Indeks Massa Tubuh
  kesehatanStatusGizi?: string; // Gizi Kurang, Normal, Overweight, Obesitas
  kesehatanStatusImunisasi?: string; // Lengkap, Tidak Lengkap, Belum Tahu
  kesehatanRiwayatAlergi?: string;
  kesehatanSkriningZat?: string; // Bebas Zat, Lem / Inhalan, Rokok, NAPZA
  kesehatanPenyakitKulit?: string; // Bebas Keluhan, Scabies / Gudik, Jamur Kulit
  kesehatanCatatanKlinik?: string; // Catatan pemeriksaan medis & obat

  asesmenBiologis: string;
  asesmenPsikologis: string;
  asesmenSosial: string;
  asesmenSpiritual: string;
  asesmenKebutuhanDasar: string;
  asesmenPemecahanMasalah: string;
  asesmenPeranSosial: string;
  asesmenPemaknaan: string; // Meaning-making with Gemini AI

  // Intervensi
  intervensiTujuan: string;
  intervensiStrategi: string;
  aiIntervensiTujuan?: string; // Draft Rekomendasi Tujuan AI
  aiIntervensiStrategi?: string; // Draft Rekomendasi Strategi AI
  aiIntervensiIndikator?: string[]; // Indikator Usulan AI
  aiIntervensiGeneratedAt?: string; // Timestamp perumusan AI

  // Evaluasi & Terminasi
  evaluasiPerkembangan: string;
  evaluasiHambatan: string;
  terminasiStatus: ClientStatus;
  terminasiAlasan: string;
  evaluasiSkorAkhir?: number; // 0 - 100
  evaluasiSkorBiologis?: number;
  evaluasiSkorPsikologis?: number;
  evaluasiSkorSosial?: number;
  evaluasiSkorKemandirian?: number;

  // Rubrik Panca Karakter Jabar (Béréhan, Calakan, Waringkas, Motékar, Berséka)
  pancaKarakterHistory?: PancaKarakterScores[];
  pancaKarakterTerakhir?: PancaKarakterScores;

  // Bimbingan Lanjut (Aftercare) & Keberlanjutan Sekolah
  aftercareStatusPendidikan?: string; // Formal, Non-Formal (PKBM), Vokasional, Belum Bersekolah, dll.
  aftercareNamaSekolah?: string; // Nama Sekolah Formal / Lembaga PKBM
  aftercareJenjang?: string; // SD / SMP / SMA / SMK / Paket A / Paket B / Paket C
  aftercareStatusSiswa?: string; // Aktif Bersekolah, Proses Daftar, Terkendala Biaya/NISN, dll.
  aftercareCatatanPendidikan?: string; // Catatan monitoring peksos

  // Buku Pantau Pasca-Binaan (Aftercare Follow-Up Logbook)
  aftercareFollowUps?: AftercareFollowUpItem[];

  // Seleksi
  seleksiCatatan: string;
  seleksiKeputusan: ClientStatus;
}

// 1. Modul Sidang Kasus Terpadu (Case Conference / Case Review)
export type CaseConferenceType = 
  | 'Sidang Awal (Initial Case Review)' 
  | 'Sidang Perkembangan (Progress Review)' 
  | 'Sidang Alih Jurusan / Rujukan Khusus' 
  | 'Sidang Pra-Terminasi & Reintegrasi' 
  | 'Sidang Penanganan Krisis / Kasus Darurat';

export interface CaseConferenceItem {
  id: string;
  tanggal: string; // YYYY-MM-DD
  waktu?: string; // HH:mm
  jenisSidang: CaseConferenceType;
  judul: string;
  pimpinanSidang: string; // e.g. "Kepala Balai" atau "Koordinator Peksos"
  notulis: string;
  pesertaHadir: string[]; // nama-nama tim multidisiplin
  latarBelakangKasus: string;
  dinamikaDanPembahasan: string; // ringkasan diskusi
  keputusanSidang: string; // rekomendasi hasil
  rencanaAksiTindakLanjut: string;
  statusPersetujuan: 'Disetujui Tim Sidang' | 'Perlu Pendalaman Kasus' | 'Rujukan Eksternal';
  diverifikasiOleh?: string;
}

// 2. Lampiran Berkas Digital Klien (Digital Case File & Document Storage)
export type ClientAttachmentCategory = 
  | 'Kartu Keluarga (KK)'
  | 'Akta Kelahiran'
  | 'KTP / KIA Anak'
  | 'Surat Rujukan / Rekomendasi Dinsos'
  | 'Surat Pernyataan / Izin Binaan Orang Tua'
  | 'Surat Bebas Narkoba / Skrining Medis'
  | 'Ijazah / Rapor Terakhir'
  | 'Sertifikat Pelatihan Vokasi'
  | 'Foto Dokumentasi Home Visit'
  | 'Dokumen Pendukung Lainnya';

export interface ClientAttachmentItem {
  id: string;
  namaBerkas: string;
  kategori: ClientAttachmentCategory;
  tipeFile: 'image/png' | 'image/jpeg' | 'application/pdf' | string;
  ukuranKb: number;
  dataUrl?: string; // Base64 dataURL
  tanggalUnggah: string;
  diunggahOleh: string;
  keterangan?: string;
}

// 3. Kontrak Pelayanan Sosial (Durasi: 3 Bulan)
export interface SocialContractData {
  nomorKontrak: string;
  tanggalMulai: string; // YYYY-MM-DD
  tanggalSelesai: string; // persis 3 bulan dari tanggal mulai
  durasiBulan: number; // default 3
  namaKepalaBalai: string;
  nipKepalaBalai: string;
  namaPeksosPendamping: string;
  namaWali: string;
  hubunganWali: string;
  nikWali: string;
  alamatWali: string;
  namaAnak: string;
  jurusanVokasi: string;
  asramaBinaan: string;
  komitmenKhusus?: string;
  statusKontrak: 'Aktif Berjalan' | 'Selesai 3 Bulan' | 'Dibatalkan / Terminasi Dini';
  tanggalTandaTangan: string;
  ditandatangani: boolean;
}

export interface Client {
  id: string;
  nama: string;
  umur: number;
  gender: 'Laki-laki' | 'Perempuan';
  status: ClientStatus;
  peksosEmail: string;
  riwayatPenyakit: string[];
  pelaksanaanIntervensi: InterventionLogItem[];
  caseConferences?: CaseConferenceItem[];
  berkasDigital?: ClientAttachmentItem[];
  kontrakPelayanan?: SocialContractData;
  formData: ClientFormData;
  createdAt?: string;
  updatedAt?: string;
}

export type UserRole = 'admin' | 'peksos';

export interface AppUserProfile {
  uid: string;
  email: string;
  nama: string;
  role: UserRole;
  disabled?: boolean;
  createdAt?: string;
  lastLoginAt?: string;
  updatedAt?: string;
}


