import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  ClipboardCheck, 
  FileText, 
  Brain, 
  Handshake, 
  Flag, 
  Printer, 
  Check, 
  AlertCircle, 
  Save,
  MapPin,
  Calendar,
  AlertTriangle,
  Sparkles,
  Cloud,
  CloudCheck,
  FolderLock,
  FileCheck
} from 'lucide-react';
import { 
  Client, 
  ClientStatus, 
  InterventionLogItem, 
  CaseConferenceItem, 
  ClientAttachmentItem, 
  SocialContractData,
  AppUserProfile
} from './types';
import { INITIAL_CLIENTS, DEFAULT_JURUSAN } from './data/defaultData';
import { 
  auth, 
  onAuthStateChanged, 
  logoutUser, 
  saveClient as saveClientToFirestore, 
  removeClient as removeClientFromFirestore,
  subscribeClients,
  testConnection,
  syncUserProfile,
  isBootstrappedAdminEmail
} from './firebase';
import { User as FirebaseUser } from 'firebase/auth';
import { HeaderNav } from './components/HeaderNav';
import { AuthLandingPage } from './components/AuthLandingPage';
import { TabSeleksi } from './components/tabs/TabSeleksi';
import { TabProfil } from './components/tabs/TabProfil';
import { TabAsesmen } from './components/tabs/TabAsesmen';
import { TabIntervensi } from './components/tabs/TabIntervensi';
import { TabEvaluasi } from './components/tabs/TabEvaluasi';
import { TabCetak } from './components/tabs/TabCetak';
import { AddClientModal } from './components/modals/AddClientModal';
import { GlobalDashboardModal } from './components/modals/GlobalDashboardModal';
import { DataManagementModal } from './components/modals/DataManagementModal';
import { AIConsultModal } from './components/modals/AIConsultModal';
import { ManageJurusanModal } from './components/modals/ManageJurusanModal';
import { ProfileModal } from './components/modals/ProfileModal';
import { AuthModal } from './components/modals/AuthModal';
import { CaseConferenceModal } from './components/modals/CaseConferenceModal';
import { DigitalAttachmentModal } from './components/modals/DigitalAttachmentModal';
import { SocialContractModal } from './components/modals/SocialContractModal';
import { GlobalQuickSearchModal } from './components/modals/GlobalQuickSearchModal';
import { AdminPanelModal } from './components/modals/AdminPanelModal';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';
import { generateClientId } from './utils/clientIdGenerator';

const getScopedClientCacheKey = (uid: string) => `rsa_jabar_clients_uid_${uid}`;
const LEGACY_CLIENT_CACHE_KEY = 'rsa_jabar_clients_v2';
const IDLE_TIMEOUT_STORAGE_KEY = 'rsa_jabar_idle_minutes';

export default function App() {
  // Persistence state: strictly empty until authenticated to prevent child data leakage
  const [clients, setClients] = useState<Record<string, Client>>({});

  const [jurusanList, setJurusanList] = useState<string[]>(() => {
    const saved = localStorage.getItem('rsa_jabar_jurusan');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return DEFAULT_JURUSAN;
  });

  const [peksosName, setPeksosName] = useState<string>('Pekerja Sosial');

  // Firebase auth & cloud state
  const [authReady, setAuthReady] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<AppUserProfile | null>(null);
  const [isCloudConnected, setIsCloudConnected] = useState<boolean>(false);
  const [sessionNotice, setSessionNotice] = useState<{ type: 'info' | 'error'; text: string } | null>(null);
  const [idleTimeoutMinutes, setIdleTimeoutMinutes] = useState<number>(() => {
    const raw = localStorage.getItem(IDLE_TIMEOUT_STORAGE_KEY);
    const parsed = raw !== null ? Number(raw) : 30;
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : 30;
  });

  const isAdmin = Boolean(
    currentUser &&
      (isBootstrappedAdminEmail(currentUser.email) || userProfile?.role === 'admin')
  );

  // Navigation & filters
  const [currentClientId, setCurrentClientId] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<string>('tab-profil');
  const [regionFilter, setRegionFilter] = useState('');
  const [angkatanFilter, setAngkatanFilter] = useState('');
  const [onlyActiveFilter, setOnlyActiveFilter] = useState(true);

  // Modals
  const [isAddClientOpen, setIsAddClientOpen] = useState(false);
  const [isGlobalDashboardOpen, setIsGlobalDashboardOpen] = useState(false);
  const [isDataManagementOpen, setIsDataManagementOpen] = useState(false);
  const [dataManagementTab, setDataManagementTab] = useState<'export' | 'import'>('export');
  const [isAIConsultOpen, setIsAIConsultOpen] = useState(false);
  const [isManageJurusanOpen, setIsManageJurusanOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isCaseConferenceOpen, setIsCaseConferenceOpen] = useState(false);
  const [isAttachmentsOpen, setIsAttachmentsOpen] = useState(false);
  const [isSocialContractOpen, setIsSocialContractOpen] = useState(false);
  const [isQuickSearchOpen, setIsQuickSearchOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);

  const closeAllWorkspaceModals = () => {
    setIsAddClientOpen(false);
    setIsGlobalDashboardOpen(false);
    setIsDataManagementOpen(false);
    setIsAIConsultOpen(false);
    setIsManageJurusanOpen(false);
    setIsProfileOpen(false);
    setIsAuthModalOpen(false);
    setIsCaseConferenceOpen(false);
    setIsAttachmentsOpen(false);
    setIsSocialContractOpen(false);
    setIsQuickSearchOpen(false);
    setIsAdminPanelOpen(false);
  };

  const clearSensitiveSessionData = (uid?: string | null) => {
    try {
      localStorage.removeItem(LEGACY_CLIENT_CACHE_KEY);
      if (uid) {
        localStorage.removeItem(getScopedClientCacheKey(uid));
      }
    } catch {}
    setClients({});
    setCurrentClientId(null);
    setUserProfile(null);
    closeAllWorkspaceModals();
  };

  // Shortcut Ctrl+K / Cmd+K for Global Quick Search (only active when authenticated)
  useEffect(() => {
    if (!currentUser) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        setIsQuickSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentUser]);

  // Toast
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  // Sync to user-scoped localStorage ONLY while authenticated
  useEffect(() => {
    if (!currentUser) return;
    if (Object.keys(clients).length === 0) return;
    try {
      localStorage.setItem(getScopedClientCacheKey(currentUser.uid), JSON.stringify(clients));
    } catch (err) {
      console.error('Gagal menyimpan data ke localStorage:', err);
    }
  }, [clients, currentUser]);

  useEffect(() => {
    localStorage.setItem('rsa_jabar_jurusan', JSON.stringify(jurusanList));
  }, [jurusanList]);

  useEffect(() => {
    localStorage.setItem(IDLE_TIMEOUT_STORAGE_KEY, String(idleTimeoutMinutes));
  }, [idleTimeoutMinutes]);

  // Firebase initialization and strict auth-gated connection verification
  useEffect(() => {
    // Always purge un-scoped legacy cache on boot so signed-out visitors never retain old PII
    try {
      localStorage.removeItem(LEGACY_CLIENT_CACHE_KEY);
    } catch {}

    const saved = localStorage.getItem('rsa_active_firebase_config');
    if (saved && saved.includes('semarakppsgbr')) {
      localStorage.removeItem('rsa_active_firebase_config');
    }

    testConnection().then((connected) => {
      if (auth.currentUser) {
        setIsCloudConnected(connected);
      }
    });

    let unsubscribeFirestore: (() => void) | null = null;
    let isCancelled = false;

    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (unsubscribeFirestore) {
        unsubscribeFirestore();
        unsubscribeFirestore = null;
      }

      if (!user) {
        setCurrentUser(null);
        setIsCloudConnected(false);
        clearSensitiveSessionData(null);
        if (!isCancelled) setAuthReady(true);
        return;
      }

      try {
        const profile = await syncUserProfile(user);
        if (isCancelled) return;

        setUserProfile(profile);
        setCurrentUser(user);
        setIsCloudConnected(true);
        setPeksosName(profile.nama || user.displayName || user.email || 'Pekerja Sosial');
        setSessionNotice(null);

        // Load user-scoped offline cache immediately for offline PWA resilience
        let cachedClients: Record<string, Client> = {};
        try {
          const rawCached = localStorage.getItem(getScopedClientCacheKey(user.uid));
          if (rawCached) {
            const parsed = JSON.parse(rawCached);
            if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
              cachedClients = parsed;
              setClients(parsed);
            }
          }
        } catch {}

        // Attach Firestore listener only when authenticated & verified active
        unsubscribeFirestore = subscribeClients(
          (remoteClients) => {
            if (Object.keys(remoteClients).length > 0) {
              setClients(remoteClients);
            } else if (Object.keys(cachedClients).length === 0) {
              // Initial database seeding if empty
              setClients(INITIAL_CLIENTS);
              Object.values(INITIAL_CLIENTS).forEach((c) => {
                saveClientToFirestore(c).catch(console.error);
              });
            }
          },
          (err) => {
            console.warn('Firestore subscription notice (using scoped local cache):', err);
          }
        );
      } catch (err: any) {
        // Account disabled by Admin
        await logoutUser().catch(() => {});
        clearSensitiveSessionData(user.uid);
        setCurrentUser(null);
        setIsCloudConnected(false);
        setSessionNotice({
          type: 'error',
          text: err?.message || 'Akses akun ditolak oleh Administrator.',
        });
      } finally {
        if (!isCancelled) setAuthReady(true);
      }
    });

    return () => {
      isCancelled = true;
      if (unsubscribeFirestore) {
        unsubscribeFirestore();
      }
      unsubscribeAuth();
    };
  }, []);

  const handleSignOut = async (reason?: string) => {
    const uid = currentUser?.uid || auth.currentUser?.uid || null;
    try {
      clearSensitiveSessionData(uid);
      await logoutUser();
      setCurrentUser(null);
      setIsCloudConnected(false);
      setSessionNotice({
        type: 'info',
        text:
          reason ||
          'Anda telah keluar dari sistem. Seluruh data anak telah dibersihkan dari memori perangkat.',
      });
      showToast('Berhasil keluar. Sesi & data anak telah dikunci.', 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal keluar dari sesi Firebase.', 'error');
    }
  };

  // Auto-logout idle timer to prevent data exposure on unattended computers
  useEffect(() => {
    if (!currentUser || idleTimeoutMinutes <= 0) return;

    let timeoutId: ReturnType<typeof setTimeout>;
    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        handleSignOut(
          `Sesi dikunci otomatis setelah ${idleTimeoutMinutes} menit tanpa aktivitas untuk melindungi data anak.`
        );
      }, idleTimeoutMinutes * 60 * 1000);
    };

    const events = ['mousemove', 'keydown', 'mousedown', 'touchstart', 'scroll'];
    events.forEach((ev) => window.addEventListener(ev, resetTimer, { passive: true }));
    resetTimer();

    return () => {
      clearTimeout(timeoutId);
      events.forEach((ev) => window.removeEventListener(ev, resetTimer));
    };
  }, [currentUser, idleTimeoutMinutes]);

  // Derived lists
  const clientList = useMemo(() => Object.values(clients), [clients]);

  const allAngkatanList = useMemo(() => {
    const set = new Set<string>();
    clientList.forEach((c) => {
      if (c?.formData?.angkatan) {
        c.formData.angkatan.split(',').forEach((a) => {
          if (a.trim()) set.add(a.trim());
        });
      }
    });
    return Array.from(set).sort();
  }, [clientList]);

  const filteredClients = useMemo(() => {
    return clientList.filter((c) => {
      if (!c) return false;
      const matchRegion = !regionFilter || c.formData?.kabupatenKota === regionFilter;
      const matchAngkatan = !angkatanFilter || (c.formData?.angkatan || '').includes(angkatanFilter);
      let matchStatus = true;
      if (onlyActiveFilter) {
        const s = c.status || '';
        matchStatus = !['Terminasi (Selesai)', 'Drop Out', 'Ditolak (Tidak Memenuhi Syarat)', 'Referal (Rujukan)'].includes(s);
      }
      return matchRegion && matchAngkatan && matchStatus;
    });
  }, [clientList, regionFilter, angkatanFilter, onlyActiveFilter]);

  // Keep currentClientId valid
  useEffect(() => {
    if (filteredClients.length > 0) {
      if (!currentClientId || !filteredClients.find((c) => c.id === currentClientId)) {
        setCurrentClientId(filteredClients[0].id);
      }
    } else if (clientList.length > 0 && !currentClientId) {
      setCurrentClientId(clientList[0].id);
    }
  }, [filteredClients, currentClientId, clientList]);

  const currentClient = currentClientId ? clients[currentClientId] : null;

  // Handler for Global Quick Search selection with optional direct tab navigation
  const handleSelectClientAndTab = (clientId: string, targetTab?: string) => {
    // If client is filtered out by status or region, reset filters to show this client
    const target = clients[clientId];
    if (target) {
      if (onlyActiveFilter && target.status?.includes('Terminasi')) {
        setOnlyActiveFilter(false);
      }
      if (regionFilter && target.formData.kabupatenKota !== regionFilter) {
        setRegionFilter('');
      }
      if (angkatanFilter && target.formData.angkatan !== angkatanFilter) {
        setAngkatanFilter('');
      }
    }
    setCurrentClientId(clientId);
    if (targetTab) {
      setActiveTab(targetTab);
    }
  };

  // Handlers for modifying client data
  const handleUpdateField = (key: string, value: any) => {
    if (!currentClientId) return;

    setClients((prev) => {
      const target = prev[currentClientId];
      if (!target) return prev;

      if (key === 'nama' || key === 'umur' || key === 'gender' || key === 'status') {
        return {
          ...prev,
          [currentClientId]: {
            ...target,
            [key]: value,
          },
        };
      }

      return {
        ...prev,
        [currentClientId]: {
          ...target,
          formData: {
            ...target.formData,
            [key]: value,
          },
        },
      };
    });
  };

  const handleAddPenyakit = (namaPenyakit: string) => {
    if (!currentClientId) return;
    setClients((prev) => {
      const target = prev[currentClientId];
      if (!target) return prev;
      return {
        ...prev,
        [currentClientId]: {
          ...target,
          riwayatPenyakit: [...(target.riwayatPenyakit || []), namaPenyakit],
        },
      };
    });
    showToast(`Penyakit '${namaPenyakit}' ditambahkan.`, 'success');
  };

  const handleRemovePenyakit = (index: number) => {
    if (!currentClientId) return;
    setClients((prev) => {
      const target = prev[currentClientId];
      if (!target) return prev;
      const updated = [...(target.riwayatPenyakit || [])];
      updated.splice(index, 1);
      return {
        ...prev,
        [currentClientId]: {
          ...target,
          riwayatPenyakit: updated,
        },
      };
    });
  };

  const handleAddIntervensiLog = (item: Omit<InterventionLogItem, 'id'>) => {
    if (!currentClientId) return;
    const newItem: InterventionLogItem = {
      ...item,
      id: `log-${Date.now()}`,
    };
    setClients((prev) => {
      const target = prev[currentClientId];
      if (!target) return prev;
      return {
        ...prev,
        [currentClientId]: {
          ...target,
          pelaksanaanIntervensi: [newItem, ...(target.pelaksanaanIntervensi || [])],
        },
      };
    });
  };

  const handleRemoveIntervensiLog = (id: string) => {
    if (!currentClientId) return;
    setClients((prev) => {
      const target = prev[currentClientId];
      if (!target) return prev;
      return {
        ...prev,
        [currentClientId]: {
          ...target,
          pelaksanaanIntervensi: (target.pelaksanaanIntervensi || []).filter((l) => l.id !== id),
        },
      };
    });
    showToast('Log intervensi dihapus.', 'success');
  };

  // Case Conference handlers
  const handleSaveCaseConference = (item: CaseConferenceItem) => {
    if (!currentClientId) return;
    setClients((prev) => {
      const target = prev[currentClientId];
      if (!target) return prev;
      const existing = target.caseConferences || [];
      const index = existing.findIndex((c) => c.id === item.id);
      let updatedConferences: CaseConferenceItem[];
      if (index >= 0) {
        updatedConferences = [...existing];
        updatedConferences[index] = item;
      } else {
        updatedConferences = [item, ...existing];
      }
      const updatedClient = {
        ...target,
        caseConferences: updatedConferences,
        updatedAt: new Date().toISOString(),
      };
      if (isCloudConnected) {
        saveClientToFirestore(updatedClient).catch(console.error);
      }
      return {
        ...prev,
        [currentClientId]: updatedClient,
      };
    });
  };

  const handleDeleteCaseConference = (id: string) => {
    if (!currentClientId) return;
    setClients((prev) => {
      const target = prev[currentClientId];
      if (!target) return prev;
      const updatedClient = {
        ...target,
        caseConferences: (target.caseConferences || []).filter((c) => c.id !== id),
        updatedAt: new Date().toISOString(),
      };
      if (isCloudConnected) {
        saveClientToFirestore(updatedClient).catch(console.error);
      }
      return {
        ...prev,
        [currentClientId]: updatedClient,
      };
    });
  };

  // Digital Attachment handlers with integrity validation & persistent sync
  const handleSaveAttachment = async (
    item: ClientAttachmentItem
  ): Promise<{ success: boolean; error?: string }> => {
    if (!currentClientId) {
      const error = 'Tidak ada data anak binaan aktif yang dipilih.';
      showToast(error, 'error');
      return { success: false, error };
    }

    const target = clients[currentClientId];
    if (!target) {
      const error = 'Data anak binaan tidak ditemukan.';
      showToast(error, 'error');
      return { success: false, error };
    }

    // 1. Validasi integritas metadata & string Base64 (termasuk mencegah unggahan KK kosong)
    const cleanName = (item?.namaBerkas || '').trim();
    const cleanCategory = item?.kategori;
    const cleanMime = (item?.tipeFile || '').trim();
    const cleanDataUrl = (item?.dataUrl || '').trim();

    const base64Match = cleanDataUrl.match(/^data:([^;]+);base64,([A-Za-z0-9+/=]+)$/);
    const base64Payload = base64Match?.[2] || '';

    if (!item?.id || !cleanName || !cleanCategory || !cleanMime || !base64Match || base64Payload.length < 16 || item.ukuranKb <= 0) {
      const error =
        cleanCategory === 'Kartu Keluarga (KK)'
          ? 'Unggahan Kartu Keluarga (KK) kosong atau file rusak/tidak valid. Silakan pilih file gambar/PDF KK yang benar terlebih dahulu.'
          : 'Data lampiran berkas kosong atau format Base64 tidak valid. Silakan pilih ulang berkas Anda.';
      showToast(error, 'error');
      return { success: false, error };
    }

    const sanitizedItem: ClientAttachmentItem = {
      id: item.id,
      namaBerkas: cleanName,
      kategori: cleanCategory,
      tipeFile: cleanMime,
      ukuranKb: Math.max(1, Math.round(item.ukuranKb)),
      dataUrl: cleanDataUrl,
      tanggalUnggah: item.tanggalUnggah || new Date().toISOString().split('T')[0],
      diunggahOleh: item.diunggahOleh || peksosName || 'Pekerja Sosial',
      ...(item.keterangan && item.keterangan.trim() ? { keterangan: item.keterangan.trim() } : {}),
    };

    const existing = target.berkasDigital || [];
    const updatedClient: Client = {
      ...target,
      berkasDigital: [sanitizedItem, ...existing],
      updatedAt: new Date().toISOString(),
    };

    // 2. Cek batas ukuran dokumen Firestore (~1 MiB = 1.048.576 bytes)
    const serializedClientSize = new Blob([JSON.stringify(updatedClient)]).size;
    if (serializedClientSize > 980_000) {
      const error = `Total ukuran berkas klien ini (${Math.round(serializedClientSize / 1024)} KB) melebihi batas maksimal dokumen Cloud Firestore (980 KB). Gunakan foto beresolusi lebih kecil atau hapus berkas lama.`;
      showToast(error, 'error');
      return { success: false, error };
    }

    const nextClients: Record<string, Client> = {
      ...clients,
      [currentClientId]: updatedClient,
    };

    // 3. Simpan ke localStorage terisolasi UID pengguna terlebih dahulu secara aman
    const cacheKey = auth.currentUser
      ? getScopedClientCacheKey(auth.currentUser.uid)
      : LEGACY_CLIENT_CACHE_KEY;

    try {
      localStorage.setItem(cacheKey, JSON.stringify(nextClients));
    } catch (storageErr: any) {
      const error =
        storageErr?.name === 'QuotaExceededError'
          ? 'Penyimpanan lokal browser (LocalStorage) sudah penuh! Silakan cadangkan arsip JSON dan hapus berkas lama terlebih dahulu.'
          : 'Gagal menyimpan berkas ke penyimpanan lokal perangkat.';
      showToast(error, 'error');
      return { success: false, error };
    }

    // 4. Sinkronkan ke Firestore jika pengguna sedang login / terhubung ke Cloud
    if (auth.currentUser) {
      try {
        await saveClientToFirestore(updatedClient);
      } catch (cloudErr: any) {
        console.error('Gagal menyimpan berkas ke Firestore:', cloudErr);
        // Kembalikan localStorage agar konsisten jika Firestore menolak write
        try {
          localStorage.setItem(cacheKey, JSON.stringify(clients));
        } catch {}
        const errMsg = cloudErr?.message || 'Koneksi atau izin Firestore gagal.';
        const error = `Gagal menyimpan berkas "${cleanName}" ke Cloud Firestore: ${errMsg}`;
        showToast(error, 'error');
        return { success: false, error };
      }
    }

    // 5. Terapkan ke state React setelah validasi dan penyimpanan terkonfirmasi
    setClients(nextClients);
    showToast(
      auth.currentUser
        ? `Berkas "${cleanName}" berhasil disimpan & disinkronkan ke Cloud Firestore!`
        : `Berkas "${cleanName}" berhasil disimpan di penyimpanan lokal perangkat.`,
      'success'
    );
    return { success: true };
  };

  const handleDeleteAttachment = (id: string) => {
    if (!currentClientId) return;
    setClients((prev) => {
      const target = prev[currentClientId];
      if (!target) return prev;
      const updatedClient = {
        ...target,
        berkasDigital: (target.berkasDigital || []).filter((b) => b.id !== id),
        updatedAt: new Date().toISOString(),
      };
      if (auth.currentUser) {
        saveClientToFirestore(updatedClient).catch((err) => {
          console.error(err);
          showToast('Gagal menghapus berkas di Cloud Firestore.', 'error');
        });
      }
      return {
        ...prev,
        [currentClientId]: updatedClient,
      };
    });
  };

  // Social Contract handler
  const handleSaveSocialContract = (contract: SocialContractData) => {
    if (!currentClientId) return;
    setClients((prev) => {
      const target = prev[currentClientId];
      if (!target) return prev;
      const updatedClient = {
        ...target,
        kontrakPelayanan: contract,
        updatedAt: new Date().toISOString(),
      };
      if (isCloudConnected) {
        saveClientToFirestore(updatedClient).catch(console.error);
      }
      return {
        ...prev,
        [currentClientId]: updatedClient,
      };
    });
  };

  const handleSaveNewClient = (data: {
    nama: string;
    kabupatenKota: string;
    angkatan: string;
    tanggalLahir: string;
    gender: 'Laki-laki' | 'Perempuan';
    status: ClientStatus;
  }) => {
    const newId = generateClientId({
      kabupatenKota: data.kabupatenKota,
      angkatan: data.angkatan || 'Angkatan I - 2026',
      existingClients: Object.values(clients),
    });
    const birthYear = data.tanggalLahir ? new Date(data.tanggalLahir).getFullYear() : 2012;
    const calculatedAge = Math.max(0, new Date().getFullYear() - birthYear);

    const newClient: Client = {
      id: newId,
      nama: data.nama,
      umur: calculatedAge,
      gender: data.gender,
      status: data.status,
      peksosEmail: 'peksos@jabarprov.go.id',
      riwayatPenyakit: [],
      pelaksanaanIntervensi: [],
      formData: {
        kabupatenKota: data.kabupatenKota,
        kecamatan: '',
        desa: '',
        alamat: '',
        tempatLahir: data.kabupatenKota,
        tanggalLahir: data.tanggalLahir,
        agama: 'Islam',
        angkatan: data.angkatan || 'Angkatan I - 2026',
        statusIdentitas: 'Memiliki KTP/KIA',
        noIdentitas: '',
        pendidikan: 'SMP / Sederajat',
        jurusan: jurusanList[0] || 'Otomotif',
        putusSekolah: 'Tidak (Lancar)',
        kondisiPendidikan: '',
        tipePengasuh: 'Orang Tua',
        namaAyah: '',
        statusAyah: 'Masih Hidup',
        pekerjaanAyah: '',
        namaIbu: '',
        statusIbu: 'Masih Hidup',
        pekerjaanIbu: '',
        namaWali: '',
        hubunganWali: '',
        alasanDenganWali: '',
        kontakWali: '',
        pekerjaanOrangTua: '',
        penghasilanBulanan: '< Rp 1 Juta',
        desil: 'Desil 2',
        bantuan: 'Tidak Ada Bantuan',
        bpjs: 'BPJS PBI (Pemerintah)',
        pekerjaAnak: 'Tidak',
        pekerjaAnakTahun: '',
        tinggalJalan: 'Tidak Pernah',
        tingkatRisiko: 'Rendah',
        asesmenKronologi: '',
        asesmenBiologis: '',
        asesmenPsikologis: '',
        asesmenSosial: '',
        asesmenSpiritual: '',
        asesmenKebutuhanDasar: '',
        asesmenPemecahanMasalah: '',
        asesmenPeranSosial: '',
        asesmenPemaknaan: '',

        // Modul Kesehatan Fisik Dasar & Antropometri Balai
        kesehatanGolonganDarah: 'Belum Tahu',
        kesehatanTinggiBadan: 0,
        kesehatanBeratBadan: 0,
        kesehatanIMT: 0,
        kesehatanStatusGizi: 'Belum Terhitung',
        kesehatanStatusImunisasi: 'Lengkap (Sesuai Usia)',
        kesehatanRiwayatAlergi: '',
        kesehatanSkriningZat: 'Bebas Zat (Bersih / Tidak Ada Riwayat)',
        kesehatanPenyakitKulit: 'Bebas Keluhan Kulit (Sehat)',
        kesehatanCatatanKlinik: '',

        intervensiTujuan: '',
        intervensiStrategi: '',
        aiIntervensiTujuan: '',
        aiIntervensiStrategi: '',
        aiIntervensiIndikator: [],
        aiIntervensiGeneratedAt: '',
        evaluasiPerkembangan: '',
        evaluasiHambatan: '',
        terminasiStatus: data.status,
        terminasiAlasan: '',

        // Aftercare & Panca Karakter
        aftercareFollowUps: [],
        pancaKarakterHistory: [],

        seleksiCatatan: 'Registrasi langsung melalui aplikasi.',
        seleksiKeputusan: data.status,
      },
    };

    setClients((prev) => ({
      ...prev,
      [newId]: newClient,
    }));
    // Also persist to Firestore
    saveClientToFirestore(newClient).catch((err) => console.warn('Saved locally, Firestore sync pending:', err));

    setCurrentClientId(newId);
    if (data.status === 'Calon Klien (Proses Seleksi)') {
      setActiveTab('tab-seleksi');
    } else {
      setActiveTab('tab-profil');
    }
    showToast(`Anak baru '${data.nama}' berhasil ditambahkan!`, 'success');
  };

  const handleOpenDataManagement = (tab: 'export' | 'import' = 'export') => {
    setDataManagementTab(tab);
    setIsDataManagementOpen(true);
  };

  const handleImportClients = (imported: Record<string, Client>, mode: 'merge' | 'replace' = 'merge') => {
    setClients((prev) => {
      const merged = mode === 'replace' ? imported : { ...prev, ...imported };
      const keys = Object.keys(merged);
      if (keys.length > 0 && (!currentClientId || !keys.includes(currentClientId))) {
        const firstNewKey = Object.keys(imported)[0] || keys[0];
        setCurrentClientId(firstNewKey);
      }
      return merged;
    });

    // Sync all imported clients to Firestore
    Object.values(imported).forEach((c) => {
      saveClientToFirestore(c).catch((err) => console.warn('Sync to Firestore pending:', err));
    });
  };

  const handleManualSave = async () => {
    const cacheKey = auth.currentUser
      ? getScopedClientCacheKey(auth.currentUser.uid)
      : LEGACY_CLIENT_CACHE_KEY;
    try {
      localStorage.setItem(cacheKey, JSON.stringify(clients));
    } catch (err) {
      showToast('Penyimpanan lokal browser penuh! Silakan ekspor cadangan JSON terlebih dahulu.', 'error');
      return;
    }
    if (currentClient) {
      if (auth.currentUser) {
        try {
          await saveClientToFirestore(currentClient);
          showToast('Data berhasil disimpan dan disinkronkan ke Cloud Firestore!', 'success');
        } catch (e: any) {
          showToast(`Data tersimpan lokal, namun gagal sinkron ke Cloud: ${e?.message || 'Error'}`, 'error');
        }
      } else {
        showToast('Data tersimpan di penyimpanan lokal.', 'success');
      }
    } else {
      showToast('Seluruh data berhasil disimpan dan disinkronkan.', 'success');
    }
  };

  // Admin exclusive handlers
  const handleUpdateClientStatusByAdmin = async (clientId: string, status: ClientStatus) => {
    if (!isAdmin) return;
    const target = clients[clientId];
    if (!target) return;
    const updatedClient: Client = {
      ...target,
      status,
      updatedAt: new Date().toISOString(),
    };
    setClients((prev) => ({
      ...prev,
      [clientId]: updatedClient,
    }));
    if (auth.currentUser) {
      try {
        await saveClientToFirestore(updatedClient);
        showToast(`Status ${target.nama} diperbarui menjadi "${status}".`, 'success');
      } catch (e: any) {
        showToast(`Status diubah lokal, namun gagal sinkron ke Cloud: ${e?.message || 'Error'}`, 'error');
      }
    }
  };

  const handleDeleteClientByAdmin = async (clientId: string) => {
    if (!isAdmin) {
      showToast('Aksi ditolak: hanya Administrator yang dapat menghapus data anak.', 'error');
      return;
    }
    const targetName = clients[clientId]?.nama || clientId;
    if (auth.currentUser) {
      try {
        await removeClientFromFirestore(clientId);
      } catch (e: any) {
        showToast(`Gagal menghapus dari Cloud Firestore: ${e?.message || 'Izin ditolak'}`, 'error');
        return;
      }
    }
    setClients((prev) => {
      const next = { ...prev };
      delete next[clientId];
      if (currentUser) {
        try {
          localStorage.setItem(getScopedClientCacheKey(currentUser.uid), JSON.stringify(next));
        } catch {}
      }
      return next;
    });
    if (currentClientId === clientId) {
      setCurrentClientId(null);
    }
    showToast(`Data anak "${targetName}" telah dihapus permanen.`, 'success');
  };

  const handleSeedInitialClients = async () => {
    if (!isAdmin) return;
    setClients(INITIAL_CLIENTS);
    if (auth.currentUser) {
      await Promise.all(
        Object.values(INITIAL_CLIENTS).map((c) => saveClientToFirestore(c).catch(console.error))
      );
    }
    showToast('Data contoh awal berhasil dimuat.', 'success');
  };

  const handleExportAllJSON = () => {
    if (clientList.length === 0) {
      showToast('Tidak ada data untuk dicadangkan.', 'error');
      return;
    }
    const blob = new Blob([JSON.stringify(clients, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Backup_RSA_Jabar_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('File cadangan JSON berhasil diunduh.', 'success');
  };

  // Loading gate before auth state resolves (never expose child data prematurely)
  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-2 border-sky-700 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-semibold text-slate-600">
            Memverifikasi sesi akses terenkripsi...
          </p>
        </div>
      </div>
    );
  }

  // Strict Auth Gate: signed-out users ONLY see the login landing page
  if (!currentUser) {
    return (
      <>
        {toast && (
          <div
            className={`fixed bottom-5 right-5 z-100 px-5 py-3 rounded-xl shadow-lg flex items-center gap-3 text-white text-xs sm:text-sm font-semibold ${
              toast.type === 'error' ? 'bg-rose-600' : 'bg-emerald-600'
            }`}
          >
            {toast.type === 'error' ? <AlertCircle className="w-5 h-5 shrink-0" /> : <Check className="w-5 h-5 shrink-0" />}
            <span>{toast.message}</span>
          </div>
        )}
        <AuthLandingPage
          onShowToast={showToast}
          onSuccess={(name) => setPeksosName(name)}
          sessionNotice={sessionNotice}
          onClearNotice={() => setSessionNotice(null)}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 flex flex-col font-sans">
      {/* Toast Alert */}
      {toast && (
        <div
          className={`fixed bottom-5 right-5 z-100 px-5 py-3 rounded-xl shadow-lg flex items-center gap-3 text-white text-xs sm:text-sm font-semibold transition-all duration-300 animate-in fade-in slide-in-from-bottom-5 ${
            toast.type === 'error' ? 'bg-rose-600' : 'bg-emerald-600'
          }`}
        >
          {toast.type === 'error' ? <AlertCircle className="w-5 h-5 shrink-0" /> : <Check className="w-5 h-5 shrink-0" />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Offline PWA Indicator */}
      <OfflineIndicator />

      {/* Navigation & Toolbar */}
      <HeaderNav
        clients={clientList}
        filteredClients={filteredClients}
        currentClientId={currentClientId}
        onSelectClient={setCurrentClientId}
        regionFilter={regionFilter}
        onRegionFilterChange={setRegionFilter}
        angkatanFilter={angkatanFilter}
        onAngkatanFilterChange={setAngkatanFilter}
        allAngkatanList={allAngkatanList}
        onlyActiveFilter={onlyActiveFilter}
        onToggleActiveFilter={() => setOnlyActiveFilter(!onlyActiveFilter)}
        onOpenAddClient={() => setIsAddClientOpen(true)}
        onOpenGlobalDashboard={() => setIsGlobalDashboardOpen(true)}
        onOpenDataManagement={() => handleOpenDataManagement('export')}
        onOpenExcelImport={() => handleOpenDataManagement('import')}
        onOpenAIConsult={() => setIsAIConsultOpen(true)}
        onOpenQuickSearch={() => setIsQuickSearchOpen(true)}
        peksosName={peksosName}
        onOpenProfile={() => setIsProfileOpen(true)}
        isCloudConnected={isCloudConnected}
        currentUser={currentUser}
        isAdmin={isAdmin}
        onOpenAdminPanel={() => setIsAdminPanelOpen(true)}
        onSignOut={() => handleSignOut()}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full no-print">
        {currentClient ? (
          <>
            {/* Active Client Banner Card */}
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200/90 p-5 sm:p-6 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-linear-to-br from-sky-500 to-indigo-600 text-white font-extrabold text-xl flex items-center justify-center shadow-xs shrink-0">
                  {currentClient.nama ? currentClient.nama.charAt(0).toUpperCase() : 'A'}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                      {currentClient.nama}
                    </h1>
                    {(currentClient.formData.tingkatRisiko === 'Tinggi' || currentClient.formData.tingkatRisiko === 'Kritis') && (
                      <span className="bg-rose-100 text-rose-800 text-[11px] font-extrabold px-2.5 py-0.5 rounded-full border border-rose-300 flex items-center gap-1 animate-pulse">
                        <AlertTriangle className="w-3 h-3 text-rose-600" />
                        RISIKO {currentClient.formData.tingkatRisiko.toUpperCase()}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 mt-1 font-medium">
                    <span className="font-mono text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded">
                      ID: {currentClient.id}
                    </span>
                    <span>{currentClient.umur} Tahun ({currentClient.gender})</span>
                    <span className="flex items-center gap-1 text-sky-700">
                      <MapPin className="w-3.5 h-3.5" />
                      {currentClient.formData.kabupatenKota || 'Jawa Barat'}
                    </span>
                    <span className="text-slate-600">
                      Jurusan: <strong className="text-sky-800">{currentClient.formData.jurusan || '-'}</strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Status Badge & Actions */}
              <div className="flex flex-wrap items-center gap-2 sm:gap-2.5 w-full sm:w-auto justify-between sm:justify-end">
                {(() => {
                  const clientStatus = currentClient.status || 'Calon Klien';
                  const badgeClass = clientStatus.includes('Aktif')
                    ? 'bg-sky-50 text-sky-800 border-sky-200'
                    : clientStatus.includes('Terminasi')
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : clientStatus.includes('Seleksi')
                    ? 'bg-amber-50 text-amber-800 border-amber-200'
                    : 'bg-rose-50 text-rose-800 border-rose-200';

                  return (
                    <span
                      className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-bold shadow-2xs border ${badgeClass}`}
                    >
                      {clientStatus}
                    </span>
                  );
                })()}

                {/* Modul Sidang Kasus Terpadu (Case Conference) */}
                <button
                  type="button"
                  onClick={() => setIsCaseConferenceOpen(true)}
                  className="bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200 font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 shadow-2xs transition"
                  title="Sidang Kasus Terpadu (Case Conference / Multidisiplin)"
                >
                  <Users className="w-3.5 h-3.5 text-purple-600" />
                  <span>Sidang Kasus</span>
                  <span className="bg-purple-200/80 text-purple-900 text-[10px] px-1.5 py-0.2 rounded-full font-extrabold">
                    {currentClient.caseConferences?.length || 0}
                  </span>
                </button>

                {/* Modul Berkas Digital Klien */}
                <button
                  type="button"
                  onClick={() => setIsAttachmentsOpen(true)}
                  className="bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 shadow-2xs transition"
                  title="Lampiran Berkas Digital Klien (KK, Akta, Surat, Foto)"
                >
                  <FolderLock className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Berkas Digital</span>
                  <span className="bg-indigo-200/80 text-indigo-900 text-[10px] px-1.5 py-0.2 rounded-full font-extrabold">
                    {currentClient.berkasDigital?.length || 0}
                  </span>
                </button>

                {/* Modul Kontrak Pelayanan Sosial 3 Bulan */}
                <button
                  type="button"
                  onClick={() => setIsSocialContractOpen(true)}
                  className={`font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 shadow-2xs transition border ${
                    currentClient.kontrakPelayanan
                      ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border-emerald-300'
                      : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-amber-300'
                  }`}
                  title="Kontrak Pelayanan Sosial Binaan Balai (Standar 3 Bulan)"
                >
                  <FileCheck className={`w-3.5 h-3.5 ${currentClient.kontrakPelayanan ? 'text-emerald-600' : 'text-amber-600'}`} />
                  <span>Kontrak 3 Bulan</span>
                  {currentClient.kontrakPelayanan && (
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  )}
                </button>

                {/* Tombol Simpan Manual */}
                <button
                  type="button"
                  onClick={handleManualSave}
                  className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-3.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 shadow-xs transition"
                  title="Simpan Perubahan Data"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Simpan</span>
                </button>
              </div>
            </div>

            {/* Tabs Navigation */}
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200/90 overflow-hidden">
              <div className="border-b border-slate-200 overflow-x-auto bg-slate-50/50">
                <nav className="flex w-max min-w-full -mb-px px-2" aria-label="Tabs">
                  {/* Tab Seleksi - only shown if client is still candidate or explicitly on it */}
                  {(currentClient.status === 'Calon Klien (Proses Seleksi)' || activeTab === 'tab-seleksi') && (
                    <button
                      onClick={() => setActiveTab('tab-seleksi')}
                      className={`tab-btn flex-1 min-w-[140px] py-3.5 px-3 text-center border-b-2 font-bold text-xs sm:text-sm transition flex items-center justify-center gap-1.5 ${
                        activeTab === 'tab-seleksi'
                          ? 'border-sky-600 text-sky-700 bg-white'
                          : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <ClipboardCheck className="w-4 h-4" /> Seleksi Calon
                    </button>
                  )}

                  <button
                    onClick={() => setActiveTab('tab-profil')}
                    className={`tab-btn flex-1 min-w-[140px] py-3.5 px-3 text-center border-b-2 font-bold text-xs sm:text-sm transition flex items-center justify-center gap-1.5 ${
                      activeTab === 'tab-profil'
                        ? 'border-sky-600 text-sky-700 bg-white'
                        : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <FileText className="w-4 h-4" /> Profil & Riwayat
                  </button>

                  <button
                    onClick={() => setActiveTab('tab-asesmen')}
                    className={`tab-btn flex-1 min-w-[140px] py-3.5 px-3 text-center border-b-2 font-bold text-xs sm:text-sm transition flex items-center justify-center gap-1.5 ${
                      activeTab === 'tab-asesmen'
                        ? 'border-sky-600 text-sky-700 bg-white'
                        : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <Brain className="w-4 h-4" /> Asesmen BPSS
                    <Sparkles className="w-3 h-3 text-purple-600" />
                  </button>

                  <button
                    onClick={() => setActiveTab('tab-intervensi')}
                    className={`tab-btn flex-1 min-w-[140px] py-3.5 px-3 text-center border-b-2 font-bold text-xs sm:text-sm transition flex items-center justify-center gap-1.5 ${
                      activeTab === 'tab-intervensi'
                        ? 'border-sky-600 text-sky-700 bg-white'
                        : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <Handshake className="w-4 h-4" /> Intervensi & Log
                    <Sparkles className="w-3 h-3 text-purple-600" />
                  </button>

                  <button
                    onClick={() => setActiveTab('tab-evaluasi')}
                    className={`tab-btn flex-1 min-w-[140px] py-3.5 px-3 text-center border-b-2 font-bold text-xs sm:text-sm transition flex items-center justify-center gap-1.5 ${
                      activeTab === 'tab-evaluasi'
                        ? 'border-sky-600 text-sky-700 bg-white'
                        : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <Flag className="w-4 h-4" /> Evaluasi Akhir
                  </button>

                  <button
                    onClick={() => setActiveTab('tab-cetak')}
                    className={`tab-btn flex-1 min-w-[140px] py-3.5 px-3 text-center border-b-2 font-bold text-xs sm:text-sm transition flex items-center justify-center gap-1.5 ${
                      activeTab === 'tab-cetak'
                        ? 'border-sky-600 text-sky-700 bg-white'
                        : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <Printer className="w-4 h-4" /> Cetak Laporan
                  </button>
                </nav>
              </div>

              {/* Tab Content Body */}
              <div className="p-5 sm:p-7">
                {activeTab === 'tab-seleksi' && (
                  <TabSeleksi client={currentClient} onChangeField={handleUpdateField} />
                )}

                {activeTab === 'tab-profil' && (
                  <TabProfil
                    client={currentClient}
                    jurusanList={jurusanList}
                    allAngkatanList={allAngkatanList}
                    onChangeField={handleUpdateField}
                    onAddPenyakit={handleAddPenyakit}
                    onRemovePenyakit={handleRemovePenyakit}
                    onOpenManageJurusan={() => setIsManageJurusanOpen(true)}
                  />
                )}

                {activeTab === 'tab-asesmen' && (
                  <TabAsesmen
                    client={currentClient}
                    onChangeField={handleUpdateField}
                    onGoToPrint={() => setActiveTab('tab-cetak')}
                    onShowToast={showToast}
                    peksosName={peksosName}
                  />
                )}

                {activeTab === 'tab-intervensi' && (
                  <TabIntervensi
                    client={currentClient}
                    onChangeField={handleUpdateField}
                    onAddIntervensiLog={handleAddIntervensiLog}
                    onRemoveIntervensiLog={handleRemoveIntervensiLog}
                    onShowToast={showToast}
                    peksosName={peksosName}
                    onSaveClient={handleManualSave}
                  />
                )}

                {activeTab === 'tab-evaluasi' && (
                  <TabEvaluasi 
                    client={currentClient} 
                    onChangeField={handleUpdateField} 
                    peksosName={peksosName}
                    onShowToast={showToast}
                  />
                )}

                {activeTab === 'tab-cetak' && (
                  <TabCetak client={currentClient} peksosName={peksosName} />
                )}
              </div>

              {/* Bottom Card Footer */}
              <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-slate-500">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  Sistem tersinkronisasi lokal & server terintegrasi Gemini AI
                </span>
                <button
                  type="button"
                  onClick={handleManualSave}
                  className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-5 py-2 rounded-lg text-xs flex items-center gap-1.5 shadow-xs transition"
                >
                  <Save className="w-3.5 h-3.5" />
                  Simpan Perubahan
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4">
            <Users className="w-12 h-12 text-slate-400 mx-auto" />
            <h2 className="text-xl font-bold text-slate-800">Belum Ada Data Anak Dipilih</h2>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Silakan pilih anak binaan dari filter di bagian atas atau tambahkan data anak binaan baru untuk memulai proses asesmen dan intervensi sosial.
            </p>
            <button
              onClick={() => setIsAddClientOpen(true)}
              className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-5 py-2 rounded-xl text-xs inline-flex items-center gap-2"
            >
              Tambah Anak Baru
            </button>
          </div>
        )}
      </main>

      {/* Floating Gemini AI Quick Assist Button */}
      <button
        onClick={() => setIsAIConsultOpen(true)}
        className="fixed bottom-6 left-6 z-40 bg-linear-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white p-3.5 rounded-full shadow-xl flex items-center gap-2 transition hover:scale-105 no-print"
        title="Buka Asisten Konsultasi Kasus AI"
      >
        <Sparkles className="w-5 h-5 text-amber-300" />
        <span className="text-xs font-bold pr-1 hidden sm:inline">Konsultasi AI</span>
      </button>

      {/* Modals */}
      <AddClientModal
        isOpen={isAddClientOpen}
        onClose={() => setIsAddClientOpen(false)}
        onSave={handleSaveNewClient}
        allAngkatanList={allAngkatanList}
        existingClients={clientList}
        onOpenExcelImport={() => handleOpenDataManagement('import')}
      />

      <GlobalDashboardModal
        isOpen={isGlobalDashboardOpen}
        onClose={() => setIsGlobalDashboardOpen(false)}
        clients={clientList}
        onSelectClient={setCurrentClientId}
        allAngkatanList={allAngkatanList}
      />

      <DataManagementModal
        isOpen={isDataManagementOpen}
        onClose={() => setIsDataManagementOpen(false)}
        clients={clientList}
        onImportClients={handleImportClients}
        onShowToast={showToast}
        initialTab={dataManagementTab}
      />

      <AIConsultModal
        isOpen={isAIConsultOpen}
        onClose={() => setIsAIConsultOpen(false)}
        activeClient={currentClient || undefined}
      />

      <ManageJurusanModal
        isOpen={isManageJurusanOpen}
        onClose={() => setIsManageJurusanOpen(false)}
        jurusanList={jurusanList}
        onAddJurusan={(name) => setJurusanList((prev) => [...prev, name])}
        onRemoveJurusan={(idx) =>
          setJurusanList((prev) => prev.filter((_, i) => i !== idx))
        }
      />

      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        peksosName={peksosName}
        onSave={setPeksosName}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onShowToast={showToast}
        onSuccess={(name) => setPeksosName(name)}
      />

      {/* Modul Sidang Kasus Terpadu (Case Conference) */}
      {currentClient && (
        <CaseConferenceModal
          isOpen={isCaseConferenceOpen}
          onClose={() => setIsCaseConferenceOpen(false)}
          client={currentClient}
          onSaveCaseConference={handleSaveCaseConference}
          onDeleteCaseConference={handleDeleteCaseConference}
          onShowToast={showToast}
          peksosName={peksosName}
        />
      )}

      {/* Modul Lampiran Berkas Digital Klien */}
      {currentClient && (
        <DigitalAttachmentModal
          isOpen={isAttachmentsOpen}
          onClose={() => setIsAttachmentsOpen(false)}
          client={currentClient}
          onSaveAttachment={handleSaveAttachment}
          onDeleteAttachment={handleDeleteAttachment}
          onShowToast={showToast}
          peksosName={peksosName}
        />
      )}

      {/* Modul Kontrak Pelayanan Sosial 3 Bulan */}
      {currentClient && (
        <SocialContractModal
          isOpen={isSocialContractOpen}
          onClose={() => setIsSocialContractOpen(false)}
          client={currentClient}
          onSaveSocialContract={handleSaveSocialContract}
          onShowToast={showToast}
          peksosName={peksosName}
        />
      )}

      {/* Modal Pencarian Global Cepat (Ctrl+K) */}
      <GlobalQuickSearchModal
        isOpen={isQuickSearchOpen}
        onClose={() => setIsQuickSearchOpen(false)}
        clients={clientList}
        onSelectClient={handleSelectClientAndTab}
      />

      {/* Panel Administrator Eksklusif */}
      {isAdmin && (
        <AdminPanelModal
          isOpen={isAdminPanelOpen}
          onClose={() => setIsAdminPanelOpen(false)}
          clients={clientList}
          currentUserEmail={currentUser?.email}
          currentUserUid={currentUser?.uid}
          isCloudConnected={isCloudConnected}
          jurusanList={jurusanList}
          idleTimeoutMinutes={idleTimeoutMinutes}
          onChangeIdleTimeout={setIdleTimeoutMinutes}
          onAddJurusan={(name) => setJurusanList((prev) => [...prev, name])}
          onRemoveJurusan={(idx) =>
            setJurusanList((prev) => prev.filter((_, i) => i !== idx))
          }
          onSelectClient={(id) => handleSelectClientAndTab(id)}
          onUpdateClientStatus={handleUpdateClientStatusByAdmin}
          onDeleteClient={handleDeleteClientByAdmin}
          onSeedInitialClients={handleSeedInitialClients}
          onExportAllJSON={handleExportAllJSON}
          onSignOut={() => handleSignOut()}
          onShowToast={showToast}
        />
      )}
    </div>
  );
}
